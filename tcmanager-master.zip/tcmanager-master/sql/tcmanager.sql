# --------------------------------------------------------
# Host:                         127.0.0.1
# Database:                     tcmanager
# Server version:               5.2.4-MariaDB
# Server OS:                    Win32
# HeidiSQL version:             5.0.0.3272
# Date/time:                    2011-01-12 17:24:40
# --------------------------------------------------------

# Dumping database structure
CREATE DATABASE IF NOT EXISTS tcmanager;
USE tcmanager;

DROP TABLE IF EXISTS auth_role;
CREATE TABLE IF NOT EXISTS auth_role (
  roleId bigint(10) NOT NULL,
  name varchar(64) NOT NULL,
  description varchar(256) DEFAULT NULL,
  created bigint(10) DEFAULT NULL,
  modified bigint(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS auth_user;
CREATE TABLE auth_user (
	userid BIGINT(10) NOT NULL,
	name VARCHAR(64) NOT NULL,
	realname VARCHAR(128) NOT NULL,
	password VARCHAR(160) NOT NULL,
	email VARCHAR(128) NULL DEFAULT NULL,
	phone VARCHAR(32) NULL DEFAULT NULL,
	mobile VARCHAR(32) NULL DEFAULT NULL,
	status INT(4) NOT NULL,
	description VARCHAR(256) NULL DEFAULT NULL,
	type INT(4) NOT NULL,
	lastLoginTime BIGINT(10) NULL DEFAULT NULL,
	lockedAt BIGINT(10) NULL DEFAULT NULL,
	created BIGINT(10) NULL DEFAULT NULL,
	modified BIGINT(10) NULL DEFAULT NULL,
	dept VARCHAR(32) NULL DEFAULT NULL,
	iprestrict VARCHAR(128) NULL DEFAULT NULL,
	authedNavs VARCHAR(512) NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS asset;

CREATE  TABLE IF NOT EXISTS asset (
   `id` bigint(20) unsigned NOT NULL,
  `name` varchar(256) NOT NULL DEFAULT '',
  `alias` varchar(256) DEFAULT '',  
  `description` text,
  `type` varchar(256) NOT NULL,
  `virtualType` bigint(20) DEFAULT 0  COMMENT '虚拟化类型',
  `timeCreate` bigint(20) unsigned DEFAULT NULL,
  `timeModify` bigint(20) unsigned DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `mask` varchar(64) DEFAULT NULL,
  `mac` varchar(32) DEFAULT NULL,
  `servicePort` int(10) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL  DEFAULT 1 ,
  `manageSwitch` int(11) NOT NULL  DEFAULT 1 ,
  `manageGroupId` INT DEFAULT 0 COMMENT '资产所在组的id，可提高组递归查询效率',
  `departmentId` bigint(20) unsigned DEFAULT NULL,  
  `department` varchar(255) DEFAULT NULL COMMENT '所属部门',
  `business` varchar(255) DEFAULT NULL COMMENT '所属业务系统',
  `contact` varchar(64) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `manufacturer` varchar(128) DEFAULT NULL,
  `assetCode` varchar(64) DEFAULT NULL COMMENT '资产编码',
  `sn` varchar(128) DEFAULT NULL,
  `hardVersion` varchar(128) DEFAULT NULL,
  `softVersion` varchar(128) DEFAULT NULL,
  `installPath` varchar(512) DEFAULT NULL,
  `kpi` double DEFAULT NULL,
  `confidentiality` int(11) DEFAULT NULL,
  `integrity` int(11) DEFAULT NULL,
  `availability` int(11) DEFAULT NULL,
  `protectLevel` int(10) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `assignType` int(10) unsigned DEFAULT NULL,
  `externalSysid` varchar(50) DEFAULT NULL,
  `netdistrictId` int(11) DEFAULT 1,
  `masterId` bigint(20) DEFAULT NULL,
  `ipnum10` bigint(20) DEFAULT NULL,
  `ipHexadecimal` varchar(64) DEFAULT NULL,
  `innerRelation` int(11) DEFAULT NULL,
  `standby1` int(11) DEFAULT NULL,
  `standby2` int(11) DEFAULT NULL,
  `standby3` bigint(20) DEFAULT NULL,
  `standby4` bigint(20) DEFAULT NULL,
  `standby5` varchar(128) DEFAULT NULL COMMENT '用作存储虚拟主机和虚拟机的uuid', 
  `standby6` varchar(128) DEFAULT NULL,
  `manageUrl` VARCHAR(255) NULL DEFAULT NULL ,
  `username` VARCHAR(128) NULL DEFAULT NULL ,
  `password` VARCHAR(128) NULL DEFAULT NULL ,
  `encryption` VARCHAR(128) NULL DEFAULT NULL ,
  `timePurchase` bigint(20) unsigned DEFAULT NULL,
  `expiredDate` bigint(20) unsigned DEFAULT NULL,
  `reserveFields` text DEFAULT NULL,
  `method` VARCHAR(128) NULL DEFAULT NULL ,
  PRIMARY KEY (`id`),  
  INDEX `index_ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `asset_link` ;

CREATE TABLE `asset_link` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `type` int(11) NOT NULL,
  `timeCreate` bigint(20) unsigned DEFAULT NULL,
  `timeModify` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `manageSwitch` int(11) NOT NULL DEFAULT '1',
  `startId` bigint(20) unsigned NOT NULL,
  `startPortdesc` varchar(255) DEFAULT NULL,
  `startPort` int(11) DEFAULT NULL,
  `startPointShape` int(11) DEFAULT NULL,
  `endId` bigint(20) unsigned NOT NULL,
  `endPortdesc` varchar(255) DEFAULT NULL,
  `endPort` int(11) DEFAULT NULL,
  `endPointShape` int(11) DEFAULT NULL,
  `width` float DEFAULT NULL,
  `color` int(11) DEFAULT NULL,
  `shape` int(11) DEFAULT NULL,
  `flowThresholdHigh` bigint(20) DEFAULT -1,
  `flowThresholdLow` bigint(20) DEFAULT -1,
  PRIMARY KEY (`id`)
)ENGINE = InnoDB DEFAULT CHARACTER SET = utf8;

DROP TABLE IF EXISTS `radix_link` ;

CREATE TABLE `radix_link` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `type` int(11) NOT NULL,
  `timeCreate` bigint(20) unsigned DEFAULT NULL,
  `timeModify` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `manageSwitch` int(11) NOT NULL DEFAULT '1',
  sourceIp varchar(64) NOT NULL,
  endIp varchar(64) NOT NULL,
  lost float default 0,
  time bigint(20),
  min float,
  max float,
  avg float,
  mdev float,
  PRIMARY KEY (`id`)
)ENGINE = InnoDB DEFAULT CHARACTER SET = utf8;

DROP TABLE IF EXISTS `asset_v_manage` ;

CREATE  TABLE IF NOT EXISTS `asset_v_manage` (
  `id` BIGINT UNSIGNED NOT NULL ,
  `name` VARCHAR(64) NOT NULL DEFAULT '' ,
  `description` VARCHAR(255) NULL DEFAULT NULL ,
  `value` INT NOT NULL DEFAULT 0,
  `timeCreate` BIGINT UNSIGNED NULL ,
  `timeModify` BIGINT UNSIGNED NULL ,
  `status` INT NOT NULL DEFAULT 1,
  `manageSwitch` INT NOT NULL DEFAULT 1,
  `contact` VARCHAR(64) NULL DEFAULT NULL,
  `bgImage` VARCHAR(255) NULL DEFAULT NULL ,
  `icon` varchar(255) DEFAULT NULL,
  `bgColor` int(11) DEFAULT NULL,
  `graphUrl` TEXT NULL ,
  `builtIn` INT NULL ,
  `posSaved` INT DEFAULT 0,
  PRIMARY KEY (`id`) 
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8;

-- -----------------------------------------------------
-- Table `asset_relation`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `asset_relation` ;

CREATE  TABLE IF NOT EXISTS `asset_relation` (
  `id` BIGINT UNSIGNED NOT NULL ,
  `nodeId` BIGINT UNSIGNED NOT NULL ,
  `pNodeId` BIGINT UNSIGNED NOT NULL ,
  `nodeType` INT NOT NULL ,
  `pNodeType` INT NOT NULL ,
  `pointX` INT NULL ,
  `pointY` INT NULL ,
  `viewType` INT NOT NULL ,
  `graphType` INT NOT NULL DEFAULT 1 ,
   `polymorphic` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
)ENGINE = InnoDB DEFAULT CHARACTER SET = utf8;


DROP TABLE IF EXISTS `asset_auth` ;

CREATE  TABLE IF NOT EXISTS `asset_auth` (
  `id` BIGINT UNSIGNED NOT NULL ,
  `ip` VARCHAR(64) NULL DEFAULT NULL ,
  `netDistrictId` BIGINT UNSIGNED NULL,
  `url` VARCHAR(255) NULL DEFAULT NULL ,
  `protocol` VARCHAR(64) NULL DEFAULT NULL ,
  `port` INT NULL ,
  `instanceName` VARCHAR(32) NULL DEFAULT NULL ,
  `username` VARCHAR(32) NULL DEFAULT NULL ,
  `pwd` VARCHAR(64) NULL DEFAULT NULL ,
  `superPwd` VARCHAR(64) NULL DEFAULT NULL ,
  `snmpVersion` INT NULL ,
  `getCommunity` VARCHAR(64) NULL DEFAULT NULL ,
  `setCommunity` VARCHAR(64) NULL DEFAULT NULL ,
  `v3SecurityLevel` INT NULL ,
  `v3AuthProtocol` INT NULL ,
  `v3AuthPwd` VARCHAR(64) NULL DEFAULT NULL ,
  `v3PrivProtocol` VARCHAR(32) NULL DEFAULT NULL ,
  `v3PrivPwd` VARCHAR(64) NULL DEFAULT NULL ,
  `cmdPrompt` VARCHAR(32) NULL DEFAULT NULL ,
  `description` VARCHAR(255) NULL DEFAULT NULL ,
  `standby1` INT NULL ,
  `standby2` INT NULL ,
  `standby3` VARCHAR(64) NULL DEFAULT NULL ,
  `standby4` VARCHAR(64) NULL DEFAULT NULL ,
  PRIMARY KEY (`id`)
)ENGINE = InnoDB DEFAULT CHARACTER SET = utf8;


-- 设备类型
-- ----------------------------
-- Table structure for `asset_v_type`
-- ----------------------------
DROP TABLE IF EXISTS `asset_v_type`;
CREATE TABLE IF NOT EXISTS `asset_v_type` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `code` varchar(64) NOT NULL DEFAULT '',
  `icon` varchar(255) DEFAULT NULL,
  `builtIn` int(11) DEFAULT '2',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  UNIQUE KEY `code_UNIQUE` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- ------------------------------------------------------
-- 告警表
-- ------------------------------------------------------
DROP TABLE IF EXISTS `corr_alert`;
CREATE TABLE IF NOT EXISTS `corr_alert` (
  `id` bigint(20) NOT NULL COMMENT 'ID',
  `ruleId` varchar(128) COMMENT '关联规则ID',
  `eventIds` mediumtext COMMENT '关联事件ID,以逗号分隔',
  `businessIds` varchar(512) COMMENT '关联业务ID,以逗号分隔',
  `assetId` bigint(10) COMMENT '关联资产ID',
  `assetDistrict` varchar(64) COMMENT '关联资产所属网络区域',
  `title` varchar(256) DEFAULT NULL COMMENT '告警名称',
  `priority` int(1) COMMENT '告警等级',
  `devIp` varchar(128) COMMENT '设备IP',
  `devName` varchar(64) COMMENT '设备名称',
  `devType` varchar(128) COMMENT '设备类型',
  `alertType` varchar(32) DEFAULT NULL COMMENT '告警分类',
  `alertSrc` int(1) DEFAULT '1' COMMENT '告警来源(0-监控,1-事件)',
  `monitorTaskId` bigint(20) COMMENT '监控任务ID',
  `monitorItemId` bigint(10) COMMENT '监控指标ID',
  `status` int(1) DEFAULT '0' COMMENT '处理状态(0-未处理,1-已处理)',
  `solution` text COMMENT '处理情况描述',
  `handledBy` bigint(10) DEFAULT NULL COMMENT '处理者',
  `timeHandled` bigint(20) DEFAULT NULL COMMENT '处理时间',
  `timeCreated` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `repeattimes` bigint(20) DEFAULT '1' COMMENT '重复次数',
  `description` text COMMENT '描述',
  PRIMARY KEY (`ID`),
  INDEX index_devIp (devIp),
  INDEX index_priority (priority),
  INDEX index_timeCreated (timeCreated)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='告警表';





# Dumping structure for table auth_userrole_relation
DROP TABLE IF EXISTS auth_userrole_relation;
CREATE TABLE IF NOT EXISTS auth_userrole_relation (
  relationId bigint(10) NOT NULL,
  userId bigint(10) NOT NULL,
  roleId bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# Dumping structure for table monitor_taskstruct
DROP TABLE IF EXISTS `monitor_taskstruct`;
CREATE TABLE IF NOT EXISTS `monitor_taskstruct` (
  `id` bigint(20) NOT NULL,
  `assetId` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `ip` varchar(64),
  `mTypeId` int(10) NOT NULL,
  `mType` varchar(64) NOT NULL,
  `versionId` int(10) NOT NULL,
  `version` varchar(64) NOT NULL,
  `protocol` varchar(64) NOT NULL,
  `port` int(10) NOT NULL,
  `schemaName` varchar(64) NOT NULL,
  `url` varchar(512) NOT NULL,
  `task` tinyint(1) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `forceCreate` tinyint(1) NOT NULL,
  `keepData` tinyint(1) NOT NULL,
  `taskStatus` int(10) NOT NULL,
  `schedulingCycle` int(10) NOT NULL,
  `defaultTimeout` int(10) NOT NULL,
  `retrys` int(10) NOT NULL,
  `relip` varchar(64) DEFAULT NULL COMMENT '关联IP,用作添加vmware监控任务时获取认证信息',
  `uuid` varchar(128) DEFAULT NULL COMMENT '虚拟机或虚拟服务器监控任务的uuid',
  `collector` varchar(128) DEFAULT NULL COMMENT '运行环境 0为本地 其他为采集器uuid',
  PRIMARY KEY (`id`),
  KEY `ip_key` (`ip`)
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


# Dumping structure for table monitor_concernsentry
DROP TABLE IF EXISTS `monitor_concernsentry`;
CREATE TABLE IF NOT EXISTS `monitor_concernsentry` (
  `id` bigint(20) NOT NULL,
  `taskId` bigint(20) NOT NULL,
  `concernsId` bigint(10) NOT NULL,
  `concernsName` varchar(64) NOT NULL,
  `brief` varchar(128) NOT NULL,
  `indexId` int(10) NOT NULL,
  `indexName` varchar(512) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `type` int(10) NOT NULL,
  `unit` varchar(255) NOT NULL,  
  `oid` text,  
  `customBandwidth` float DEFAULT '-1',
  `comments` varchar(64) NOT NULL,
  `alertSetting` text DEFAULT NULL COMMENT '告警设置',
  
  PRIMARY KEY (`id`),
  KEY `taskId_key` (`taskId`),
  KEY `concernsId_key` (`concernsId`)
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dumping structure for table monitor_ext
DROP TABLE IF EXISTS `monitor_ext`;
CREATE TABLE IF NOT EXISTS `monitor_ext` (
  `id` bigint(20) NOT NULL,
  `taskId` bigint(20) NOT NULL,
  `className` text, 
  `xml` text,  
  PRIMARY KEY (`id`),
  KEY `taskId_key` (`taskId`)
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


# Dumping structure for table sys_tblids
DROP TABLE IF EXISTS `sys_tblids`;
CREATE TABLE IF NOT EXISTS `sys_tblids` (
  `name` varchar(32) NOT NULL,
  `maxid` bigint(20) NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# Dumping structure for table sys_logs
DROP TABLE IF EXISTS `sys_logs`;
CREATE TABLE IF NOT EXISTS `sys_logs` (
  `timestamp` bigint(20) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `username` varchar(64) NOT NULL,
  `sourceip` varchar(32) DEFAULT NULL,
  `module` varchar(128) DEFAULT NULL,
  `action` varchar(128) DEFAULT NULL,
  `msg` varchar(512) DEFAULT NULL,
  `result` int(4) NOT NULL,
  `cause` varchar(128) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- admin / admin
INSERT INTO auth_user VALUES (1,'admin','超级管理员','d033e22ae348aeb5660fc2140aec35850c4da997',NULL,NULL,NULL,1,NULL,0,0,0,0,0,NULL,NULL,NULL);

-- 默认资产组
INSERT INTO `asset_v_manage` (`id`, `name`, `description`, `value`, `timeCreate`, `timeModify`, `status`, `manageSwitch`, `contact`, `bgImage`, `icon`, `bgColor`, `graphUrl`, `builtIn`) VALUES (1, '默认分组', '默认分组', 0, 0, 0, 0, 0, NULL, NULL, NULL, -1, NULL, 0);
INSERT INTO `asset_relation` (`id`, `nodeId`, `pNodeId`, `nodeType`, `pNodeType`, `pointX`, `pointY`, `viewType`, `graphType`, `polymorphic`) VALUES (1, 1, 0, 4, 4, 80, 80, 1, 0, 0);

INSERT INTO `asset_v_type` VALUES (2, '/服务器/Linux', '/server/linux', 'server_linux.png', 1);
INSERT INTO `asset_v_type` VALUES (3, '/服务器/Windows', '/server/windows', 'server_windows.png', 1);
INSERT INTO `asset_v_type` VALUES (4, '/服务器/AIX', '/server/aix', 'server_aix.png', 1);
INSERT INTO `asset_v_type` VALUES (5, '/服务器/Solaris', '/server/solaris', 'server_solaris.png', 1);
INSERT INTO `asset_v_type` VALUES (6, '/服务器/HP-UX', '/server/hpunix', 'server_hp.png', 1);
INSERT INTO `asset_v_type` VALUES (20, '/交换机', '/switchboard', 'net_switch.png', 1);
INSERT INTO `asset_v_type` VALUES (30, '/路由器', '/router', 'net_router.png', 1);
INSERT INTO `asset_v_type` VALUES (40, '/安全设备', '/securitydevice', 'security.png', 1);
INSERT INTO `asset_v_type` VALUES (50, '/网擎流控设备', '/radixdigit', 'net_traffic.png', 1);

INSERT INTO `sys_tblids` VALUES ('asset_relation',10000);
INSERT INTO `sys_tblids` VALUES ('asset_nodegroup',10000);
INSERT INTO `sys_tblids` VALUES ('asset_v_manage',10000);
INSERT INTO `sys_tblids` VALUES ('asset_v_type',10000);
INSERT INTO `sys_tblids` VALUES ('auth_user',10000);


