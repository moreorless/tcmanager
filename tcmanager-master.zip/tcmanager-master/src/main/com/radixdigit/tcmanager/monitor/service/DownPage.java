package com.radixdigit.tcmanager.monitor.service;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

/**
 * @author 陈庆钊
 * @Email parkme210@hotmail.com
 * @date 2012-9-5下午1:30:13
 * @Description TODO
 */
public class DownPage {
	
	private String uri = null;
	
	public DownPage(String uri){
		this.uri = uri;
	}
	
	static final Pattern charsetPattern = Pattern.compile("(?i)charset=\"?([-_\\w]*)\"?");
	private String getCharset (String _c_type) {
		if (_c_type != null) {
			Matcher matcher = charsetPattern.matcher(_c_type);
			if (matcher.find())
				return matcher.group(1);
		}
		return Charset.defaultCharset().name();
	}
	
	private int getResponseContent (HttpURLConnection conn ,byte[] b, boolean isGzip) throws IOException{
		BufferedInputStream in;
		if (isGzip)
			in = new BufferedInputStream(new GZIPInputStream(conn.getInputStream()));
		else
			in = new BufferedInputStream(conn.getInputStream());			
		
		int off = 0;
		int len = 0;
		while ((len = in.read(b, off, b.length - off)) >= 0) {
			off += len;
		}
		in.close();
		return off;
	}
	
	private String doubleCheckCharsetInsideHTML (String content, String charsetInHeader) {
		Matcher matcher = charsetPattern.matcher(content);
		if (matcher.find()) {
			String charset = matcher.group(1);
			if (!charset.equalsIgnoreCase(charsetInHeader)) {
				return charset;
			}
		}
		return charsetInHeader;
	}
	public String getPageResource(){
		String content = null;
		HttpURLConnection conn = null;
		try {
			conn = getConnection(uri);
			
			//获得页面编码
			String content_encoding = conn.getContentEncoding();
			String content_charset = getCharset (conn.getContentType());
			
			byte[] b = new byte[5485760];
			int off = getResponseContent(conn, b ,"gzip".equalsIgnoreCase(content_encoding));

			content = new String (b, 0 ,off, content_charset);
			String checkedCharset = doubleCheckCharsetInsideHTML (content, content_charset); 
			if (checkedCharset != content_charset){
				content = new String (b, 0 ,off, checkedCharset);
			}
		} catch (UnsupportedEncodingException e) {
			//e.printStackTrace();
			System.out.println(uri+"打开出错。。。。。。。。");
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(conn != null)
				conn.disconnect();
		}
		return content;
	}
	
	private HttpURLConnection getConnection (String uri){
		HttpURLConnection conn = null;
		try {
			URL url = new URL(uri);
			conn = (HttpURLConnection)url.openConnection();	
			setProperties (conn);
			conn.setConnectTimeout(10000);
			
			try{
				conn.connect();
			}catch (java.net.SocketTimeoutException e){
				System.out.println("error while connecting: "+uri);
			}
			
		} catch (MalformedURLException e) {
			//e.printStackTrace();
			System.out.println(uri+"打开出错。。。。。。。。");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return conn;
	}
	private void setProperties (HttpURLConnection conn) {
		conn.setRequestProperty("Cookie","PREF=ID=50ecee25e6158be9:U=09591b7451d583a9:FF=1:LD=zh-CN:NW=1:TM=1276692359:LM=1282280648:S=yCeAMql2fQdx1TNf; NID=36=czadLRFDzxz0Gz9U1Mt7H-6jjdEZEFMABSm7T9cxLOTFpMea6ksmtJzUo2ipuaag4Ju9vgp57RwaN7VvK1sxatXE6LUxRxaI8LPAoNpqZWjFIEQH_AzXD6fk_B91CnIw");
		conn.setRequestProperty("Connection","keep-alive");
		conn.setRequestProperty("Accept-Encoding","gzip,deflate");
		conn.setRequestProperty("User-agent","Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0;  Embedded Web Browser from: http://bsalsa.com/; .NET CLR 2.0.50727; InfoPath.2; CIBA; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; msn OptimizedIE8;ZHCN; AskTB5.6)");
		conn.setRequestProperty("Accept-Charset","GBK,utf-8;q=0.7,*;q=0.3");
		conn.setRequestProperty("Accept-Language","zh-cn");
		conn.setRequestProperty("Accept","application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5");
		conn.setRequestProperty("Cache-Control","max-age=0");
	}
}
