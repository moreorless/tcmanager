package com.radixdigit.tcmanager.monitor.service;

import java.util.List;

import org.nutz.ioc.loader.annotation.IocBean;

@IocBean
public class IfMonitorService {

	/**
	 * 读取接口的历史数据
	 * @param taskId	任务id
	 * @param ifIndex	接口序号
	 * @param type		数据类型(ifStatus/ifFlux/ifOutFlux/ifOutPkts/ifOutUtilization/ifOutError/ifOutLost/ifInFlux/ifInPkts/ifInUtilization/ifInError/ifInLost)
	 * @param startTime	开始时间
	 * @param endTime	结束时间
	 */
	public List<Number> getHistroyData(long taskId, int ifIndex, String type, long startTime, long endTime){
		
		return null;
	}
	
}
