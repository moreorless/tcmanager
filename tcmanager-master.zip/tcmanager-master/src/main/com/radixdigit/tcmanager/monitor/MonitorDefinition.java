package com.radixdigit.tcmanager.monitor;

import java.util.HashMap;
import java.util.Map;

public class MonitorDefinition {

//	public static Integer counter = 0;
//	
//	public static Integer ready = 0;
//	
//	public synchronized static void changeReadyCounter(){
//		ready = ready + 1;
//	}
//	
//	public synchronized static void changeCounter(String a){
//		if(a.equals("+")){
//			counter = counter+1;
//		}
//		if(a.equals("-")){
//			counter = counter-1;
//		}
//		System.out.println("当前正在执行的任务数量为：" + counter + "已加入调度的任务数量为：" + ready);
//	}
	/**
	 * 每行的分隔符
	 */
	public static String INFO_SEPARATOR = "\t";

	/**
	 * 每个参数的分隔符
	 */
	public static String AUTH_SEPARATOR = ",";

	/**
	 *  标准协议端口映射 
	 *  key:   端口号
	 *  value: 协议名
	 */
	public static Map<String, String> standardPort = new HashMap<String, String>();
	
	/**
	 * 	认证信息构造类映射
	 */
	public static Map<String, String> constructor = new HashMap<String, String>();
	
	/**
	 * 监控大类型-颜色映射
	 * 
	 * 例：主机——#FF0000
	 */
	public static Map<String, String> color = new HashMap<String, String>();
	
	static{
		standardPort.put("22", "ssh");
		standardPort.put("23", "telnet");
		standardPort.put("161", "snmp");
		standardPort.put("3306", "jdbc");
		standardPort.put("1521", "jdbc");
		standardPort.put("1433", "jdbc");
		standardPort.put("-1", "http");
		
		constructor.put("dhcp", "com.radixdigit.tcmanager.monitor.batch.paramconstructor.DhcpConstructor");
		constructor.put("dns", "com.radixdigit.tcmanager.monitor.batch.paramconstructor.DnsConstructor");
		constructor.put("http", "com.radixdigit.tcmanager.monitor.batch.paramconstructor.HttpConstructor");
		constructor.put("jdbc", "com.radixdigit.tcmanager.monitor.batch.paramconstructor.JdbcConstructor");
		constructor.put("ssh", "com.radixdigit.tcmanager.monitor.batch.paramconstructor.ShellConstructor");
		constructor.put("telnet", "com.radixdigit.tcmanager.monitor.batch.paramconstructor.ShellConstructor");
		constructor.put("snmp", "com.radixdigit.tcmanager.monitor.batch.paramconstructor.SnmpConstructor");
		constructor.put("tcp", "com.radixdigit.tcmanager.monitor.batch.paramconstructor.TcpConstructor");
		constructor.put("tomcat_jmx", "com.radixdigit.tcmanager.monitor.batch.paramconstructor.TomcatJmxConstructor");
		constructor.put("websphere_xml", "com.radixdigit.tcmanager.monitor.batch.paramconstructor.WebsphereXmlConstructor");
		
		color.put("windows", "#3399ff");
		color.put("linux", "#ff00ff");
		color.put("aix", "#ffff00");
		color.put("solaris", "#ccffff");
		color.put("router", "#ccff00");
		color.put("switchboard", "#ffcc00");
		color.put("firewall", "#ccccff");
		color.put("ips", "#cccc00");
		color.put("ids", "#0000ff");
		color.put("av", "#ff0000");
		color.put("storage", "#66cc33");
		color.put("oracle", "#66cc33");
		color.put("sqlserver", "#cccc66");
		color.put("mysql", "#ff00ff");
		color.put("sybase", "#cc99cc");
		color.put("db2", "#993300");
		color.put("informix", "#000099");
		color.put("weblogic", "#339900");
		color.put("websphere", "#9999cc");
		color.put("webapplication", "#9999cc");
		color.put("web", "#666666");
		color.put("tomcat", "#333366");
		color.put("iis", "#330066");
		color.put("LotusDomino", "#ffcc66");
		color.put("email", "#9132c9");
		color.put("tcp", "#cc0066");
		color.put("dns", "#0033ff");
		color.put("dhcp", "#ff0099");
		color.put("esx", "#ccffcc");
		color.put("vm", "#6699cc");
		color.put("utm", "#b0eecf");
	}
}
