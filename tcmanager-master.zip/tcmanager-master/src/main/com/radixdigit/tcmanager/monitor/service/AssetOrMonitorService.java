package com.radixdigit.tcmanager.monitor.service;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.radixdigit.tcmanager.monitor.core.DefaultTask;
import com.radixdigit.tcmanager.monitor.core.MonitorDispatcherService;
import com.radixdigit.tcmanager.monitor.core.TaskContext;
import com.radixdigit.tcmanager.monitor.core.config.BasicDataManager;
import com.radixdigit.tcmanager.monitor.core.config.beans.MVersionDef;
import com.radixdigit.tcmanager.monitor.core.config.beans.mversion.Concerns;
import com.radixdigit.tcmanager.monitor.core.dao.MonitorDao;
import com.radixdigit.tcmanager.monitor.core.dao.MonitorInterfaceDao;
import com.radixdigit.tcmanager.monitor.core.data.ConcernsEntry;
import com.radixdigit.tcmanager.monitor.core.data.TaskStruct;
import com.radixdigit.tcmanager.util.dao.DaoUtil;


@IocBean(name = "assetOrMonitorService")


public class AssetOrMonitorService{
    private static Logger logger = Logger.getLogger(ProMonitorService.class);
    private MonitorDao dao = null;
	private MonitorDispatcherService dispatcherService;
	private MonitorInterfaceDao monitorInterfaceDao;
	@Inject("refer:monitorInterfaceDao")
	public void setMonitorInterfaceDao(MonitorInterfaceDao monitorInterfaceDao) {
		this.monitorInterfaceDao = monitorInterfaceDao;
	}
	@Inject("refer:monitorDao")
	public void setMonitorDao(MonitorDao dao)
	{
		this.dao = dao;
	}
	@Inject("refer:$setup_MonitorDispatcherService")
	public void setDispatcherService(MonitorDispatcherService dispatcherService)
	{
		this.dispatcherService = dispatcherService;
	}
	
    /**
     *监控类型与资产类型的映射(根据资产的类型获取监控类型的数据)
     */
	public String getMonitorType(String assertType) {
		String value="";
		try{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setIgnoringElementContentWhitespace(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			String fileName = "AlertDevTypeMapping.xml";
			String path = System.getProperty("conf.dir")+File.separator+"monitor"+File.separator+fileName;
			Document document = builder.parse(new File(path));
			NodeList nodeList = document.getElementsByTagName("DevTypeItem");
			//获取监控类型的数据
			for(int i=0;i<nodeList.getLength();i++){
			    boolean flag=false; 
				//获取当前的节点
				Node devType = nodeList.item(i);
				//获取当前节点的子节点的集合
				NodeList attList =  devType.getChildNodes();
				for(int j =0;j<attList.getLength();j++){
					if(attList.item(j).getNodeName().equals("AlertDeVTypeName")){
						value = attList.item(j).getTextContent();
					} 
					if(attList.item(j).getNodeName().equals("DevTypeName")){	    	
						if(assertType.equals(attList.item(j).getTextContent())){
							  flag=true;
							  break;
						}
				    }
				}
				if(true){
					break;
				}
			 }
			}catch(Exception e){
				System.out.println(e);
			}
		return value;
	}
    /**
     *
     *根据IP+监控类型获取监控器
     * 
     */
	public List<TaskStruct> getMonitorByIPOrMtype(String ip, String mtype) {
	    List<TaskStruct> lisTaskStruct=monitorInterfaceDao.getMonitorByIPOrMtype(ip, mtype);
		if(lisTaskStruct.size()>0){	
		  return lisTaskStruct;
	    }else{
		   logger.error("未找到Ip=["+ip+"]监控类型mType=["+mtype+"]的监控");
		   return null;
	    }
	}
	/**
	 * 根据监控的Id获取监控的可用性
	 * @param monitorId
	 * @return
	 */
	public String getUsibility(long monitorId) {
		TaskStruct ts=dao.getTaskStructOnly(monitorId);
		MVersionDef versionDef = BasicDataManager.getInstance().getMVersionDef(ts.getMtypeId(), ts.getVersionId());
		if(versionDef == null)
		{
			logger.error("获取Web应用程序快照数据出错：此任务对应的版本定义对象不存在");
			return null;
		}
		DefaultTask task = dispatcherService.getByTaskId(monitorId);
		TaskContext tCtx = null;
		if(task == null){
			   tCtx = MonitorMessageListener.getCollectorTasks().get(ts.getName() + ts.getMtype());
		}else{
			   tCtx = task.getContext();
		}
		if(tCtx == null){
			logger.warn("不存在[id="+monitorId+"]的监控任务");
			return null;
		}
		String usability = null;
		if(tCtx.isUsability()){
			usability = "正常";
		}else{
			usability = "不可用";
		}
		
		return usability;
	}
	   /**
	    * 获取所有的Key的值
	    * @param monitorId
	    * @return
	    */
    	public List<String> getListKeyByMonitorId(long monitorId) {
    		List<String> strList=new ArrayList<String>();
    		TaskStruct ts=dao.getTaskStructOnly(monitorId);
    		MVersionDef versionDef = BasicDataManager.getInstance().getMVersionDef(ts.getMtypeId(), ts.getVersionId());
    		List<ConcernsEntry> listEntry=dao.getConcernsEntrysByTaskId(monitorId);
    		for(ConcernsEntry entry:listEntry){
    	     	    //获取关注的指标的实体类的对象的数据
    	     	    Concerns con=versionDef.getConcernsById(entry.getConcernsId());
    	     	    String key=con.getKey();
    	     	    boolean flag=false;
    	     	    for(int i=0;i<strList.size();i++){
    	     	    	if(strList.get(i).equals(key)){
    	     	    		flag=true;
    	     	    	}
    	     	    }
    	     	    if(flag==false){
    	     	      strList.add(key);
    	     	    }
    	     }
    		return strList;
    	}
	
	 /**
	  * 获取你想要的指标的值(两个方法进行的重叠)
	  * @return
	 * @throws SQLException 
	  */
	 public List<Double> getIndicatorValue(long monitorId,String itemKey,long startDate,long endDate){
		  List<Double> objList=new ArrayList<Double>();		 
		  TaskStruct ts=dao.getTaskStructOnly(monitorId);
		  MVersionDef versionDef = BasicDataManager.getInstance().getMVersionDef(ts.getMtypeId(), ts.getVersionId());
		  Concerns concerns= versionDef.getConcernsBykey(itemKey);
		  if(concerns != null){
			  String tableName=concerns.getDataTableName();
			  int concernsId=concerns.getConcernsId();
			  String sql="";
			  if(startDate==0&&endDate==0){
			      sql="select numericValue from "+tableName+" where concernsId = ? and time=(select max(time) from "+tableName+" )";
			  }else{
				  sql="select numericValue from "+tableName+" where concernsId = ? and time > ? and time < ?";
			  }
			  Connection conn = DaoUtil.me().getConnection();
			  PreparedStatement ps = null;
			  ResultSet rs = null;
			  try {
					ps = conn.prepareStatement(sql);
					ps.setInt(1, concernsId);
					if(!(startDate==0&&endDate==0)){
						ps.setLong(2,startDate);
						ps.setLong(3,startDate);
					}
					rs = ps.executeQuery();
					while(rs.next()){
						//获取查询出来的数据
						objList.add(rs.getDouble(1));
					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					if(rs != null){
						try{
							rs.close();
						}catch(SQLException sqlEx){
							logger.warn(sqlEx);
						}
					}
					if(ps != null)
					{
						try{
							ps.close();
				        }catch(SQLException sqlEx){
							logger.warn(sqlEx);
						}
					}
					DaoUtil.me().close(conn);
				}
				return objList;
		 }else{
			 return null;
		 }
	 }
}
