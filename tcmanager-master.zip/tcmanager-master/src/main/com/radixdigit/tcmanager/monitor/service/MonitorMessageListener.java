package com.radixdigit.tcmanager.monitor.service;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.radixdigit.tcmanager.monitor.MonitorUtils;
import com.radixdigit.tcmanager.monitor.core.TaskContext;
import com.radixdigit.tcmanager.monitor.core.TaskHelper;
import com.radixdigit.tcmanager.monitor.core.data.ConcernsDataResultSet;
import com.radixdigit.tcmanager.monitor.core.data.TaskStruct;
import com.radixdigit.tcmanager.tms.MessageListener;

public class MonitorMessageListener implements MessageListener {

	public static Map<String, TaskContext> collectorTasks = new HashMap<String, TaskContext>();
	
	@Override
	public void handle(Object message) {
		String tcs = (String)message;
		try {
			tcs = MonitorUtils.uncompress(tcs);
		} catch (IOException e) {
			e.printStackTrace();
		}
		TaskContext tc = null;
		tc = (TaskContext) MonitorUtils.getXstream().fromXML(tcs);
		setCollectorTasks(tc);
		// 存库 zd_表
		Collection<ConcernsDataResultSet> cache = tc.getAllCacheData();
		Iterator<ConcernsDataResultSet> it = cache.iterator();
		while(it.hasNext()){
			ConcernsDataResultSet cdr = it.next();
			TaskHelper.store(cdr);
		}
	}

	public static Map<String, TaskContext> getCollectorTasks() {
		return collectorTasks;
	}

	public static void setCollectorTasks(TaskContext collectorTask) {
		TaskStruct ts = collectorTask.getTaskStruct();
		collectorTasks.put(ts.getName() + ts.getMtype(), collectorTask);
	}
	
	public static void removeCollectorTasks(TaskStruct ts){
		collectorTasks.remove(ts.getName() + ts.getMtype());
	}
}
