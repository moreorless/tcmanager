package com.radixdigit.tcmanager;

import org.nutz.mvc.annotation.ChainBy;
import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.IocBy;
import org.nutz.mvc.annotation.LoadingBy;
import org.nutz.mvc.annotation.Modules;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.SetupBy;
import org.nutz.mvc.annotation.Views;

import com.radixdigit.tcmanager.annotation.JstlLocalization;
import com.radixdigit.tcmanager.commons.mvc.ioc.ComboIocProvider;
import com.radixdigit.tcmanager.commons.mvc.view.ExceptionViewMaker;

@LoadingBy(CupidNutLoading.class)
@Modules(scanPackage=true)
@Ok("json")
@Fail("json")
@IocBy(type = ComboIocProvider.class, args = {	//配置Ioc容器
		"*org.nutz.ioc.loader.json.JsonLoader", "ioc/dao.js", "ioc/service.js",
		"*org.nutz.ioc.loader.annotation.AnnotationIocLoader","com.radixdigit.tcmanager","com.radixdigit.tcmanager",
		"*org.nutz.ioc.loader.xml.XmlIocLoader", "ioc/controller.xml", "ioc/setuplistener.xml"} 
		)
@Views(ExceptionViewMaker.class)
@SetupBy(value = MainModuleSetup.class)
@JstlLocalization("../i18n")
@ChainBy(args="chain.js")
public class MainModule {

}
