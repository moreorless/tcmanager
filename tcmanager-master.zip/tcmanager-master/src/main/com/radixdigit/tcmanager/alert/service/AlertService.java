/**
 
 * Author: liusanrong
 * Created: July 1, 2011
 */
package com.radixdigit.tcmanager.alert.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.alert.dao.AlertDao;
import com.radixdigit.tcmanager.alert.data.Alert;
import com.radixdigit.tcmanager.commons.mvc.Pager;
import com.radixdigit.tcmanager.commons.service.TblIdsEntityService;
import com.radixdigit.tcmanager.schedule.DefaultScheduleIterator;
import com.radixdigit.tcmanager.schedule.Scheduler;
import com.radixdigit.tcmanager.schedule.SchedulerTask;
import com.radixdigit.tcmanager.util.dao.DaoUtil;
import com.radixdigit.tcmanager.monitor.core.config.BasicDataManager;
import com.radixdigit.tcmanager.monitor.core.config.beans.MTypeMeta;
import com.radixdigit.tcmanager.monitor.core.config.beans.global.Layer;
import com.radixdigit.tcmanager.monitor.core.config.beans.global.NodeRef;
import com.radixdigit.tcmanager.monitor.core.data.alert.AlertCache;


/**
 * 告警管理 service
 */

@IocBean(name="alertService", fields={"dao"})
public class AlertService extends TblIdsEntityService<Alert>{
	private static Logger logger = Logger.getLogger(AlertService.class);
	
	
	private AlertDao alertDao = null;
	
	@Inject("refer:alertDao")
	public void setAlertDao(AlertDao alertDao) {
		this.alertDao = alertDao;
	}


	/**
	 * 读取 告警列表 分页
	 * @param condition
	 * @param pager
	 * @return
	 */
	public Pager<Alert> paging(Condition condition, Pager<Alert> pager){
		List<Alert> alertList = query(condition, this.dao().createPager(pager.getPage(), pager.getPageSize()));
		pager.setRecords(this.count(condition));
    	pager.setData(alertList);
		return pager;
		
	}
	
	/**
	 * 根据id查询 告警
	 * @param id
	 * @return
	 */
	public Alert findById(long id){
		Alert alert=this.dao().fetch(getEntityClass(),id);
		return alert;
	}
	
	public Alert fetchAlert(long id){
		return alertDao.fetch(Alert.class,id);
	}
	
	/**
	 * 新增告警
	 * @param alert
	 */
	public Alert insertAlert(Alert alert){
		
		// 添加到告警缓存
		alert = alertDao.insertAlert(alert);
		AlertCache.me().insert(alert);
		return alert;
	}
	
	/**
	 * 修改告警
	 * @param alert
	 */
	public void updateAlert(Alert alert){
		alertDao.update(alert);
	}
	
	/**
	 * 删除选中的告警
	 * @param ids 要删除的告警Id
	 */
	public void deleteAlert(long ... ids){
		alertDao.clear(Alert.class,Cnd.where("id", "in", ids));
	}
	
	/**
	 * 告警处理   可以将告警的状态重置(未处理：0，已处理：1，已确认：2)
	 * @param solution 
	 * @param alert
	 * @return
	 */
	public int updateAlert(Alert.Status status,String userId,String solution, long id){
		Alert alert=this.findById(id);		
		if(alert==null) 
			return 0;
		alert.setStatus(status);
		alert.setSolution(solution);
		alert.setHandledBy(Long.parseLong(userId));
		alert.setTimeHandled(new Date().getTime());//add By HanX_2011_12_02 for BUG1125
		return this.dao().update(alert);
	}
	
	/**
	 * 告警处理   批量处理
	 * @param ids
	 * @param solution 
	 */
	public void updateByIds(Alert.Status status,String userId, String solution, long... ids){
		for(long id:ids){
			this.updateAlert(status,userId, solution,id);
		}
	}
	

	public List<Alert> getAlerts(long startTime,long endTime,boolean isDesc){
		String timeField = "timeCreated";
		Cnd condition = Cnd.where(timeField , ">=", startTime).and(timeField, "<=", endTime);
		if(isDesc){
			condition.desc(timeField);
		}else{
			condition.asc(timeField);
		}
		List<Alert> alertList = query(condition, null);
		
		return alertList;

	}
	
	
	
	
	/**
	 * 资产告警对象
	 * @author zjf
	 *
	 */
	public class AssetAlert implements Comparable<AssetAlert>{
		/**
		 * 资产IP
		 */
		private String assetIp;
		
		/**
		 * 告警等级分布
		 * 按等级分布,key-告警等级,value-告警数量;
		 */
		private LinkedHashMap<String,Integer> priorityCountMap;
		
		AssetAlert(String assetIp,LinkedHashMap<String,Integer> priorityCountMap){
			this.assetIp = assetIp;
			this.priorityCountMap = priorityCountMap;
		}
		
		public String getAssetIp() {
			return assetIp;
		}

		public LinkedHashMap<String, Integer> getPriorityCountMap() {
			return priorityCountMap;
		}

		/**
		 * 得到每个Ip的总告警数
		 * @return
		 */
		private int getCount(){
			int count = 0;
			if(priorityCountMap != null && !priorityCountMap.isEmpty()){
				for(Map.Entry<String,Integer> entry : priorityCountMap.entrySet()){
					Integer value = entry.getValue();
					if(value != null)
						count += value.intValue();
				}
			}
			return count;
		}
		
		/**
		 * 降序排列
		 * @param o2
		 * @return
		 */
		@Override
		public int compareTo(AssetAlert o2) {
			if(o2 == null)
				return 1;
			return  o2.getCount() - this.getCount();
		}
	}
	
	private String getMonitorTypes(String layerKey){
		String result = "";
		Layer layer = Layer.getSupport().getLayerByKey(layerKey);
		List<Layer> layers = layer.getSubLayerList();
		if(layers.size() > 0){
			for(int j = 0 ; j < layers.size(); j++){
				Layer l = layers.get(j);
				List<NodeRef> nrs = l.getNodeRefList();
				for(int i = 0; i < nrs.size(); i++){
					NodeRef nr = nrs.get(i);
					MTypeMeta mtm = BasicDataManager.getInstance().getGlobalDefinitions().getMTypeMeta(nr.getRef());
					result += "'" + mtm.getMTypeId() + "'";
					if(j == layers.size()-1 && i == nrs.size()-1)
						continue;
					result += ",";
				}
			}
		}
		return result;
	}
	
	public List<Map<String, String>> getHistoryAlertTop5(String layerKey){
		Map<String, Map<String, String>> resultMap = new HashMap<String, Map<String, String>>();
		String typesStr = getMonitorTypes(layerKey).trim();
		if(typesStr.endsWith(",")||typesStr.endsWith(";")){
			typesStr = typesStr.substring(0, typesStr.length()-1);
		}
		String countTop = "select count(*), monitorTaskId from corr_alert a, monitor_taskstruct b where monitorTaskId<>'' and a.monitorTaskId = b.id and b.mTypeId in("+ typesStr +") group by monitorTaskId order by monitorTaskId limit 5";
		System.out.println("sql : "+countTop);
		DaoUtil daoUtil = DaoUtil.me();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = daoUtil.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(countTop);
			String top5id = "";
			while(rs.next()){
				String id = rs.getString("monitorTaskId");
				top5id += "'"+id+"',";
			}
			if(top5id.length() > 0){
				top5id = top5id.substring(0, top5id.length()-1);
				String resultSql = "select count(*) as count, priority, monitorTaskId, devname, devip  from corr_alert where monitorTaskId in ("+top5id+") group by monitortaskid, priority";
				rs = stmt.executeQuery(resultSql);
				while(rs.next()){
					String count = rs.getString("count");
					String priority = rs.getString("priority");
					String monitorTaskId = rs.getString("monitorTaskId");
					String devname = rs.getString("devname");
					String devip = rs.getString("devip");
					
					Map<String, String> map = resultMap.get(monitorTaskId);
					if(map == null){
						map = new HashMap<String, String>();
						map.put("name", devname);
						map.put("ip", devip);
						resultMap.put(monitorTaskId, map);
					}
					map.put(priority, count);
				}
			}
		} catch (SQLException e) {
			logger.error(e.getMessage(),e);
		}finally{
			DaoUtil.me().close(conn);
		}
		
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		Set<String> keys = resultMap.keySet();
		Iterator<String> it = keys.iterator();
		while(it.hasNext()){
			Map<String, String> tempMap = resultMap.get(it.next());
			result.add(tempMap);
		}
		return result;
	}
	

	/**
	 * 更新监控器名称时应把告警信息中的相关名称对应修改
	 * @param oldName 原名
	 * @param newName 新名
	 */
	public void updateDevName(String oldName, String newName){
		Connection conn = null;
		Statement stmt = null;
		try {
			conn = DaoUtil.me().getConnection();
			stmt = conn.createStatement();
			stmt.execute("update corr_alert set devName='"+ newName +"' where devName='"+ oldName +"'");
		} catch (SQLException e) {
			logger.error(e.getMessage(),e);
		}finally{
			DaoUtil.me().close(conn);
		}
	}
	
	/**
	 * 告警定时维护
	 * 每晚的0点0时0分开始执行任务
	 * 
	 */
	public void alertMaintain(String maxAlertNum,String maxAlertDays){
		Scheduler scheduler = Scheduler.getDefault();
		MaintainTask task = scheduler.getSchedulerTaskByName(MaintainTask.class, MaintainTask.class.getSimpleName());
		if( task != null){
			scheduler.removeSchedulerTask(MaintainTask.class.getSimpleName());
		}
		int num = Integer.parseInt(maxAlertNum);
		int days = Integer.parseInt(maxAlertDays);
		task = new MaintainTask(num,days);
		
		//首先运行一次
		task.runOnce();
		
		//从当前时间开始,每间隔 24 小时，运行一次 任务
		Calendar taskTime = Calendar.getInstance();
		taskTime.set(Calendar.HOUR_OF_DAY, 0);
		taskTime.set(Calendar.MINUTE, 0);
		taskTime.set(Calendar.SECOND, 0);
		DefaultScheduleIterator schedulerIterator = new DefaultScheduleIterator(
				taskTime, Calendar.HOUR, 24, 0);
		Scheduler.getDefault().schedule(task, schedulerIterator);
	}
	
	/**
	 * 根据时间段查询某一指标的告警
	 * @param concernsEntryId
	 * @param timeBegin
	 * @param timeEnd
	 * @return
	 */
	public List<Alert> getAlertsByconcernsEntryId(Long concernsEntryId,long timeBegin,long timeEnd){
		return alertDao.getAlertsByconcernsEntryId(concernsEntryId,timeBegin,timeEnd);
	}
	
	public List<Alert> getAlertsByMonitorId(Long monitorId,long timeBegin,long timeEnd){
		return alertDao.getAlertsByMonitorId(monitorId, timeBegin, timeEnd);
	}
	
	/**
	 * 获取未处理告警的数量
	 * @param monitorId
	 * @param timeBegin
	 * @param timeEnd
	 * @return
	 */
	public int getUnhandledAlertCount(long monitorId,long timeBegin,long timeEnd){
		Condition cnd = Cnd.where("monitorTaskId", "=", monitorId)
				.and("timeCreated",">=",timeBegin).and("timeCreated","<=",timeEnd)
				.and("status", "=", 0);
		return alertDao.count(Alert.class, cnd);
	}
	
	/**
	 * 告警定时维护任务
	 * 每天晚上凌晨 2 点 进行维护:
	 * 		当告警天数大于 {@link DataMaintain.longday} 时,删除最早的超出天数的数据
	 * 		当告警数量大于 {@link DataMaintain.allnumber} 时,删除最早一天的数据,直到数量满足设置的数目
	 * @author zjf
	 *
	 */
	class MaintainTask extends SchedulerTask{
		private static final long serialVersionUID = -2340349336772661657L;

		long dayInterval = 24 * 3600000;	//1 天的时间间隔
		int maxAlertNum = 0;
		int maxAlertDays = 0;
		
		MaintainTask(int maxAlertNum,int maxAlertDays){
			super(MaintainTask.class.getSimpleName());
			this.maxAlertDays = maxAlertDays;
			this.maxAlertNum = maxAlertNum;
		}
		
		@Override
		public void run() {
			this.runOnce();
		}

		@Override
		public boolean cancel() {
			return true;
		}
		
		/**
		 * 运行一次清除数据任务
		 */
		private void runOnce(){
			//首先删除超时的数据,从当前时间的整点算
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			long time = cal.getTimeInMillis();
			
			Cnd cnd = Cnd.where("timeCreated","<",time - maxAlertDays * dayInterval);
			dao().clear(Alert.class, cnd);
			//判断是否总数超额,如果是,则删除一天的数据
			int count = dao().count(Alert.class);
			while(count > maxAlertNum){
				Connection conn = null;
				Statement stmt = null;
				ResultSet rs = null;
				
				try{
					conn = DaoUtil.me().getConnection();
					stmt = conn.createStatement();
					rs = stmt.executeQuery("select min(timeCreated) from corr_alert");
					if(rs.next()){
						long curTime = rs.getLong(1);
						cal.setTimeInMillis(curTime);
						cal.set(Calendar.HOUR_OF_DAY, 0);
						cal.set(Calendar.MINUTE, 0);
						cal.set(Calendar.SECOND, 0);
						cal.set(Calendar.MILLISECOND, 0);
						stmt.execute("delete from corr_alert where timeCreated < " + (cal.getTimeInMillis() + dayInterval));
						count = dao().count(Alert.class);
					}
				}catch(Exception ex){
					logger.error(ex.getMessage(),ex);
				}finally{
					DaoUtil.me().close(conn);
				}
			}
		}
	}
}

