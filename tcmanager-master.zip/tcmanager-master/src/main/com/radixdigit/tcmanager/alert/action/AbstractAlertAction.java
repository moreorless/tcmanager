
package com.radixdigit.tcmanager.alert.action;

import java.util.Map;

import com.radixdigit.tcmanager.alert.base.IAlertAction;


/**
 * 告警动作抽象类,需要以 Map 方式传递参数的的告警响应动作类需要继承此类
 */
public abstract class AbstractAlertAction implements IAlertAction {
	private static final long serialVersionUID = 7014016893397271308L;
	/*
	 * 执行告警动作需要的参数
	 */
	protected Map<String,String> paras;
	
	public AbstractAlertAction(){
	}

	public AbstractAlertAction(Map<String,String> paras){
		this.paras = paras;
	}
	
	public Map<String, String> getParas() {
		return paras;
	}

	public void setParas(Map<String, String> paras) {
		this.paras = paras;
	}
	
/*	public String me2Json(){
		return Json.toJson(this);
	}
*/}
