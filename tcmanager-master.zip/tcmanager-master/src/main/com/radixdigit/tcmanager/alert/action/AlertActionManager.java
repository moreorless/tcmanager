package com.radixdigit.tcmanager.alert.action;

import java.util.ArrayList;
import java.util.List;

import com.radixdigit.tcmanager.alert.base.IAlertAction;
import com.radixdigit.tcmanager.sysconfig.data.MailBean;
import com.radixdigit.tcmanager.sysconfig.data.ShortMsgBean;
import com.radixdigit.tcmanager.sysconfig.service.SysconfigService;
public class AlertActionManager {

	private static AlertActionManager _instance = new AlertActionManager();
	private AlertActionManager(){}
	public static AlertActionManager me(){
		return _instance;
	}
	
	/**
	 * 读取系统配置的告警动作
	 * @return
	 */
	public List<IAlertAction> getActions(){
		List<IAlertAction> actionList = new ArrayList<>();
		MailBean mailBean = SysconfigService.me().loadMailBean();
		
		if(mailBean.isEnable() && mailBean.getMailTo() != null){
			AlertActionMail mailAction = new AlertActionMail();
			String[] mailToArray = mailBean.getMailTo().split(";");
			List<String> tos = new ArrayList<>();
			for(String mailTo : mailToArray){
				if(mailTo.trim().length() > 0){
					tos.add(mailTo);
				}
			}
			mailAction.setTos(tos);
			actionList.add(mailAction);
		}
		
		ShortMsgBean shortMsgBean = SysconfigService.me().loadShortMsgBean();
		
		if(shortMsgBean.isEnable() && shortMsgBean.getMsgTo() != null){
			String[] phoneArray = shortMsgBean.getMsgTo().split(";");
			List<String> phones = new ArrayList<>();
			for(String phone : phoneArray){
				if(phone.trim().length() > 0){
					phones.add(phone);
				}
			}
			
			AlertActionSM shortMsgAction = new AlertActionSM(phones, "");
			actionList.add(shortMsgAction);
		}
		
		return actionList;
		
	}
	
}
