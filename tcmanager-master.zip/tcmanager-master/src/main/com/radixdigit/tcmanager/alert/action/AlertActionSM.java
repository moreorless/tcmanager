package com.radixdigit.tcmanager.alert.action;

import java.util.List;

import org.apache.log4j.Logger;

import com.radixdigit.tcmanager.alert.base.IAlertAction;
import com.radixdigit.tcmanager.alert.data.Alert;
import com.radixdigit.tcmanager.commons.data.EventObject;
import com.radixdigit.tcmanager.util.ShortMsgImpl;

public class AlertActionSM implements IAlertAction {
	private static final long serialVersionUID = -8272731232173863834L;


	private static Logger logger = Logger.getLogger(AlertActionSM.class);

	
	/**
	 * 电话号码
	 */
	private List<String> phoneNums;
	
	/**
	 * 发送的内容
	 */
	private String content;
	
	public AlertActionSM(){}
	
	public AlertActionSM(List<String> phoneNums,String content){
		this.phoneNums = phoneNums;
		this.content = content;
	}

	@Override
	public boolean action(Alert alert) {
		boolean result = true;
		if(this.phoneNums == null || this.phoneNums.isEmpty())
			return false;
		
		EventObject event = null;
		if(alert != null)
			event = alert.getEvent();
//		if(event != null)
//			content = EventUtil.replaceFieldValue(event, content);
		
		
		for(String phoneNum : phoneNums){
			
			result = ShortMsgImpl.getInstance().sendSM(phoneNum, content);
			
			if(!result)
				return result;
		}
		
		return true;
	}

	@Override
	public String getName() {
		return "alert-action-sm";
	}

/*	@Override
	public String me2Json() {
		String json = Json.toJson(this);
		if(logger.isDebugEnabled())
			logger.debug(getName() + " json:" + json);
		return json;
	}
*/	
	public static void main(String...strings){
		String phone = "13522853073";
		String port = "COM3";
		System.out.println("Example : AlertActionSM COM3");
		if(strings.length >= 1){
			port = strings[0];
		}
		
		//instance.sendMsg(phone, "短消息");
		ShortMsgImpl.testSendSM(phone,port, "短信发送测试: 111111111111111111111111111111111111111111111111111111111111");
		//instance.sendMsg(phone, "看也有一个啊就是是试试在Windows 2000 中，您可以使用“控制面板”中的“任务计划”工具来安排任务。您也可以使用 at 命令手动安排任务。本文介绍如何使用 at 命令创建和取消计划任务在Windows 2000 中，您可以使用“控制面板”中的“任务计划”工具来安排任务。您也可以使用 at 命令手动安排任务。本文介绍如何使用 at 命令创建和取消计划任务在Windows 2000 中，您可以使用“控制面板”中的“任务计划”工具来安排任务。您也可以使用 at 命令手动安排任务。本文介绍如何使用 at 命令创建和取消计划任务在Windows 2000 中，您可以使用“控制面板”中的“任务计划”工具来安排任务。您也可以使用 at 命令手动安排任务。本文介绍如何使用 at 命令创建和取消计划任务over");
	}
}
