package com.radixdigit.tcmanager.alert.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.mail.EmailException;
import org.apache.log4j.Logger;

import com.radixdigit.tcmanager.alert.base.IAlertAction;
import com.radixdigit.tcmanager.alert.data.Alert;
import com.radixdigit.tcmanager.commons.data.EventObject;
import com.radixdigit.tcmanager.util.MailUtil;

/**
 * 告警响应-发送邮件
 * @author zjf
 *
 */
public class AlertActionMail implements IAlertAction {
	private static final long serialVersionUID = 6012898977880214274L;

	private static final Logger logger = Logger.getLogger(AlertActionMail.class);
	
	/**
	 * 接收人列表
	 */
	private List<String> tos;
	/**
	 * subject
	 */
	private String subject;
	/**
	 * mail content
	 */
	private String content;
	
	public AlertActionMail(){}
	
	public AlertActionMail(List<String> tos,String subject,String content) {
		this.tos = tos;
		this.subject = subject;
		this.content = content;
	}

	@Override
	public boolean action(Alert alert) {
		if(tos == null || tos.isEmpty())
			return false;
		EventObject event = null;
		if(alert != null)
			event = alert.getEvent();
		
		for(String to : tos){
			try
			{
				subject = "设备"+ alert.getDevIp() + "异常告警";
				SimpleDateFormat dft=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss E");
				
				String msg = dft.format(new Date(alert.getTimeCreated())) + "  " + subject + " -- " + alert.getDescription();
				
				MailUtil.sendMail(to, subject, msg);
				logger.info("==================================ActionMail has been done==================================");
			}
			catch(EmailException ee)
			{
				logger.error("发送邮件给["+to+"]失败", ee);
			}
		}
		return true;
	}

	@Override
	public String getName() {
		return "alert-action-mail";
	}

	public List<String> getTos() {
		return tos;
	}

	public void setTos(List<String> tos) {
		this.tos = tos;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

/*	@Override
	public String me2Json() {
		// TODO Auto-generated method stub
		return Json.toJson(this);
	}
*/
}
