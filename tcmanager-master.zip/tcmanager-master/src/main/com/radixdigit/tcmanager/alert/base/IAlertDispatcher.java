package com.radixdigit.tcmanager.alert.base;

import com.radixdigit.tcmanager.alert.data.Alert;

/**
 * 告警动作分发器接口
 * @author zjf
 *
 */
public interface IAlertDispatcher {
	/**
	 * 初始化告警动作分发器
	 */
	void init();
	
	/**
	 * 告警动作资源分发回收
	 */
	void destroy();
	
	/**
	 * 将告警动作给告警响应动作列表
	 * @param alert
	 */
	void dispatch(Alert alert);
}
