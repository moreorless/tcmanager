package com.radixdigit.tcmanager.alert.dao;

import java.util.List;

import org.nutz.dao.Cnd;
import org.nutz.dao.impl.NutDao;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.alert.data.Alert;
import com.radixdigit.tcmanager.util.dao.TblMaxIdHelper;


@IocBean(name="alertDao", fields={"dataSource"})
public class AlertDao extends NutDao{
	
	public List<Alert> getAlertsByconcernsEntryId(Long concernsEntryId,long timeBegin,long timeEnd){
		return this.query(Alert.class, Cnd.where("monitorItemId", "=", concernsEntryId).and("timeCreated",">=",timeBegin).and("timeCreated","<=",timeEnd).desc("timeCreated"), null);
	}
	
	public List<Alert> getAlertsByMonitorId(Long monitorId ,long timeBegin,long timeEnd){
		return this.query(Alert.class, Cnd.where("monitorTaskId", "=", monitorId).and("timeCreated",">=",timeBegin).and("timeCreated","<=",timeEnd).desc("timeCreated"));
	}
	
	/**
	 * 添加告警
	 * 
	 * @param alert
	 * @return
	 */
	public Alert insertAlert(Alert alert){
		
		long id = TblMaxIdHelper.getTblMaxIdWithUpdate(this,
				Alert.class);
		
		alert.setId(id);
		
		return this.insert(alert);
	}
	
}
