package com.radixdigit.tcmanager.alert.module;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.catalina.connector.Request;
import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.dao.sql.OrderBy;
import org.nutz.dao.util.cri.SqlExpressionGroup;
import org.nutz.ioc.annotation.InjectName;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.lang.Mirror;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Chain;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.Param;

import com.radixdigit.tcmanager.alert.data.Alert;
import com.radixdigit.tcmanager.alert.service.AlertService;
import com.radixdigit.tcmanager.annotation.AuthBy;
import com.radixdigit.tcmanager.commons.mvc.Pager;
import com.radixdigit.tcmanager.sysconfig.data.AlertParamBean;
import com.radixdigit.tcmanager.sysconfig.data.MailBean;
import com.radixdigit.tcmanager.sysconfig.data.ShortMsgBean;
import com.radixdigit.tcmanager.sysconfig.service.SysconfigService;

@IocBean
@InjectName
@AuthBy(check=false)
@At("/alert")
public class AlertModule {

	@Inject
	AlertService alertService;
	@At
	@Ok("jsp:jsp.alert.main")
	public void main(HttpServletRequest request){
		long endTime = System.currentTimeMillis();
		long startTime = endTime - 24*3600*1000;
		List<Alert> alertList = alertService.getAlerts(startTime, endTime, true);
		request.setAttribute("alertList", alertList);
	}
	
	/**
	 * 读取告警列表
	 * @param request
	 * @param startTime	起始时间
	 * @param endTime	结束时间
	 * @param range		时间范围(hour/day/week/month/3month/year/custom)
	 */
	@At
	@Ok("jsp:jsp.alert.alertlist")
	public Pager<Alert> list(HttpServletRequest request, @Param("monitorId") long monitorId,
			@Param("startTime") long startTime, @Param("endTime") long endTime, @Param("range") String range,
			@Param("..") Pager<Alert> pager){
		
		if(!"custom".equals(range)){
			endTime = System.currentTimeMillis();
			long millisInHour = 3600 * 1000;
			switch (range) {
			case "hour":
				startTime = endTime - millisInHour;
				break;
			case "day":
				startTime = endTime - 24 * millisInHour;
				break;
			case "week":
				startTime = endTime - 7 * 24 * millisInHour;
				break;
			case "month":
				startTime = endTime - 30 * 24 * millisInHour;
				break;	
			case "3month":
				startTime = endTime - 3 * 30 * 24 * millisInHour;
				break;	
			case "year":
				startTime = endTime - 365 * 24 * millisInHour;
				break;	
			default:		// 默认显示1天的告警
				startTime = endTime - 24 * millisInHour;
				break;
			}
		}
		
		SqlExpressionGroup el = Cnd.exps("timeCreated",">=",startTime).and("timeCreated","<=",endTime);
		if(monitorId > 0){
			el.and("monitorTaskId", "=", monitorId);
		}
		
		Condition condition = Cnd.where(el);
		/* ++++++++ 除了排序以外的条件应该在这里组装 +++++++++ */		
		/* +++++++++++++++++++++++++++++++++++++++++++++++++++ */		
		//在这里组织好查询所需的条件			
		if(pager.getSidx()!= null){
			Mirror.me(OrderBy.class).invoke(condition, pager.getSord(),pager.getSidx());
		}else{
			condition = Cnd.where(el).desc("timeCreated");
		}
		
		
		return alertService.paging(condition, pager);
	}
	
	/**
	 * 告警动作配置
	 */
	@At
	@Ok("jsp:jsp.alert.actionconfig")
	public void actionConfig(HttpServletRequest request){
		// 邮件配置
		MailBean mailBean = SysconfigService.me().loadMailBean();
		request.setAttribute("mailBean", mailBean);
		
		// 短信配置
		ShortMsgBean shortMsgBean = SysconfigService.me().loadShortMsgBean();
		request.setAttribute("shortMsgBean", shortMsgBean);
	}
	
	/**
	 * 保存告警动作配置
	 * @param mailBean
	 * @param shortMsgBean
	 */
	@At
	@Chain("validate")
	@Ok("json")
	public void saveActions(@Param("::mailBean.") MailBean mailBean, @Param("::shortMsgBean.") ShortMsgBean shortMsgBean){
		SysconfigService.me().saveMail(mailBean);
		SysconfigService.me().saveShortMsg(shortMsgBean);
	}
	
	/**
	 * 告警参数设置
	 * @param request
	 */
	@At
	@Ok("jsp:jsp.alert.paramconfig")
	public void paramConfig(HttpServletRequest request){
		AlertParamBean alertParam = SysconfigService.me().loadAlertParam();
		request.setAttribute("alertParam", alertParam);
	}
	
	@At
	@Chain("validate")
	@Ok("json")
	public void saveAlertParam(@Param("::alertParam.")AlertParamBean alertParam){
		SysconfigService.me().saveAlertParam(alertParam);
	}
}
