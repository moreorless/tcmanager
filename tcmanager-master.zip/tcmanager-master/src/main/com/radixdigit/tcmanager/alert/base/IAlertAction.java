package com.radixdigit.tcmanager.alert.base;

import java.io.Serializable;

import com.radixdigit.tcmanager.alert.data.Alert;


/**
 * 告警处理接口,所有的告警处理、都应该实现此接口,比如告警动作、存贮告警
 * 注意所有实现类均应该有缺省构造函数(WebService 调用时要求)
 *
 */
public interface IAlertAction extends Serializable{
	
	/**
	 * 返回告警响应动作名称
	 * @return
	 */
	public String getName();
	
	/**
	 * 执行告警动作
	 * @param alert 告警对象
	 * @return
	 */
	public boolean action(Alert alert);
	
	
	//public String me2Json();
}
