package com.radixdigit.tcmanager.alert.data;

import java.io.Serializable;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

import com.radixdigit.tcmanager.commons.data.EventObject;

/**
 * 告警对象,跟告警表对应对应
 * @author zjf
 *
 */
@Table("corr_alert")
public class Alert implements Serializable {
	private static final long serialVersionUID = 6934348359667136976L;

	@Column
	@Id(auto=false)
	private long id;

	/**
	 * 关联规则Id,由哪个关联规则引起的告警
	 */
	@Column
	private String ruleId;
	
	/**
	 * 关联事件Id,由哪些相关事件引起的告警,多个Id以逗号分隔
	 */
	@Column
	private String eventIds;

	/**
	 * 关联业务Id,多个Id以逗号分隔
	 */
	@Column
	private String businessIds;

	/**
	 * 关联资产ID,多个Id以逗号分隔
	 */
	@Column
	private long assetId;

	/**
	 * 关联资产所属网络区域
	 */
	@Column
	private String assetDistrict;
	
	/**
	 * 告警名称
	 */
	@Column
	private String title;
	
	/**
	 * 告警等级
	 */
	@Column
	private int priority;
	
	/**
	 * 设备IP
	 */
	@Column
	private String devIp;
	
	/**
	 * 设备类型
	 */
	@Column
	private String devType;
	
	/**
	 * 设备名称
	 */
	@Column
	private String devName;
	
	/**
	 * 告警分类
	 */
	@Column
	private String alertType;
	
	/**
	 * 告警来源
	 */
	@Column
	@ColDefine(type=ColType.INT, width=1)
	private Type alertSrc = Type.EVENT;
	
	/**
	 * 监控任务Id
	 */
	@Column
	private long monitorTaskId;
	
	/**
	 * 监控指标 Id
	 */
	@Column
	private long monitorItemId;
	
	/**
	 * 处理状态
	 */
	@Column
	@ColDefine(type=ColType.INT, width=1)
	private Status status = Status.NOT_HANDLED;
	
	/**
	 * 处理情况描述
	 */
	@Column
	private String solution;
	
	/**
	 * 处理者
	 */
	@Column
	private long handledBy;
	
	/**
	 * 处理时间
	 */
	@Column
	private long timeHandled;
	
	@Column
	private long timeCreated = System.currentTimeMillis();

	/**
	 * 引发告警的最后一条事件
	 */
	private EventObject event;
	
	/**
	 * 描述
	 */
	@Column
	private String description;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public String getEventIds() {
		return eventIds;
	}

	public void setEventIds(String eventIds) {
		this.eventIds = eventIds;
	}

	public String getBusinessIds() {
		return businessIds;
	}

	public void setBusinessIds(String businessIds) {
		this.businessIds = businessIds;
	}

	public long getAssetId() {
		return assetId;
	}

	public void setAssetId(long assetId) {
		this.assetId = assetId;
	}

	public String getTitle() {
		return title;
	}

	public String getAssetDistrict() {
		return assetDistrict;
	}

	public void setAssetDistrict(String assetDistrict) {
		this.assetDistrict = assetDistrict;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getDevIp() {
		return devIp;
	}

	public void setDevIp(String devIp) {
		this.devIp = devIp;
	}

	public String getDevType() {
		return devType;
	}

	public void setDevType(String devType) {
		this.devType = devType;
	}

	public String getDevName() {
		return devName;
	}

	public void setDevName(String devName) {
		this.devName = devName;
	}

	public String getAlertType() {
		return alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}

	public Type getAlertSrc() {
		return alertSrc;
	}

	public void setAlertSrc(Type alertSrc) {
		this.alertSrc = alertSrc;
	}

	public long getMonitorTaskId() {
		return monitorTaskId;
	}

	public void setMonitorTaskId(long monitorTaskId) {
		this.monitorTaskId = monitorTaskId;
	}

	public long getMonitorItemId() {
		return monitorItemId;
	}

	public void setMonitorItemId(long monitorItemId) {
		this.monitorItemId = monitorItemId;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

	public long getHandledBy() {
		return handledBy;
	}

	public void setHandledBy(long handledBy) {
		this.handledBy = handledBy;
	}

	public long getTimeHandled() {
		return timeHandled;
	}

	public void setTimeHandled(long timeHandled) {
		this.timeHandled = timeHandled;
	}

	public long getTimeCreated() {
		return timeCreated;
	}

	public void setTimeCreated(long timeCreated) {
		this.timeCreated = timeCreated;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public EventObject getEvent() {
		return event;
	}

	public void setEvent(EventObject event) {
		this.event = event;
	}

	/**
	 * 告警来源
	 */
	public static enum Type{
		/**
		 * 监控
		 */
		MONITOR,
		/**
		 * 事件
		 */
		EVENT,
		/**
		 * 风险计算
		 */
		RISK,
		/**
		 * 态势
		 */
		SITUATION,
		/**
		 * 基线产品产生的告警
		 */
		CVS,
		/**
		 * 其他
		 */
		OTHER
	}

	/**
	 * 处理状态
	 */
	public static enum Status{
		/**
		 * 未处理
		 */
		NOT_HANDLED,
		/**
		 * 已处理
		 */
		HANDLED
	}
}
