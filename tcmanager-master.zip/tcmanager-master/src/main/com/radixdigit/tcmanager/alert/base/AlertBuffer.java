package com.radixdigit.tcmanager.alert.base;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.nutz.lang.Strings;

import com.radixdigit.tcmanager.alert.data.Alert;


/**
 * 告警缓存
 * @author zjf
 *
 */
public class AlertBuffer{
	private static final Logger logger = Logger.getLogger(AlertBuffer.class);
	
	/**
	 * 最近发生的告警缓存,最大缓存 1000 条
	 */
	private static final int MAX_NUM = 1000;
	
	/**
	 * 每个告警响应动作中指定的用户对应的告警缓存最大容量 
	 */
	private static final int MAX_NUM_BY_USER = 10;
	
	/**
	 * 最近发生的告警缓存,最大缓存数由 {@link MAX_NUM}决定
	 * 最新的告警放在第一条
	 */
	private static LinkedList<Alert> alertBuffer = new LinkedList<Alert>();
	
	/**
	 * 每个用户对应的告警缓存
	 * 当告警响应动作为弹出对话框时,需要选择接收的用户,选择的每个用户对应一个告警列表
	 */
	private static Map<String,LinkedList<Alert>> userAlertBuffer = new HashMap<String,LinkedList<Alert>>();
	
	private AlertBuffer(){};
	
	/**
	 * 将告警添加到缓存,缓存包括两个: 最近告警缓存与用户告警缓存
	 * @param alert
	 */
	public static void addAlert(Alert alert){
		//添加到最近发生的告警缓存
		synchronized(alertBuffer){
			if(alertBuffer.size() >= MAX_NUM)
				alertBuffer.removeLast();
			alertBuffer.addFirst(alert);
		}
	}
	
	/**
	 * 添加告警到用户缓存
	 * 可能存在的问题:当动作修改后,使当前用户不在动作指定的用户列表中时,用户缓存并不会被清除
	 * @param userId 用户 Id
	 * @param alert 告警对象
	 */
	public static void addUserAlert(String userId,Alert alert){
		if(Strings.isBlank(userId))
			return;
		
		synchronized(userAlertBuffer){
			LinkedList<Alert> list = userAlertBuffer.get(userId);
			if(list == null){
				list = new LinkedList<Alert>();
			}
			if(list.size() >= MAX_NUM_BY_USER)
				list.removeLast();
			list.addFirst(alert);
			userAlertBuffer.put(userId, list);
		}
		
	}
	
	/**
	 * 当前最近的告警缓存
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Alert> getLatestAlerts(){
		List<Alert> result = null;
		try{
			result = (List<Alert>)alertBuffer.clone();
		}catch(Exception ex){
			logger.error(ex.getMessage());
		}
		return result;
	}
	
	/**
	 * 得到用户Id相关的告警缓存
	 * @param userId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Alert> getLatestAlertsByUserId(String userId){
		List<Alert> result = null;
		try{
			result = (List<Alert>)userAlertBuffer.get(userId).clone();
		}catch(Exception ex){
			logger.error(ex.getMessage());
		}
		return result;
	}
	
	/**
	 * 删除指定用户告警缓存中的指定告警
	 * @param userId 用户Id
	 * @param alertId 告警Id
	 */
	public static void removeAlertByUserId(String userId,long alertId){
		synchronized(userAlertBuffer){
			List<Alert> list = (List<Alert>)userAlertBuffer.get(userId);
			for(Alert alert : list){
				if(alert.getId() == alertId){
					list.remove(alert);
					break;
				}
			}
		}
	}
	
	/**
	 * 删除指定用户的所有告警,用户被删除时应该同时调用此方法
	 * @param userId
	 */
	public static void removeAllAlertsByUserId(String userId){
		if(Strings.isBlank(userId))
			return;
		synchronized(userAlertBuffer){
			userAlertBuffer.remove(userId);
		}
	}
}
