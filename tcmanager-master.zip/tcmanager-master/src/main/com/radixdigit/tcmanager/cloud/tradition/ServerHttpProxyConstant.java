package com.radixdigit.tcmanager.cloud.tradition;

import java.util.regex.Pattern;

public class ServerHttpProxyConstant {

    /**
     * Key for content length header.
     */
    public static String HEADER_NAME_CONTENT_LENGTH = "Content-Length";
    
    public static String HEADER_NAME_SERVER_HTTP_PROXY_CONTEXT = "HTTP-SERVER-PROXY-CONTEXT";
    /**
     * Key for host header
     */
    public static String STRING_HOST_HEADER_NAME = "Host";
    
    public static String STRING_COOKIE_HEADER_NAME = "Cookie";
    
    public static String STRING_SET_COOKIE_HEADER_NAME = "Set-Cookie";
    
    public static String STRING_SESSION_ID_NAME = "JSESSIONID";
    
    public static String STRING_PROXY_NODE_SESSION_KEY = "PROXY-NODES";
    
	/**
	 * The maximum size for uploaded files in bytes. Default value is 5MB.
	 */
    public static int SIZE_FILE_UPLOAD_MAX = 5 * 1024 * 1024;

	public static final Pattern COOKIE_PATTERN = Pattern.compile("(\\w+)\\s*(=\\s*\"?(\\w+)\"?)?\\s*(;|$)");
	
	public static final Pattern SKIN_COOKIE_PATTERN = Pattern.compile("(SKIN\\s*=\\s*\"?\\w+\"?)\\s*(;|$)");
	
	public static String STRING_SIGNOUT_PATH = "/signout";
	
	public static String STRING_SIGNOUT_REDIRECT_PAGE = "/WEB-INF/jsp/cluster/signout.jsp";
	
}
