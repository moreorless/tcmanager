package com.radixdigit.tcmanager.annotation;

import com.radixdigit.tcmanager.auth.matcher.PermissionMatcher;


public @interface MatchBy {

	Class<? extends PermissionMatcher> value();
	
	String ioc() default "";
}
