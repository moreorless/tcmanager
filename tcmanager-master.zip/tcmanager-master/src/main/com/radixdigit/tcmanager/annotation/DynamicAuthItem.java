package com.radixdigit.tcmanager.annotation;

public @interface DynamicAuthItem {

	String key() default "";
	
	AuthBy by();
	
}
