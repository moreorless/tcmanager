/**
 
 * Author: wangxh
 * Created: 2011-6-3
 */
package com.radixdigit.tcmanager.asset.dao.node;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.dao.Sqls;
import org.nutz.dao.sql.Sql;
import org.nutz.dao.util.cri.SqlExpressionGroup;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.dao.group.ManageGroupDao;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.asset.data.NodeQueryCnd;
import com.radixdigit.tcmanager.asset.data.node.Asset;
import com.radixdigit.tcmanager.asset.data.node.AssetInterface;
import com.radixdigit.tcmanager.asset.util.IpUtil;
import com.radixdigit.tcmanager.commons.mvc.Pager;
import com.radixdigit.tcmanager.util.IPComparatorHandler;

/**
 * @author wangxh
 * 
 */

@IocBean(name = "assetDao", fields = { "dataSource" })
public class AssetDao extends NodeDao<Asset> {

	@Inject
	private ManageGroupDao manageGroupDao;
	
	//-------以下为扩充方法
	/**
	 * 获取属于某类型的所有资产
	 * 
	 * @param id
	 * @return
	 */
	public Pager<Asset> queryByTypeId(long assetTypeId, Pager<Asset> pager) {
		Condition cnd = Cnd.where("type", "=", assetTypeId);
		return enPager(pager, cnd);
	}

	/**
	 * 获取属于某类型的所有资产
	 * 
	 * @param id
	 * @return
	 */
	public Pager<Asset> queryByTypeId(long assetTypeId, Condition cnd, Pager<Asset> pager) {
		Condition appendCnd = Cnd.where("type", "=", assetTypeId);
		
		return enPager(pager, mergeCondition(cnd, appendCnd));
	}
	
	/**
	 * 根据被删除的资产ID，更新资产主从关系
	 * 
	 * @param ids
	 */
	public void updateByDeletedId(long... ids) {
		Sql sql = Sqls
				.create("UPDATE asset SET masterId='0',innerRelation='0' where masterId in $ids");
		StringBuffer sb = new StringBuffer();
		sb.append("(");
		for (long id : ids) {
			sb.append(id);
			sb.append(",");
		}
		sb.deleteCharAt(sb.lastIndexOf(","));
		sb.append(")");
		sql.vars().set("ids", sb.toString());
		this.execute(sql);
	}

	/**
	 * 构造资产查询条件
	 * 
	 * @param nqc
	 * @param bRecurse 是否进行组递归查询
	 * @return
	 */
	public Condition createCnd(NodeQueryCnd nqc, boolean bRecurse,int view) {

		long id = nqc.getId();
		String ip = nqc.getIp();
		String interfaceIp = nqc.getInterfaceIp();
		String name = nqc.getName();
		String mac = nqc.getMac();
		String contact = nqc.getContact();
		String netDistrict = nqc.getNetDistrict();
		long type = nqc.getType();
		int manageSwitch = nqc.getManageSwitch();
		String alias=nqc.getAlias();
		String assetCode=nqc.getAssetCode();
		String sn=nqc.getSn();
		String location=nqc.getLocation();
		String manufact=nqc.getManufacturer();
		int virtualType=nqc.getVirtualType();
		int valueLower=nqc.getValueLowwer();
		int valueUpper=nqc.getValueUpper();
		int protLower=nqc.getProtectLowwer();
		int protUpper=nqc.getProtectUpper();
		String typeIds=nqc.getTypeids();	
		String startIp=nqc.getIpRangeStart();
		String endIp=nqc.getIpRangeEnd();
		
		SqlExpressionGroup e = null;
		//资产ID
		if (id > 0) {
			return Cnd.where("id", "=", id);
		}
		//资产名称
		if (name != null && name.length() > 0) {
			e = Cnd.exps("name", "like", "%" + name + "%");
		}
		//资产别名
		if(alias!=null&&!alias.equals("")){
			SqlExpressionGroup ealias =Cnd.exps("alias","like","%"+alias+"%");
			e = (e == null) ? ealias : e.and(ealias);
		}
		//资产编码
		if(assetCode!=null&&!assetCode.equals("")){
			SqlExpressionGroup ec=Cnd.exps("assetCode","=",assetCode);
			e = (e == null) ? ec : e.and(ec);
		}
		//序列号
		if(sn!=null&&!sn.equals("")){
			SqlExpressionGroup ec=Cnd.exps("sn","=",sn);
			e = (e == null) ? ec : e.and(ec);
		}
		//地理位置
		if(location!=null&&!location.equals("")){
			SqlExpressionGroup ec=Cnd.exps("location","like","%"+location+"%");
			e = (e == null) ? ec : e.and(ec);
		}
		//制造商
		if(manufact!=null&&!manufact.equals("")){
			SqlExpressionGroup ec=Cnd.exps("manufacturer","like","%"+manufact+"%");
			e = (e == null) ? ec : e.and(ec);
		}
		//是否虚拟机资产
		if(virtualType>-1){
			SqlExpressionGroup ec=Cnd.exps("virtualType","=",virtualType);
			e = (e == null) ? ec : e.and(ec);
		}
		//等保等级
		if(protLower>0&&protUpper>0){
			SqlExpressionGroup ec=null;
			if(protLower!=protUpper){
				if(protLower<protUpper){
					ec=Cnd.exps("protectLevel",">=",protLower).and("protectLevel","<=",protUpper);
				}else{
					ec=Cnd.exps("protectLevel",">=",protUpper).and("protectLevel","<=",protLower);
				}
			}else{
				ec=Cnd.exps("protectLevel","=",protLower);
			}
			e = (e == null) ? ec : e.and(ec);
		}
		//价值
		if(valueLower>0&&valueUpper>0){
			SqlExpressionGroup ec=null;
			if(valueLower!=valueUpper){
				if(valueLower<valueUpper){
					ec=Cnd.exps("value",">=",valueLower).and("value","<=",valueUpper);
				}else{
					ec=Cnd.exps("value",">=",valueUpper).and("value","<=",valueLower);
				}
			}else{
				ec=Cnd.exps("value","=",valueLower);
			}
			e = (e == null) ? ec : e.and(ec);
		}
		//mac
		if (mac != null && mac.length() > 0) {
			SqlExpressionGroup eMac = Cnd.exps("mac", "=", mac);
			e = (e == null) ? eMac : e.and(eMac);
		}
		//联系人
		if (contact != null && contact.length() > 0) {
			SqlExpressionGroup eContact = Cnd.exps("contact", "=", contact);
			e = (e == null) ? eContact : e.and(eContact);
		}
		//
		if (netDistrict != null && netDistrict.length() > 0) {
			SqlExpressionGroup eDistrict = Cnd.exps("netDistrict", "=", netDistrict);
			e = (e == null) ? eDistrict : e.and(eDistrict);
		}
		//资产类型
		if (type > 0) {
			SqlExpressionGroup eType = Cnd.exps("type", "=", type);
			e = (e == null) ? eType : e.and(eType);
		}
		//多个资产类型
		if(typeIds!=null && !typeIds.equals("")){
			String[] typeArr=typeIds.split(",");
			SqlExpressionGroup eType = Cnd.exps("type", "IN", typeArr);
			e = (e == null) ? eType : e.and(eType);
		}
		//管理开关：资产是否接受管理
		if(manageSwitch>-1){
			SqlExpressionGroup eSwitch = Cnd.exps("manageSwitch", "=", manageSwitch);
			e = (e == null) ? eSwitch : e.and(eSwitch);
		}
		//判断ip范围
		if((startIp!=null && !startIp.equals(""))&& (endIp!=null && !endIp.equals(""))){
			if(startIp.equals(endIp)){
				nqc.setIp(startIp);
			}else{//IP分段查询
				SqlExpressionGroup eIp1 = null;
				try{
					String strIpNum=IpUtil.buildKey(startIp);
					String endIpNum=IpUtil.buildKey(endIp);
					if(strIpNum.compareToIgnoreCase(endIpNum)>0){
						eIp1=Cnd.exps("ipHexadecimal", "<=", strIpNum).and("ipHexadecimal", ">=", endIpNum);
					}else{
						eIp1=Cnd.exps("ipHexadecimal", ">=", strIpNum).and("ipHexadecimal", "<=", endIpNum);
					}
					if(eIp1!=null){
						e = (e == null) ? eIp1 : e.and(eIp1);
					}
				}catch(Exception ex){
					ex.printStackTrace();
				}
			}
		}else if((startIp!=null && !startIp.equals(""))&& (endIp==null || endIp.equals(""))){
			nqc.setIp(startIp);
		}else if((startIp==null || startIp.equals(""))&& (endIp!=null && !endIp.equals(""))){
			nqc.setIp(endIp);
		}
		//IP单个查询
		if (nqc.getIp() != null && nqc.getIp().length() > 0) {
			SqlExpressionGroup eIp1 = Cnd.exps("ip", "=", nqc.getIp());
			e = (e == null) ? eIp1 : e.and(eIp1);
		}
		if (interfaceIp != null && interfaceIp.length() > 0){
			String[] ips = interfaceIp.split(",");
			SqlExpressionGroup inquery = Cnd.exps("ip", "IN", ips);
			List<AssetInterface> interfaces = this.query(AssetInterface.class,
					Cnd.where(inquery), null);
			if (interfaces != null && interfaces.size() > 0) {
				long[] assetIds = new long[interfaces.size()];
				for (int i = 0; i < assetIds.length; i++) {
					assetIds[i] = interfaces.get(i).getAssetId();
				}
				SqlExpressionGroup eIp2 = Cnd.exps("id", "IN", assetIds);
				e = (e == null) ? eIp2 : e.and(eIp2);
			}else{
				e = Cnd.exps("1", ">", "2");
			}
			return Cnd.where(e);
		}
		long curGroupId = nqc.getGroupId();
		if(view==NodeConstant.VIEW_MANAGE){
			if(nqc.getOperate()!=null && nqc.getOperate().equals("add")){//如果是新增资产，查询资产库
				SqlExpressionGroup eGroup = Cnd.exps("manageGroupId", "!=", curGroupId);
				e = (e == null) ? eGroup : e.and(eGroup);		
			}else{
				if(bRecurse){	// 组递归
					/*if(curGroupId != NodeConstant.MANAGE_ROOT_ID){*/
						
						// 需要进行管理组过滤， 获取所有子组id
						List<NodeProxy> subGroupProxys = manageGroupDao.querySubGroupProxyRecurse(curGroupId);
						long[] groupIds = new long[subGroupProxys.size() + 1];
						groupIds[0] = curGroupId;
						int i = 1;
						Iterator<NodeProxy> iter = subGroupProxys.iterator();
						while(iter.hasNext()){
							groupIds[i++] = iter.next().getNodeId();
						}
						
						SqlExpressionGroup eGroup = Cnd.exps("manageGroupId", "in", groupIds);
						e = (e == null) ? eGroup : e.and(eGroup);
					/*}else{//查询所有资产
						SqlExpressionGroup eGroup = Cnd.exps("1", "=", "1");
						e = (e == null) ? eGroup : e.and(eGroup);
					}*/
					
				}else{			// 仅查询当前组
					SqlExpressionGroup eGroup = Cnd.exps("manageGroupId", "=", curGroupId);
					e = (e == null) ? eGroup : e.and(eGroup);
				}
			}
		}
		if(e==null){
			SqlExpressionGroup eGroup = Cnd.exps("1", ">", 2);
			e = (e == null) ? eGroup : e.and(eGroup);
		}
		return Cnd.where(e);
	}
	
	/**
	 * 构造资产查询条件
	 * 
	 * @param nqc
	 * @param bRecurse 是否进行组递归查询
	 * @return
	 */
	public Condition createCnd(NodeQueryCnd nqc, boolean bRecurse,int view,String assetTypecode) {

		long id = nqc.getId();
		String ip = nqc.getIp();
		String interfaceIp = nqc.getInterfaceIp();
		String name = nqc.getName();
		String mac = nqc.getMac();
		String contact = nqc.getContact();
		String netDistrict = nqc.getNetDistrict();
		long type = nqc.getType();
		int manageSwitch = nqc.getManageSwitch();
		String alias=nqc.getAlias();
		String assetCode=nqc.getAssetCode();
		String sn=nqc.getSn();
		String location=nqc.getLocation();
		String manufact=nqc.getManufacturer();
		int virtualType=nqc.getVirtualType();
		int valueLower=nqc.getValueLowwer();
		int valueUpper=nqc.getValueUpper();
		int protLower=nqc.getProtectLowwer();
		int protUpper=nqc.getProtectUpper();
		String typeIds=nqc.getTypeids();	
		String startIp=nqc.getIpRangeStart();
		String endIp=nqc.getIpRangeEnd();
		
		SqlExpressionGroup e = null;
		//资产ID
		if (id > 0) {
			return Cnd.where("id", "=", id);
		}
		//资产名称
		if (name != null && name.length() > 0) {
			e = Cnd.exps("name", "like", "%" + name + "%");
		}
		//资产别名
		if(alias!=null&&!alias.equals("")){
			SqlExpressionGroup ealias =Cnd.exps("alias","like","%"+alias+"%");
			e = (e == null) ? ealias : e.and(ealias);
		}
		//资产编码
		if(assetCode!=null&&!assetCode.equals("")){
			SqlExpressionGroup ec=Cnd.exps("assetCode","=",assetCode);
			e = (e == null) ? ec : e.and(ec);
		}
		//序列号
		if(sn!=null&&!sn.equals("")){
			SqlExpressionGroup ec=Cnd.exps("sn","=",sn);
			e = (e == null) ? ec : e.and(ec);
		}
		//地理位置
		if(location!=null&&!location.equals("")){
			SqlExpressionGroup ec=Cnd.exps("location","like","%"+location+"%");
			e = (e == null) ? ec : e.and(ec);
		}
		//制造商
		if(manufact!=null&&!manufact.equals("")){
			SqlExpressionGroup ec=Cnd.exps("manufacturer","like","%"+manufact+"%");
			e = (e == null) ? ec : e.and(ec);
		}
		//是否虚拟机资产
		if(virtualType>-1){
			SqlExpressionGroup ec=Cnd.exps("virtualType","=",virtualType);
			e = (e == null) ? ec : e.and(ec);
		}
		//等保等级
		if(protLower>0&&protUpper>0){
			SqlExpressionGroup ec=null;
			if(protLower!=protUpper){
				if(protLower<protUpper){
					ec=Cnd.exps("protectLevel",">=",protLower).and("protectLevel","<=",protUpper);
				}else{
					ec=Cnd.exps("protectLevel",">=",protUpper).and("protectLevel","<=",protLower);
				}
			}else{
				ec=Cnd.exps("protectLevel","=",protLower);
			}
			e = (e == null) ? ec : e.and(ec);
		}
		//价值
		if(valueLower>0&&valueUpper>0){
			SqlExpressionGroup ec=null;
			if(valueLower!=valueUpper){
				if(valueLower<valueUpper){
					ec=Cnd.exps("value",">=",valueLower).and("value","<=",valueUpper);
				}else{
					ec=Cnd.exps("value",">=",valueUpper).and("value","<=",valueLower);
				}
			}else{
				ec=Cnd.exps("value","=",valueLower);
			}
			e = (e == null) ? ec : e.and(ec);
		}
		//mac
		if (mac != null && mac.length() > 0) {
			SqlExpressionGroup eMac = Cnd.exps("mac", "=", mac);
			e = (e == null) ? eMac : e.and(eMac);
		}
		//联系人
		if (contact != null && contact.length() > 0) {
			SqlExpressionGroup eContact = Cnd.exps("contact", "=", contact);
			e = (e == null) ? eContact : e.and(eContact);
		}
		//
		if (netDistrict != null && netDistrict.length() > 0) {
			SqlExpressionGroup eDistrict = Cnd.exps("netDistrict", "=", netDistrict);
			e = (e == null) ? eDistrict : e.and(eDistrict);
		}
		//资产类型
		if (type > 0) {
			SqlExpressionGroup eType = Cnd.exps("type", "=", type);
			e = (e == null) ? eType : e.and(eType);
		}
		//多个资产类型
		if(typeIds!=null && !typeIds.equals("")){
			String[] typeArr=typeIds.split(",");
			SqlExpressionGroup eType = Cnd.exps("type", "IN", typeArr);
			e = (e == null) ? eType : e.and(eType);
		}
		//管理开关：资产是否接受管理
		if(manageSwitch>-1){
			SqlExpressionGroup eSwitch = Cnd.exps("manageSwitch", "=", manageSwitch);
			e = (e == null) ? eSwitch : e.and(eSwitch);
		}
		//判断ip范围
		if((startIp!=null && !startIp.equals(""))&& (endIp!=null && !endIp.equals(""))){
			if(startIp.equals(endIp)){
				nqc.setIp(startIp);
			}else{//IP分段查询
				SqlExpressionGroup eIp1 = null;
				try{					
					String strIpNum=IpUtil.buildKey(startIp);
					String endIpNum=IpUtil.buildKey(endIp);
					if(strIpNum.compareToIgnoreCase(endIpNum)<0){
						eIp1=Cnd.exps("ipHexadecimal", ">=", strIpNum).and("ipHexadecimal", "<=", endIpNum);
					}else{
						eIp1=Cnd.exps("ipHexadecimal", "<=", strIpNum).and("ipHexadecimal", ">=", endIpNum);
					}
					if(eIp1!=null){
						e = (e == null) ? eIp1 : e.and(eIp1);
					}
				}catch(Exception ex){
					ex.printStackTrace();
				}
			}
		}else if((startIp!=null && !startIp.equals(""))&& (endIp==null || endIp.equals(""))){
			nqc.setIp(startIp);
		}else if((startIp==null || startIp.equals(""))&& (endIp!=null && !endIp.equals(""))){
			nqc.setIp(endIp);
		}
		//IP单个查询
		if (nqc.getIp() != null && nqc.getIp().length() > 0) {
			SqlExpressionGroup eIp1 = Cnd.exps("ip", "=", nqc.getIp());
			e = (e == null) ? eIp1 : e.and(eIp1);
		}
		if (interfaceIp != null && interfaceIp.length() > 0){
			String[] ips = interfaceIp.split(",");
			SqlExpressionGroup inquery = Cnd.exps("ip", "IN", ips);
			List<AssetInterface> interfaces = this.query(AssetInterface.class,
					Cnd.where(inquery), null);
			if (interfaces != null && interfaces.size() > 0) {
				long[] assetIds = new long[interfaces.size()];
				for (int i = 0; i < assetIds.length; i++) {
					assetIds[i] = interfaces.get(i).getAssetId();
				}
				SqlExpressionGroup eIp2 = Cnd.exps("id", "IN", assetIds);
				e = (e == null) ? eIp2 : e.and(eIp2);
			}else{
				e = Cnd.exps("1", ">", "2");
			}
			return Cnd.where(e);
		}
		long curGroupId = nqc.getGroupId();
		if(view==NodeConstant.VIEW_MANAGE){
			if(nqc.getOperate()!=null && nqc.getOperate().equals("add")){//如果是新增资产，查询资产库
				SqlExpressionGroup eGroup = Cnd.exps("manageGroupId", "!=", curGroupId);
				e = (e == null) ? eGroup : e.and(eGroup);		
			}else{
				if(bRecurse){	// 组递归
					/*if(curGroupId != NodeConstant.MANAGE_ROOT_ID){*/
						
						// 需要进行管理组过滤， 获取所有子组id
						List<NodeProxy> subGroupProxys = manageGroupDao.querySubGroupProxyRecurse(curGroupId);
						long[] groupIds = new long[subGroupProxys.size() + 1];
						groupIds[0] = curGroupId;
						int i = 1;
						Iterator<NodeProxy> iter = subGroupProxys.iterator();
						while(iter.hasNext()){
							groupIds[i++] = iter.next().getNodeId();
						}
						
						SqlExpressionGroup eGroup = Cnd.exps("manageGroupId", "in", groupIds);
						e = (e == null) ? eGroup : e.and(eGroup);
					/*}else{//查询所有资产
						SqlExpressionGroup eGroup = Cnd.exps("1", "=", "1");
						e = (e == null) ? eGroup : e.and(eGroup);
					}*/
					
				}else{			// 仅查询当前组
					SqlExpressionGroup eGroup = Cnd.exps("manageGroupId", "=", curGroupId);
					e = (e == null) ? eGroup : e.and(eGroup);
				}
			}
		}
		
		if(!"".equals(assetTypecode)){
			SqlExpressionGroup eGroup = Cnd.exps("alias", "=", assetTypecode);
			e = (e == null) ? eGroup : e.and(eGroup);
		}
		
		
		if(e==null){
			SqlExpressionGroup eGroup = Cnd.exps("1", ">", 2);
			e = (e == null) ? eGroup : e.and(eGroup);
		}
		
		return Cnd.where(e);
	}
	
	/**
	 * 根据IP范围查询IP(mysql数据库有效)
	 */
	public List<Asset> queryListByIPRange(String startIp,String endIp){
		String cndStr="INET_ATON(ip)>=INET_ATON('"+startIp+"') AND INET_ATON(ip)<=INET_ATON('"+endIp+"') ";
		try{
			boolean ascx=IPComparatorHandler.comparatorIP(startIp, endIp);
			if(!ascx){
				cndStr="INET_ATON(ip)<=INET_ATON('"+startIp+"') AND INET_ATON(ip)>=INET_ATON('"+endIp+"') ";
			}
			return this.query(Asset.class, Cnd.wrap(cndStr), null);
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取全部资产
	 * @return
	 */
	public List<Asset> queryAll(){
		return this.query(Asset.class,null,null);
	}
	
	/**
	 * 根据ip获取资产
	 * @param ips
	 * @return
	 */
	public List<Asset> queryByIp(String... ips){
		Cnd cnd=Cnd.where("ip","in",ips);
		return this.query(Asset.class,cnd,null);
	}
	
	/**
	 * 根据Ip和设备类型查询
	 * @param ip
	 * @param type
	 * @return
	 */
	public List<Asset> queryByIpType(String ip, long type){
		Cnd cnd = Cnd.where("ip", "=", ip).and("type", "=", type);
		return this.query(Asset.class, cnd, null);
	}
	
	public Asset queryByExternalId(String externalId){
		Cnd cnd = Cnd.where("externalSysid", "=", externalId);
		return this.fetch(Asset.class, cnd);
	}
	/**
	 * 根据资产名查找资产
	 * @param name
	 * @return
	 */
	public Asset queryByName(String name){
		Cnd cnd = Cnd.where("name", "=", name);
		return this.fetch(Asset.class, cnd);
	}
	/**
	 * 根据Ip和GroupId查找资产
	 * @param groupId
	 * @param ip
	 * @param id
	 * @return
	 */
	public Asset queryByGroupIp(long groupId,String ip){
		Cnd cnd=Cnd.where("ip","=",ip);
		if(groupId!=0){
			cnd.and("manageGroupId", "=", groupId);
		}
		return this.fetch(Asset.class, cnd);
	}
	
}
