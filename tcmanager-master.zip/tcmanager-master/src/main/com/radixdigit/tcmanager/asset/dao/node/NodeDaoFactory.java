/**
 
 * Author: gaoxl
 * Created: 2012-6-20
 */
package com.radixdigit.tcmanager.asset.dao.node;

import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeInterface;

@IocBean
public class NodeDaoFactory {

	@Inject("refer:assetDao")
	private AssetDao assetDao;

	@Inject("refer:linkDao")
	private LinkDao linkDao;
	
	/**
	 * 获取节点dao
	 * @param nodeType
	 * @return
	 */
	public NodeDao<? extends NodeInterface> getNodeDao(int nodeType){
		NodeDao<? extends NodeInterface> nodeDao = null;
		
		switch (nodeType) {
		case NodeConstant.NODETYPE_ASSET:
			nodeDao = assetDao;
			break;
		case NodeConstant.NODETYPE_LINK:
			nodeDao = linkDao;
			break;
		default:
			break;
		}
		
		return nodeDao;
	}
	
}
