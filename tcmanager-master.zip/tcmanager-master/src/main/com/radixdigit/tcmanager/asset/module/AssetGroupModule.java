package com.radixdigit.tcmanager.asset.module;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.nutz.ioc.Ioc;
import org.nutz.ioc.annotation.InjectName;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.Param;

import com.radixdigit.tcmanager.annotation.AuthBy;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeGroupProxy;
import com.radixdigit.tcmanager.asset.data.NodeInterface;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.asset.data.group.ManageGroup;
import com.radixdigit.tcmanager.asset.service.group.ManageGroupService;
import com.radixdigit.tcmanager.asset.service.node.AssetService;

@IocBean
@InjectName
@AuthBy(check=false)
@At("/asset/group/")
@Ok("json")
@Fail("json")
public class AssetGroupModule {
	
	@Inject("refer:manageGroupService")
	private ManageGroupService groupService;
	/**
	 * 返回指定视图对应的整棵树结构
	 * @param ioc
	 * @param request
	 * @param viewType
	 * @return
	 */
	@At
	public NodeGroupProxy getGroupTree(Ioc ioc, HttpServletRequest request){
		NodeGroupProxy group = groupService.getGroupRecurve(NodeConstant.ID_ROOT);
		return group;
	}
	
	/**
	 * 检测是否是空组 （不含子组 及 资产） 
	 * @param ioc
	 * @param request
	 * @param groupId
	 * @param viewType
	 * @return true 空组; false 非空组
	 */
	@At()
	public boolean isEmpty(Ioc ioc, HttpServletRequest request, @Param("groupId") long groupId){
		List<NodeProxy> groupList = groupService.getProxysInGroup(groupId);
		
		if(groupList != null && groupList.size() > 0) return false;
		
		AssetService assetService = ioc.get(AssetService.class);
		List<NodeProxy>nodeList = assetService.getProxysInGroup(groupId, NodeConstant.VIEW_MANAGE);
		if(nodeList != null && nodeList.size() > 0) return false;
		return true;		
	}
	
	/**
	 * 检测是否重名 -- 重名返回false; 不重名返回true
	 * @param ioc
	 * @param request
	 * @param name
	 * @param viewType
	 * @return
	 */
	@At
	public NodeInterface checkName(Ioc ioc, HttpServletRequest request, @Param("name") String name,
			@Param("viewType") String viewType){
		return groupService.checkName(name);
	}

	/**
	 * 读取组下的直属资产数目
	 * @param ioc
	 * @param groupId
	 * @param viewType
	 * @return
	 */
	@At
	public int getAssetCount(Ioc ioc, @Param("groupId") long groupId){
		AssetService assetService = ioc.get(AssetService.class);
		List<NodeProxy>nodeList = assetService.getProxysInGroup(groupId, NodeConstant.VIEW_MANAGE);
		if(nodeList != null) return nodeList.size();
		else return 0;
	}
	
	/**
	 * 读取一个资产组的信息
	 * @param ioc
	 * @param request
	 * @param groupId
	 * @param viewType
	 * @return
	 */
	@At("/read")
	public NodeInterface read(Ioc ioc, HttpServletRequest request, @Param("groupId") long groupId){		 
		NodeInterface groupNode = groupService.getProxyById(groupId).getNode();
		return groupNode;
	}

	/**
	 * 添加资产组
	 * @param ioc
	 * @param request
	 * @param parentId
	 * @param name
	 * @param description
	 * @return
	 */
	@At
	public NodeProxy insert(Ioc ioc, HttpServletRequest request, 
			@Param("parentId") long parentId, 
			@Param("name") String name, 
			@Param("description") String description){
		
		ManageGroup groupNode = new ManageGroup();
		groupNode.setName(name);
		groupNode.setDescription(description);
		groupNode.setTimeCreate(System.currentTimeMillis());
		groupNode.setTimeModify(System.currentTimeMillis());
		
		NodeProxy nodeProxy = new NodeProxy();
		nodeProxy.setNode(groupNode);
		nodeProxy.setNodeType(NodeConstant.NODETYPE_GROUP);
		nodeProxy.setpNodeId(parentId);
		nodeProxy.setpNodeType(NodeConstant.NODETYPE_GROUP);
		nodeProxy.setViewType(NodeConstant.VIEW_MANAGE);
		nodeProxy.setPointX(100);
		nodeProxy.setPointY(100);
		nodeProxy = groupService.addNode(nodeProxy);
				
		return nodeProxy;
		
	}
	
	/**
	 * 编辑资产组
	 * @param ioc
	 * @param request
	 * @param groupId
	 * @param name
	 * @param description
	 * @return
	 */
	@At
	public NodeInterface update(Ioc ioc, HttpServletRequest request, 
			@Param("groupId") long groupId,
			@Param("name") String name, 
			@Param("description") String description){
				
		ManageGroup groupNode = groupService.fetch(groupId);
		if(groupNode != null){
			groupNode.setName(name);
			groupNode.setDescription(description);
			groupService.updateNodes(groupNode);		
		}
		return groupNode;
	}
	
	/**
	 * 删除资产组
	 * @param ioc
	 * @param request
	 * @param groupId
	 * @param viewType
	 * @return
	 */
	@At
	public int delete(Ioc ioc, HttpServletRequest request, @Param("groupId") long groupId){
		int result = groupService.deleteNodes(groupId);
		return result;
	}
	
	
	@At("/deleteGroupAjax")
	public int deleteGroupAjax(Ioc ioc, @Param("ids") long... ids){
		int result = groupService.deleteNodes(ids);
		return result;
	}
	
}
