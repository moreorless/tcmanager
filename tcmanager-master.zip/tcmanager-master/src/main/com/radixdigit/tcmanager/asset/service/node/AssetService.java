/**
 
 * Author: wangxh
 * Created: 2011-5-24
 */
package com.radixdigit.tcmanager.asset.service.node;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.dao.sql.OrderBy;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.lang.Mirror;

import com.radixdigit.tcmanager.asset.dao.node.AssetDao;
import com.radixdigit.tcmanager.asset.dao.node.NodeDao;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.asset.data.NodeQueryCnd;
import com.radixdigit.tcmanager.asset.data.node.Asset;
import com.radixdigit.tcmanager.asset.service.group.ManageGroupService;
import com.radixdigit.tcmanager.asset.util.IpUtil;
import com.radixdigit.tcmanager.commons.mvc.Pager;
import com.radixdigit.tcmanager.util.IPComparatorHandler;

/**
 * 资产服务
 * 
 * @author wangxh
 * 
 */

@IocBean
public class AssetService extends NodeService<Asset> {
	private Logger logger = Logger.getLogger(AssetService.class);
	
	@Inject("refer:assetDao")
	@Override
	public void setNodeDao(NodeDao<Asset> dao){
		setDao(dao);
	}

	@Inject("refer:assetLinkService")
	private AssetLinkService linkService;

	@Inject("refer:manageGroupService")
	private ManageGroupService manageGroupService;
	
	/**
	 * 获取属于某类型的所有资产
	 * 
	 * @param assetTypeId
	 * @param pager
	 * @return
	 */
	public Pager<Asset> getAssetByTypeId(long assetTypeId, Pager<Asset> pager) {
		return ((AssetDao) this.dao()).queryByTypeId(assetTypeId, pager);
	}

	/**
	 * 获取属于某类型的所有资产
	 * 
	 * @param assetTypeId
	 * @param cnd 查询条件
	 * @param pager
	 * @return
	 */
	public Pager<Asset> getAssetByTypeId(long assetTypeId, Condition cnd, Pager<Asset> pager) {
		return ((AssetDao) this.dao()).queryByTypeId(assetTypeId, cnd, pager);
	}
	
	
	/**
	 * 根据条件对象查询资产
	 * 
	 * @param nqc
	 *            查询条件。为null时获取全部资产
	 * @param pager
	 *            页。为null时不分页
	 * @return
	 */
	public Pager<Asset> getByCondition(NodeQueryCnd nqc, Pager<Asset> pager,int view) {
		Condition condition = null;
		if (nqc != null) {//只查询当前组下资产
			condition = ((AssetDao) this.dao()).createCnd(nqc, false,view);
		}
		//默认排序为IP排序
		if (pager.getSidx() == null || pager.getSidx().equals("")) {
			pager.setSidx("ip");
		}
		if (pager.getSidx() != null) { //设置排序字段和方向
			if(condition==null){
				condition = Cnd.orderBy();
			}
			if(pager.getSidx().equals("ip")){
				Mirror.me(OrderBy.class).invoke(condition, pager.getSord(), "ipHexadecimal");
			}else{
				Mirror.me(OrderBy.class).invoke(condition, pager.getSord(), pager.getSidx());
			}
			
		}
		return getByCondition(condition, pager);
	}
	
	/**
	 * 根据条件对象查询资产
	 * 
	 * @param nqc
	 *            查询条件。为null时获取全部资产
	 * @param pager
	 *            页。为null时不分页
	 * @return
	 */
	public Pager<Asset> getByCondition(NodeQueryCnd nqc, Pager<Asset> pager,int view,String assetTypecode) {
		Condition condition = null;
		if (nqc != null) {//只查询当前组下资产
			condition = ((AssetDao) this.dao()).createCnd(nqc, false,view,assetTypecode);
		}
		//默认排序为IP排序
		if (pager.getSidx() == null || pager.getSidx().equals("")) {
			pager.setSidx("ip");
		}
		if (pager.getSidx() != null) { //设置排序字段和方向
			if(condition==null){
				condition = Cnd.orderBy();
			}
			if(pager.getSidx().equals("ip")){
				Mirror.me(OrderBy.class).invoke(condition, pager.getSord(), "ipHexadecimal");
			}else{
				Mirror.me(OrderBy.class).invoke(condition, pager.getSord(), pager.getSidx());
			}
		}
		return getByCondition(condition, pager);
	}
	

	
	@SuppressWarnings("unchecked")
	public Pager<Asset> getByCondition(Condition condition, Pager<Asset> pager) {
		org.nutz.dao.pager.Pager nutzPager = null;
		List<Asset> assets = null;
		List<IPComparatorHandler> ipList = new ArrayList<IPComparatorHandler>();
		boolean ipSort=false;
		if (pager != null) {
			nutzPager = this.dao().createPager(pager.getPage(), pager.getPageSize());
		} else {
			pager = new Pager<Asset>();
		}
		try {
			assets = ((AssetDao) this.dao()).query(Asset.class, condition, nutzPager);
			pager.setRecords(this.count(condition));
			pager.setData(assets);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pager;
	}
	
	/**
	 * 根据（status--状态 ）和（standby1--虚拟化类型） 查询资产
	 */
	public List<Asset> getAssetByStatus(Condition condition){
		List<Asset> pager = ((AssetDao)this.dao()).query(Asset.class, condition, null);
		return pager;
	}
	
	public int getCountByStatusAndType(Condition condition){
		return ((AssetDao)this.dao()).count(Asset.class, condition);
	}
	@Override
	public int deleteNodes(long... ids) {
		if (ids == null || ids.length == 0) {
			return NodeConstant.RETURN_INVALID;
		}

		// 从数据库中获取要删除的资产信息
		List<Asset> assets = ((AssetDao) dao()).queryById(ids);

		//删除资产
		int result = ((AssetDao) dao()).deleteById(ids);
		if (result > 0) {
			clearLinks(ids);
			((AssetDao) dao()).updateByDeletedId(ids);// 更新资产主从关系
			deleteProxysByNodeId(0, ids);
			return result;
		} else {
			return NodeConstant.RETURN_INVALID;
		}
	}

	@Override
	public long[] getGroupsOfNode(int viewType, long... nodeIds) {
		List<NodeProxy> proxys = this.nodeProxyDao.queryGroupByNodeId(	viewType,
																		NodeConstant.NODETYPE_ASSET,
																		nodeIds);
		if (proxys != null && proxys.size() > 0) {
			long[] groupIds = new long[proxys.size()];
			int i = 0;
			for (NodeProxy proxy : proxys) {
				groupIds[i] = proxy.getpNodeId();
				i++;
			}
			return groupIds;
		}
		return null;
	}

	@Override
	protected int deleteProxysByNodeId(int viewType, long... proxyIds) {
		return nodeProxyDao.deleteProxyByNodeId(NodeConstant.NODETYPE_ASSET, viewType, proxyIds);
	}

	@Override
	public int clearLinks(long... ids) {
		// 根据节点ID获取proxyID
		List<NodeProxy> ls = nodeProxyDao.queryProxysByNodeId(NodeConstant.NODETYPE_ASSET, 0, ids);
		if (ls == null || ls.size() == 0) {
			return NodeConstant.RETURN_INVALID;
		}

		int length = ls.size();
		long[] proxyIds = new long[length];
		for (int i = 0; i < length; i++) {
			proxyIds[i] = ls.get(i).getId();
		}

		// 根据连线两端ID（即porxyID）删除连线及连接关系
		return linkService.clearLinks(proxyIds);
	}

	@Override
	public NodeProxy addNode(NodeProxy proxy) {
		if (proxy == null || proxy.getNode() == null)
			return null;
		Asset asset = (Asset) proxy.getNode();
		asset.setId(getTblMaxIdWithUpdate());
		asset.setIpHexadecimal(IpUtil.buildKey(asset.getIp()));//将IP转换为十六进制字符串
		Asset node = null;
		try {
			node = dao().insert(asset);
		}
		catch (Exception e) {
			logger.error("添加资产错误", e);
			return null;
		}

		if (node != null) {
			proxy.setNodeId(node.getId());
			NodeProxy[] nodeProxys = nodeProxyDao.addNodeProxy(proxy);
			if (nodeProxys != null && nodeProxys.length > 0) {
				return nodeProxys[0];
			}
		}
		return null;
	}

	/**
	 * 添加资产，不保存关联关系
	 * @param asset
	 * @return
	 */
	public Asset insert(Asset asset){
		Asset node = null;
		try {
			asset.setId(getTblMaxIdWithUpdate());
			asset.setIpHexadecimal(IpUtil.buildKey(asset.getIp()));//将IP转换为十六进制字符串
			node = dao().insert(asset);
		}
		catch (Exception e) {
			logger.error("添加资产错误", e);
			return null;
		}
		return node;
	}
	

	@Override
	public int updateNodes(Asset... nodes) {
		if (nodes == null || nodes.length == 0)
			return NodeConstant.RETURN_INVALID;

		// 从数据库中获取更新前的资产信息
		long[] ids = new long[nodes.length];
		int i;
		for (i = 0; i < nodes.length; i++) {
			ids[i] = nodes[i].getId();
			nodes[i].setIpHexadecimal(IpUtil.buildKey(nodes[i].getIp()));//将IP转换为十六进制字符串
		}

		// 向数据库更新资产
		int result = dao().update(nodes);
		return result;
	}
	
	/**
	 * 根据ip地址查询资产，可以是多个ip地址
	 * @param ips
	 * @return
	 */
	public List<Asset> queryAssetsByIp(String... ips){
		return ((AssetDao) this.dao()).queryByIp(ips);
	}

	public Asset queryByExternalId(String externalId){
		return ((AssetDao) this.dao()).queryByExternalId(externalId);
	}
	
	public Asset queryByName(String name){
		return ((AssetDao)this.dao()).queryByName(name);
	}
	public Asset queryByGroupIp(long groupId,String ip){
		return ((AssetDao)this.dao()).queryByGroupIp(groupId, ip);
	}
	public List<Asset> queryByIp(String ip){
		return ((AssetDao)this.dao()).queryByIp(ip);
	}
	
	/**
	 * 根据Ip和设备类型查询
	 * @param ip
	 * @param type
	 * @return
	 */
	public List<Asset> queryByIpType(String ip, long type){
		return ((AssetDao)this.dao()).queryByIpType(ip, type);
	}
	
	/**
	 * 读取所有流控设备列表
	 * @return
	 */
	public List<Asset> queryRadixAssets(){
		Condition cnd = Cnd.where("type", "=", "/radixdigit");
		return ((AssetDao)this.dao()).query(Asset.class, cnd);
	}
}
