package com.radixdigit.tcmanager.asset.polling;

import java.util.HashMap;
import java.util.Map;

import com.radixdigit.tcmanager.monitor.ext.radix.data.RadixPingInfo;
public class RadixCacheManager {
	public static RadixCacheManager _inst = new RadixCacheManager();
	private RadixCacheManager(){}
	public static RadixCacheManager me(){
		return _inst;
	}
	
	private Map<Long, RadixDeviceCache> deviceCacheMap = new HashMap<Long, RadixDeviceCache>();
	public Map<Long, RadixDeviceCache> getDeviceCacheMap() {
		return deviceCacheMap;
	}

	// 链路ping的数据缓存, key为流控设备Ip
	private Map<String, RadixPingInfo> linkCacheMap = new HashMap<>();
	
	// http ping的数据缓存， key为流动设备ip
	private Map<String, RadixPingInfo> httppingCacheMap = new HashMap<>();
	
	public Map<String, RadixPingInfo> getLinkCacheMap(){
		synchronized (linkCacheMap) {
			return linkCacheMap;
		}
	}
	
	public Map<String, RadixPingInfo> getHttppingCacheMap(){
		synchronized (httppingCacheMap) {
			return httppingCacheMap;
		}
	}
	
}
