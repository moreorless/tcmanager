package com.radixdigit.tcmanager.asset.polling;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.nutz.dao.Cnd;
import org.nutz.ioc.Ioc;
import org.nutz.mvc.NutConfig;

import com.radixdigit.tcmanager.SetupListener;
import com.radixdigit.tcmanager.asset.data.node.Asset;
import com.radixdigit.tcmanager.asset.service.node.AssetService;
import com.radixdigit.tcmanager.monitor.core.dao.TaskStructDao;
import com.radixdigit.tcmanager.monitor.core.data.TaskStruct;
import com.radixdigit.tcmanager.monitor.ext.radix.data.NetInfo;
import com.radixdigit.tcmanager.monitor.ext.radix.data.NetInfoParser;

public class RadixPollingService implements SetupListener {

	private volatile boolean runFlag = false;
	
	/**
	 * 设备状态轮询时间间隔
	 */
	private int pollingInterval = 30000;		// 30秒
	
	private Ioc ioc;
	
	private Thread netPollThread = null;
	
	@Override
	public void init(NutConfig config) {
		runFlag = true;
		
		ioc = config.getIoc();
		
		netPollThread = new Thread(new NetInfoPollingThread(), "netinfoPollingThread");
		netPollThread.start();
	}

	@Override
	public void destroy(NutConfig config) {
		runFlag = false;
		netPollThread.interrupt();
	}

	/**
	 * 网络信息轮询线程
	 * @author gaoxl
	 *
	 */
	class NetInfoPollingThread implements Runnable{

		@Override
		public void run() {
			while(runFlag){
				TaskStructDao tsDao = ioc.get(TaskStructDao.class);
				// 获取所有流控设备监控任务
				List<TaskStruct> tsList = tsDao.query(TaskStruct.class, Cnd.where("mtype", "=", "radixdigit"));
				
				long timestamp = System.currentTimeMillis();
				if(tsList != null){
					Iterator<TaskStruct> iter = tsList.iterator();
					while(iter.hasNext()){
						TaskStruct ts = iter.next();
						// 读取流控设备网络信息，写入缓存
						NetInfoParser parser = new NetInfoParser(ts.getUrl());
						
						RadixGroupItemSnap snap = new RadixGroupItemSnap();
						snap.setTimestamp(timestamp);

						
						Map<String, String> params = new HashMap<>();
						params.put("key", "session");
						params.put("type", "group");
						List<NetInfo> netInfoList = parser.getNetInfo(params);
						snap.setNetInfo(netInfoList);
						
						RadixDeviceCache groupCache = null;
						if(RadixCacheManager.me().getDeviceCacheMap().containsKey(ts.getId())){
							groupCache = RadixCacheManager.me().getDeviceCacheMap().get(ts.getId());
						}else{
							groupCache = new RadixDeviceCache();
							RadixCacheManager.me().getDeviceCacheMap().put(ts.getId(), groupCache);
						}
						groupCache.addGroupSnap(snap);
					}
				}
				
				try {
					Thread.sleep(pollingInterval);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	
}
