package com.radixdigit.tcmanager.asset.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.dao.util.cri.SqlExpressionGroup;
import org.nutz.dao.impl.NutDao;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.dao.group.NodeGroupDao;
import com.radixdigit.tcmanager.asset.dao.group.NodeGroupDaoFactory;
import com.radixdigit.tcmanager.asset.dao.node.LinkDao;
import com.radixdigit.tcmanager.asset.dao.node.NodeDao;
import com.radixdigit.tcmanager.asset.dao.node.NodeDaoFactory;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeInterface;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.asset.data.group.AbstractGroup;
import com.radixdigit.tcmanager.asset.data.node.AssetLink;
import com.radixdigit.tcmanager.util.dao.TblMaxIdHelper;

/**
 * @author wangxh
 * 
 */
@IocBean(name = "nodeProxyDao", fields = { "dataSource" })
public class NodeProxyDao extends NutDao {
	
	@Inject("refer:nodeGroupDaoFactory")
	NodeGroupDaoFactory nodeGroupDaoFactory;
	@Inject("refer:nodeDaoFactory")
	NodeDaoFactory nodeDaoFactory;
	@Inject("refer:linkDao")
	LinkDao linkDao;
	/**
	 * 添加节点关系
	 * 增加判断，如果关联关系已存在，则不再添加，只进行更新
	 * @param proxy
	 * @return
	 */
	public NodeProxy[] addNodeProxy(NodeProxy... proxy) {
		ArrayList<NodeProxy> insertProxys = new ArrayList<>();
		ArrayList<NodeProxy> updateProxys = new ArrayList<>();
		for (NodeProxy nodeProxy : proxy) {
			NodeProxy oldProxy = this.queryProxyByRelation(nodeProxy);
			if( oldProxy!= null){
				// 关联关系已存在，更新
				nodeProxy.setId(oldProxy.getId());
				updateNodeProxy(nodeProxy);
				updateProxys.add(nodeProxy);
			}else{
				long id = TblMaxIdHelper.getTblMaxIdWithUpdate(this,
						NodeProxy.class);
				nodeProxy.setId(id);
				insertProxys.add(nodeProxy);
			}
		}
		NodeProxy[] insertArray = new NodeProxy[]{};
		insertArray = this.insert(insertProxys.toArray(insertArray));
		NodeProxy[] updateArray = new NodeProxy[]{};
		updateArray = updateProxys.toArray(updateArray);
		NodeProxy[] allProxys = new NodeProxy[insertArray.length + updateArray.length];
		System.arraycopy(insertArray, 0, allProxys, 0, insertArray.length);
		System.arraycopy(updateArray, 0, allProxys, insertArray.length, updateArray.length);
		return allProxys;
	}

	/**
	 * 添加节点关系
	 * topo 模块使用
	 * @param proxy
	 * @return
	 */
	public NodeProxy[] addNodeProxyTOPO(NodeProxy... proxy) {
		for (NodeProxy nodeProxy : proxy) {
			long id = TblMaxIdHelper.getTblMaxIdWithUpdate(this,
					NodeProxy.class);
			nodeProxy.setId(id);
		}
		return this.insert(proxy);
	}
	/**
	 * 更新节点代理
	 * @param proxy
	 * @return
	 */
	public int updateNodeProxy(NodeProxy proxy){
		return this.update(proxy);
	}
	
	/**
	 * 删除节点关系
	 * 
	 * @param ids
	 *            节点关系ID
	 * @return
	 */
	public int deleteNodeProxy(long... ids) {
		if(ids==null || ids.length==0){
			return 0;
		}
		return this.clear(NodeProxy.class, Cnd.where("id", "in", ids));
	}

	/**
	 * 删除关联关系及节点
	 * @param proxyId
	 * @return
	 */
	public int deleteProxyAndNode(NodeProxy proxy){
		NodeInterface node = proxy.getNode();
		long nodeId = proxy.getNodeId();
		if(node instanceof AbstractGroup){
			NodeGroupDao nodeGroupDao = nodeGroupDaoFactory.getNodeGroupDao(proxy.getViewType());
			nodeGroupDao.deleteById(nodeId);
		}else{
			NodeDao nodeDao = nodeDaoFactory.getNodeDao(proxy.getNodeType());
			
			// 通过节点id删除关联关系
			deleteProxyByNodeId(proxy.getNodeType(), 0, nodeId);
			
			// 删除节点
			nodeDao.deleteById(nodeId);
		}
		
		// 删除关联关系
		return deleteNodeProxy(proxy.getId());
	}
	
	/**
	 * 通过节点ID删除关联关系
	 * 
	 * @param nodeType
	 *            节点类型
	 * @param viewType
	 *            视图类型。为0时表示不区分视图类型
	 * @param ids
	 *            节点ID
	 * @return
	 */
	public int deleteProxyByNodeId(int nodeType, int viewType, long... ids) {

		if (viewType != 0) {
			return this.clear(NodeProxy.class, Cnd.where("nodeId", "in", ids)
					.and("nodeType", "=", nodeType).and("viewType","=",viewType));
		} else {
			this.clear(NodeProxy.class,Cnd.where("nodeId", "in", ids).and("viewType", "=", NodeConstant.NODETYPE_RACK));
			return this.clear(NodeProxy.class, Cnd.where("nodeId", "in", ids).and("nodeType", "=", nodeType));
		}
	}

	
	/**
	 * 根据nodeId, pNodeId, nodeType, pNodeType, viewType获取节点代理
	 * @param proxy
	 * @return
	 */
	public NodeProxy queryProxyByRelation(NodeProxy proxy){
		Cnd cnd = Cnd.where("nodeId", "=", proxy.getNodeId())
				.and("pNodeId", "=", proxy.getpNodeId())
				.and("nodeType", "=", proxy.getNodeType())
				.and("pNodeType", "=", proxy.getpNodeType())
				.and("viewType", "=", proxy.getViewType())
				.and("polymorphic", "=", proxy.getPolymorphic());
		List<NodeProxy> proxys = this.query(NodeProxy.class, cnd, null);
		if(proxys != null && proxys.size() > 0){
			return proxys.get(0);
		}
		return null;
	}
	
	/**
	 * 根据节点ID,查询它所归属于哪些节点组（仅限关系对象，不含组对象）
	 * 
	 * @param viewType
	 * @param nodeIds
	 * @return
	 */
	public List<NodeProxy> queryGroupByNodeId(int viewType, int nodeType,
			long... nodeIds) {
		Cnd cnd = Cnd.where("nodeId", "in", nodeIds);
		if (viewType != 0) {
			cnd.and("viewType", "=", viewType);
		}
		cnd.and("pNodeType", "=", NodeConstant.NODETYPE_GROUP);
		cnd.and("nodeType", "=", nodeType);
		return this.query(NodeProxy.class, cnd, null);
	}

	/**
	 * 读取组内的所有直属节点信息（包括资产、辅助图元、连接以及组对象）
	 * 
	 * @param groupId
	 *            组ID
	 * @param viewType
	 *            视图类型
	 */
	public List<NodeProxy> queryProxysInGroup(long groupId, int viewType) {
		/**
 			重写该方法by gaoxl, 2012/06/20, 解决使用sql语句过多问题
		List<NodeProxy> proxys = new ArrayList<NodeProxy>();
		switch (viewType) {
		case NodeConstant.VIEW_MANAGE:
			proxys.addAll(manageDao.queryProxyInGroup(groupId));
			break;
		case NodeConstant.VIEW_CLASSIFY:
			proxys.addAll(classifyDao.queryProxyInGroup(groupId));
			break;
		default:
			break;
		}
		proxys.addAll(assetDao.queryProxyInGroup(groupId, viewType));
		proxys.addAll(linkDao.queryProxyInGroup(groupId, viewType));
		proxys.addAll(pixelDao.queryProxyInGroup(groupId, viewType));
		return proxys;
		 */
		// 读取关联关系对象nodeProxy
		Condition cnd = Cnd.where("pNodeId", "=", groupId).and("pNodeType", "=", NodeConstant.NODETYPE_GROUP).and("viewType", "=", viewType);
		List<NodeProxy> proxyList = this.query(NodeProxy.class, cnd, null);
		
		// 填充nodeProxy的节点对象（可以是组、资产、连线等）
		Iterator<NodeProxy> iter = proxyList.iterator();
		while(iter.hasNext()){
			NodeProxy proxy = iter.next();
			proxy.setNode(getNodeByProxy(proxy));
		}
		
		return proxyList;
	}
	
	/**
	 * 读取组内的所有直属节点信息（包括资产、辅助图元、连接以及组对象）
	 * @param groupId	
	 * @param viewType
	 * @param polymorphic
	 * @return
	 */
	public List<NodeProxy> queryProxysInGroup(long groupId, int viewType, int polymorphic) {
		// 读取关联关系对象nodeProxy
		Condition cnd = Cnd.where("pNodeId", "=", groupId).and("pNodeType", "=", NodeConstant.NODETYPE_GROUP)
				.and("viewType", "=", viewType)
				.and("polymorphic", "=", polymorphic);
		List<NodeProxy> proxyList = this.query(NodeProxy.class, cnd, null);
		
		// 填充nodeProxy的节点对象（可以是组、资产、连线等）
		Iterator<NodeProxy> iter = proxyList.iterator();
		while(iter.hasNext()){
			NodeProxy proxy = iter.next();
			proxy.setNode(getNodeByProxy(proxy));
		}
		
		return proxyList;
	}
	
	/**
	 * 读取组内的所有直属节点信息（包括资产、辅助图元、连接以及组对象）
	 * @param cnd 查询条件
	 * @return
	 */
	public List<NodeProxy> queryProxysInGroup(Condition cnd) {
		List<NodeProxy> proxyList = this.query(NodeProxy.class, cnd, null);
		
		// 填充nodeProxy的节点对象（可以是组、资产、连线等）
		Iterator<NodeProxy> iter = proxyList.iterator();
		while(iter.hasNext()){
			NodeProxy proxy = iter.next();
			proxy.setNode(getNodeByProxy(proxy));
		}
		
		return proxyList;
	}
	
	/**
	 * 根据proxyId获取节点代理，已经填充节点数据。
	 * @param proxyId
	 * @return
	 */
	public NodeProxy getProxyByProxyId(long proxyId){
		NodeProxy nodeProxy = this.fetch(NodeProxy.class, proxyId);
		nodeProxy.setNode(getNodeByProxy(nodeProxy));
		return nodeProxy;
	}
	
	/**
	 * 填充NodeProxy的节点属性
	 * @param proxy
	 */
	public NodeInterface getNodeByProxy(NodeProxy proxy){
		if(proxy == null) return null;
		
		NodeInterface node = null;
		if(proxy.getNodeType() == NodeConstant.NODETYPE_GROUP){
			// 组对象
			NodeGroupDao<? extends NodeInterface> groupDao = nodeGroupDaoFactory.getNodeGroupDao(proxy.getViewType());
			node = groupDao.fetch(groupDao.getEntryClass(), proxy.getNodeId()); 
		}else{
			// 节点对象
			NodeDao<? extends NodeInterface> nodeDao = nodeDaoFactory.getNodeDao(proxy.getNodeType());
			node = nodeDao.fetch(nodeDao.getEntryClass(), proxy.getNodeId());
		}
		
		return node;
	}
	
	public int updateNode(NodeProxy proxy){
		if(proxy == null) return 0;
		
		NodeInterface node = proxy.getNode();
		if(node==null) return 0;
		NodeDao<? extends NodeInterface> nodeDao = nodeDaoFactory.getNodeDao(proxy.getNodeType());
		/*if(proxy.getNodeType() == NodeConstant.NODETYPE_GROUP){
			// 组对象
			NodeGroupDao<? extends NodeInterface> groupDao = nodeGroupDaoFactory.getNodeGroupDao(proxy.getViewType());
			node = groupDao.fetch(groupDao.getEntryClass(), proxy.getNodeId()); 
			return 1;
		}else{
			// 节点对象
			NodeDao<? extends NodeInterface> nodeDao = nodeDaoFactory.getNodeDao(proxy.getNodeType());
			node = nodeDao.fetch(nodeDao.getEntryClass(), proxy.getNodeId());
			return nodeDao.update(node);
		}*/
		return nodeDao.update(node);
	}

	/**
	 * 根据节点ID查询所有代理
	 * 
	 * @param nodeType
	 *            节点类型
	 * @param ids
	 *            节点ID
	 * @return
	 */
	public List<NodeProxy> queryProxysByNodeId(int nodeType, int viewType,
			long... ids) {
		Cnd cnd = Cnd.where("nodeId", "IN", ids);
		if (nodeType > 0) {
			cnd.and("nodeType", "=", nodeType);
		}
		if (viewType > 0) {
			cnd.and("viewType", "=", viewType);
		}
		return this.query(NodeProxy.class, cnd, null);
	}
	
	/**
	 * 根据nodeId和pNodeId 查询NodeProxy 
	 */
	private List<NodeProxy> queryProxyByNidPid(long[] nodeIds, long[] pids) {
		Condition cnd = Cnd.where("pNodeId", "IN", pids).and("nodeId", "IN", nodeIds).and("polymorphic", "=", NodeConstant.POLYMOPHIC_TOPO_DEFAULT).and("pNodeType", "=", NodeConstant.NODETYPE_ASSET);
		return this.query(NodeProxy.class, cnd, null);
	}

	/**
	 * 根据nodeId查询NodeProxy列表
	 * @param pgid
	 * @return 
	 */
	public List<NodeProxy> getProxyByNodeId(long nodeId) {
		Cnd cnd = Cnd.where("nodeId", "=", nodeId);
		return this.query(NodeProxy.class, cnd);
	}
	
}
