package com.radixdigit.tcmanager.asset.module;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jofc2.model.Chart;
import jofc2.model.Text;
import jofc2.model.axis.Label;
import jofc2.model.axis.XAxis;
import jofc2.model.axis.XAxisLabels;
import jofc2.model.axis.YAxis;
import jofc2.model.axis.YAxisLabels;
import jofc2.model.elements.AbstractDot;
import jofc2.model.elements.LineChart;
import jofc2.model.elements.AnimatedElement.OnShow;

import org.nutz.ioc.annotation.InjectName;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.Param;

import com.radixdigit.tcmanager.annotation.AuthBy;
import com.radixdigit.tcmanager.asset.data.node.Asset;
import com.radixdigit.tcmanager.asset.polling.RadixCacheManager;
import com.radixdigit.tcmanager.asset.service.node.AssetService;
import com.radixdigit.tcmanager.monitor.core.data.DefineConstant;
import com.radixdigit.tcmanager.monitor.core.data.TaskStruct;
import com.radixdigit.tcmanager.monitor.ext.radix.data.PingData;
import com.radixdigit.tcmanager.monitor.ext.radix.data.RadixPingHistoryParser;
import com.radixdigit.tcmanager.monitor.ext.radix.data.RadixPingInfo;
import com.radixdigit.tcmanager.monitor.ext.radix.data.RadixPingInfoParser;
import com.radixdigit.tcmanager.monitor.service.ProMonitorService;

@IocBean
@InjectName
@AuthBy(check=false)
@At("/link")
public class LinkModule {

	@Inject
	AssetService assetService;
	
	@Inject
	private ProMonitorService proMonitorService;
	
	
	/**
	 * 查看链路信息首页
	 * @param request
	 */
	@At
	@Ok("jsp:jsp.link.main")
	public void main(HttpServletRequest request){
		List<Asset> devices = assetService.queryRadixAssets();
		request.setAttribute("devices", devices);
	}
	
	@At
	@Ok("jsp:jsp.link.history")
	public void viewHistory(@Param("sourceIp") String sourceIp, @Param("destIp") String destIp){
		
	}
	
	@At
	@Ok("chart")
	public Chart getLostChart(@Param("sourceIp") String sourceIp, @Param("destIp") String destIp, @Param("day") int day){

		Chart chart = new Chart();
		chart.setTitle(new Text("丢包率(%)"));
		
		List<TaskStruct> tsList = proMonitorService.getTaskStructsByIp(sourceIp);
		if(tsList == null) return chart;
		
		String context = null;
		for(TaskStruct ts : tsList){
			if("radixdigit".equals(ts.getMtype())){
				context = ts.getUrl();
				break;
			}
		}
		
		if(context == null) {
			return getLostEmptyChart(day);
		}
		
		RadixPingHistoryParser parser = new RadixPingHistoryParser(context);
		RadixPingInfo pingInfo = parser.getPingInfo(destIp, day);
		
		if(pingInfo == null || pingInfo.getPingdata().size() == 0) {
			return getLostEmptyChart(day);
		}
		
		LineChart lc = new LineChart().setDotStyle(new AbstractDot.Style(AbstractDot.Style.Type.H0LLOW_DOT, null,2 /* 数据点半径 */, 1 /* 数据点与连线间的间隔 */)).setWidth(3);
		lc.setOnShow(new OnShow(OnShow.TYPE_POPUP)); // 设置显示动画效果
	
		Iterator<PingData> iter = pingInfo.getPingdata().iterator();
		
		int i = 1;
		while(iter.hasNext()){
			PingData data = iter.next();
			float lost = data.getLost();
			LineChart.ScatterDot sc = new LineChart.ScatterDot(data.getTimestamp()/1000, lost);
			lc.addDots(sc);
		}

		lc.setGradientFill(true);
		lc.setColour("#32B7FE");
		lc.setText("丢包率(%)");
		chart.addElements(lc);
		
		// x轴数据
		XAxis xAxis = new XAxis();
		XAxisLabels xlabels = new XAxisLabels();
		xlabels.setRotation(Label.Rotation.HALF_DIAGONAL);
		xlabels.setText(getLabelText(day));
		
		long startTimeStamp = pingInfo.getPingdata().get(0).getTimestamp();
		long endTimeStamp = pingInfo.getPingdata().get(pingInfo.getPingdata().size() - 1).getTimestamp();

		long xStep = 3600;
		if(day > 1) xStep = 3600 * 24; 
		xAxis.setRange(startTimeStamp/1000, endTimeStamp/1000, xStep);
		xAxis.setXAxisLabels(xlabels);
		chart.setXAxis(xAxis);
		
		// y轴数据
		YAxis yAxis = new YAxis();
		yAxis.setRange(0, 100, 10);
		YAxisLabels yAxisLabels=new YAxisLabels();
		
		String unit = "%";
		yAxisLabels.setText("#val#" + unit);
		yAxis.setYAxisLabels(yAxisLabels);
		
		chart.setYAxisAutoRange(false);
		chart.setYAxis(yAxis);
		
		return chart;
	}
	
	@At
	@Ok("chart")
	public Chart getDelayChart(@Param("sourceIp") String sourceIp, @Param("destIp") String destIp, @Param("day") int day){
		Chart chart = new Chart();
		chart.setTitle(new Text("时延(ms)"));
		
		List<TaskStruct> tsList = proMonitorService.getTaskStructsByIp(sourceIp);
		if(tsList == null) return chart;
		
		String context = null;
		for(TaskStruct ts : tsList){
			if("radixdigit".equals(ts.getMtype())){
				context = ts.getUrl();
				break;
			}
		}
		
		if(context == null) return getDelayEmptyChart(day);
		
		RadixPingHistoryParser parser = new RadixPingHistoryParser(context);
		RadixPingInfo pingInfo = parser.getPingInfo(destIp, day);
		if(pingInfo == null || pingInfo.getPingdata().size() == 0) {
			return getDelayEmptyChart(day);
		}
		
		LineChart lc = new LineChart().setDotStyle(new AbstractDot.Style(AbstractDot.Style.Type.H0LLOW_DOT, null,2 /* 数据点半径 */, 1 /* 数据点与连线间的间隔 */)).setWidth(3);
		lc.setOnShow(new OnShow(OnShow.TYPE_POPUP)); // 设置显示动画效果
	
		Iterator<PingData> iter = pingInfo.getPingdata().iterator();
		
		int i = 1;
		double maxValue = 1;
		while(iter.hasNext()){
			PingData data = iter.next();
			float delay = data.getAvg();
			
			if(delay > maxValue) maxValue = delay;
			
			LineChart.ScatterDot sc = new LineChart.ScatterDot(data.getTimestamp()/1000, delay);
			lc.addDots(sc);
		}

		lc.setGradientFill(true);
		lc.setColour("#32B7FE");
		lc.setText("时延(ms)");
		chart.addElements(lc);
		
		// x轴数据
		XAxis xAxis = new XAxis();
		XAxisLabels xlabels = new XAxisLabels();
		xlabels.setRotation(Label.Rotation.HALF_DIAGONAL);
		xlabels.setText(getLabelText(day));
		
		long startTimeStamp = pingInfo.getPingdata().get(0).getTimestamp();
		long endTimeStamp = pingInfo.getPingdata().get(pingInfo.getPingdata().size() - 1).getTimestamp();

		long xStep = 3600;
		if(day > 1) xStep = 3600 * 24; 
		xAxis.setRange(startTimeStamp/1000, endTimeStamp/1000, xStep);
		xAxis.setXAxisLabels(xlabels);
		chart.setXAxis(xAxis);
		
		// y轴数据
		YAxis yAxis = new YAxis();
		yAxis.setRange(0, maxValue, getFixedYStep(maxValue));
		YAxisLabels yAxisLabels=new YAxisLabels();
		
		String unit = "ms";
		yAxisLabels.setText("#val#" + unit);
		yAxis.setYAxisLabels(yAxisLabels);
		
		chart.setYAxisAutoRange(false);
		chart.setYAxis(yAxis);
		
		return chart;
	}
	
	private Chart getLostEmptyChart(int day){
		Chart chart = new Chart();
		chart.setTitle(new Text("丢包率(%)"));
		
		// x轴数据
		XAxis xAxis = new XAxis();
		XAxisLabels xlabels = new XAxisLabels();
		xlabels.setRotation(Label.Rotation.HALF_DIAGONAL);
		xlabels.setText(getLabelText(day));
		long endTimeStamp = System.currentTimeMillis();
		long startTimeStamp = endTimeStamp - day * 24 * 3600000;
		long xStep = 3600;
		if(day > 1) xStep = 3600 * 24; 
		xAxis.setRange(startTimeStamp/1000, endTimeStamp/1000, xStep);
		xAxis.setXAxisLabels(xlabels);
		chart.setXAxis(xAxis);
		
		// y轴数据
		YAxis yAxis = new YAxis();
		yAxis.setRange(0, 100, 20);
		YAxisLabels yAxisLabels=new YAxisLabels();
		
		String unit = "%";
		yAxisLabels.setText("#val#" + unit);
		yAxis.setYAxisLabels(yAxisLabels);
		
		chart.setYAxisAutoRange(false);
		chart.setYAxis(yAxis);
		
		return chart;
		
	}
	private Chart getDelayEmptyChart(int day){
		Chart chart = new Chart();
		chart.setTitle(new Text("时延(ms)"));
		
		// x轴数据
		XAxis xAxis = new XAxis();
		XAxisLabels xlabels = new XAxisLabels();
		xlabels.setRotation(Label.Rotation.HALF_DIAGONAL);
		xlabels.setText(getLabelText(day));
		long endTimeStamp = System.currentTimeMillis();
		long startTimeStamp = endTimeStamp - day * 24 * 3600000;
		long xStep = 3600;
		if(day > 1) xStep = 3600 * 24; 
		xAxis.setRange(startTimeStamp/1000, endTimeStamp/1000, xStep);
		xAxis.setXAxisLabels(xlabels);
		chart.setXAxis(xAxis);
		
		// y轴数据
		YAxis yAxis = new YAxis();
		yAxis.setRange(0, 1, 1);
		YAxisLabels yAxisLabels=new YAxisLabels();
		
		String unit = "ms";
		yAxisLabels.setText("#val#" + unit);
		yAxis.setYAxisLabels(yAxisLabels);
		
		chart.setYAxisAutoRange(false);
		chart.setYAxis(yAxis);
		
		return chart;
		
	}
	
	private String getLabelText(int day){
		String labelText = "#date:m-d#";
		if(day <= 1){
			labelText = "#date:H:i#";
		}else {
			labelText = "#date:m-d#";
		}
		return labelText;
	}
	
	/**
	 * 计算一个合适的y轴步长
	 * @param maxValue
	 * @return
	 */
	private long getFixedYStep(double maxValue){
		long step = 1;
		if(step >= maxValue) return step;
		
		while(step < maxValue){
			step *= 10;
		}
		return step/10;
	}
	
	/**
	 * 获取流控设备链路缓存
	 * @return
	 */
	@At
	@Ok("json")
	@Fail("json")
	public Map<String, RadixPingInfo> getRadixPingCache(){
		return RadixCacheManager.me().getLinkCacheMap();
	}
	
	/**
	 * 设置链路是否使用调试模式，调试模式使用模拟数据
	 * @param mode
	 * @return
	 */
	@At
	@Ok("json")
	public String setDebugMode(@Param("debug") String mode){
		if("on".equals(mode)){
			RadixPingInfoParser.linkDebugMode = true;
		}else{
			RadixPingInfoParser.linkDebugMode = false;
		}
		return mode;
	}
}
