package com.radixdigit.tcmanager.asset.polling;

/**
 * 流控设备链路缓存
 * @author gaoxl
 *
 */
public class RadixLinkCache {

	
	
}
