package com.radixdigit.tcmanager.asset.data.node;

import java.io.Serializable;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeInterface;

/**
 * 流控设备测试链路
 * @author gaoxl
 *
 */
@Table("radix_link")
public class RadixLink implements NodeInterface, Serializable{
	/**
	 * 连接id
	 */
	@Column
	@Id(auto = false)
	private long id;

	/**
	 * 连接名称
	 */
	@Column
	private String name = "";

	/**
	 * 节点类型
	 */
	
	private int category = NodeConstant.RADIX_LINK;

	/**
	 * 管理开关：是否接受管理
	 */
	@Column
	private int manageSwitch = 0;

	/**
	 * 状态
	 */
	@Column
	private int status;

	/**
	 * 描述
	 */
	@Column
	private String description;

	/**
	 * 创建时间
	 */
	@Column
	private long timeCreate;

	/**
	 * 修改时间
	 */
	@Column
	private long timeModify;
	
	
	@Override
	public long getId() {
		return this.id;
	}

	@Override
	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int getCategory() {
		return this.category;
	}

	@Override
	public void setCategory(int category) {
		this.category = category;
	}

	@Override
	public int getManageSwitch() {
		return this.manageSwitch;
	}

	@Override
	public void setManageSwitch(int manageSwitch) {
		this.manageSwitch = manageSwitch;
	}

	@Override
	public int getStatus() {
		return this.status;
	}

	@Override
	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String getDescription() {
		return this.description;
	}

	@Override
	public void setDescription(String desc) {
		this.description = desc;
	}

	@Override
	public long getTimeCreate() {
		return this.timeCreate;
	}

	@Override
	public void setTimeCreate(long timeCreate) {
		this.timeCreate = timeCreate;

	}

	@Override
	public long getTimeModify() {
		return this.timeModify;
	}

	@Override
	public void setTimeModify(long timeModify) {
		this.timeModify = timeModify;

	}
	
	private String sourceIp;
	
	private String destIp;
	
	private float lost;
	
	private long time;
	
	private float min;
	
	private float max;
	
	private float avg;
	
	private float mdev;


	public String getSourceIp() {
		return sourceIp;
	}

	public void setSourceIp(String sourceIp) {
		this.sourceIp = sourceIp;
	}

	public String getDestIp() {
		return destIp;
	}

	public void setDestIp(String destIp) {
		this.destIp = destIp;
	}

	public float getLost() {
		return lost;
	}

	public void setLost(float lost) {
		this.lost = lost;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	public float getMin() {
		return min;
	}

	public void setMin(float min) {
		this.min = min;
	}

	public float getMax() {
		return max;
	}

	public void setMax(float max) {
		this.max = max;
	}

	public float getAvg() {
		return avg;
	}

	public void setAvg(float avg) {
		this.avg = avg;
	}

	public float getMdev() {
		return mdev;
	}

	public void setMdev(float mdev) {
		this.mdev = mdev;
	}

	@Override
	public int getBuiltIn() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setBuiltIn(int builtIn) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getIcon() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setIcon(String icon) {
		// TODO Auto-generated method stub
		
	}
	
	
}
