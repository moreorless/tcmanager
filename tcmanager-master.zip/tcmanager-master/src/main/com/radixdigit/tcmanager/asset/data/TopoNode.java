package com.radixdigit.tcmanager.asset.data;

public class TopoNode {

	
	private long id;
	private int x;
	private int y;
	private int viewMode;		// 显示类型 图标 详图 略图
	public int getViewMode() {
		return viewMode;
	}
	public void setViewMode(int viewMode) {
		this.viewMode = viewMode;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
}
