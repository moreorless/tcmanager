/**
 
 * Author: wangxh
 * Created: 2011-5-24
 */
package com.radixdigit.tcmanager.asset.dao.node;

import java.util.List;

import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.dao.impl.NutDao;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.data.node.AssetInterface;
import com.radixdigit.tcmanager.commons.mvc.Pager;


/**
 * @author wangxh
 *
 */
@IocBean(name = "interfaceDao", fields = { "dataSource" })
public class InterfaceDao  extends NutDao {

	public Pager<AssetInterface> queryByIp(Pager<AssetInterface> pager,String ip){
		return enPager(pager,Cnd.where("ip","=",ip));
	}
	
	private Pager<AssetInterface> enPager(Pager<AssetInterface> pager, Condition cnd) {
		org.nutz.dao.pager.Pager nutzPager = null;

		if (pager != null) {
			nutzPager = this.createPager(pager.getPage(), pager.getPageSize());
		} else {
			pager = new Pager<AssetInterface>();
		}

		List<AssetInterface> ls = this.query(AssetInterface.class, cnd, nutzPager);
		pager.setRecords(this.count(AssetInterface.class, cnd));
		pager.setData(ls);
		return pager;
	}
	
	/**
	 * 获取全部接口
	 * @return
	 */
	public List<AssetInterface> queryAll(){
		return this.query(AssetInterface.class,null,null);
	}
}
