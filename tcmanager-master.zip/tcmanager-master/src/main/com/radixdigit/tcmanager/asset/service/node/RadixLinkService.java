package com.radixdigit.tcmanager.asset.service.node;

import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.dao.node.NodeDao;
import com.radixdigit.tcmanager.asset.dao.node.RadixLinkDao;
import com.radixdigit.tcmanager.asset.data.node.RadixLink;
import com.radixdigit.tcmanager.monitor.view.data.RadixInterfaceItemData;

@IocBean
public class RadixLinkService extends NodeService<RadixLink>{
	private RadixLinkDao radixLinkDao;
	
	@Inject("refer:radixLinkDao")
	@Override
	public void setNodeDao(NodeDao<RadixLink> dao) {
		setDao(dao);
		radixLinkDao = (RadixLinkDao)dao;
	}

	@Override
	public int clearLinks(long... ids) {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * 根据ip查询
	 * @param sourceIp
	 * @param destIp
	 * @return
	 */
	public RadixLink queryByIp(String sourceIp, String destIp){
		return radixLinkDao.queryByIp(sourceIp, destIp);
	}
	
}
