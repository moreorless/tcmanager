/**
 
 * Author: wangxh
 * Created: 2011-4-12
 */
package com.radixdigit.tcmanager.asset.data.node;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.One;
import org.nutz.dao.entity.annotation.Table;

import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeInterface;
import com.radixdigit.tcmanager.commons.mvc.validate.annotation.ValidateType;
import com.radixdigit.tcmanager.commons.mvc.validate.annotation.ValidateType.Type;
import com.radixdigit.tcmanager.commons.mvc.validate.annotation.Validations;

/**
 * 资产对象
 * 
 * @author wangxh
 * 
 */
@Table("asset")
public class Asset implements NodeInterface, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;	

	/**
	 * 资产id
	 */
	@Column
	@Id(auto = false)
	private long id;

	/**
	 * 资产名称
	 */
	@Column
	@Validations(rules={@ValidateType(type=Type.required, errorMsg="asset.verification.name.null",resource=true, bundle="i18n_asset"),
            @ValidateType(type=Type.maxlength, parameters={"255"}, errorMsg="asset.verification.name.toolong",resource=true, bundle="i18n_asset")})
	private String name;

	
	/**
	 * 资产别名
	 */
	@Column
	@Validations(rules={@ValidateType(type=Type.maxlength, parameters={"255"}, errorMsg="asset.verification.maxlength256",resource=true, bundle="i18n_asset")})
	private String alias;
	
	/**
	 * 节点类型
	 */

	private int category = NodeConstant.NODETYPE_ASSET;

	/**
	 * 管理开关：资产是否接受管理
	 */
	@Column
	private int manageSwitch;

	
	/**
	 * 管理组Id  -- 默认根分组
	 */
	@Column
	private long manageGroupId = NodeConstant.ID_ROOT;
	
	/**
	 * 资产状态
	 * 1 在线
	 * 2 不在线
	 */
	@Column
	private int status;

	/**
	 * 资产描述
	 */
	@Column
	private String description;

	/**
	 * 资产创建时间
	 */
	@Column
	private long timeCreate;

	/**
	 * 资产修改时间
	 */
	@Column
	private long timeModify;

	// -- 以下为资产专有属性

	/**
	 * 资产类型(关联asset_v_type的id)
	 */
	@Column
	private String type;
	
	/**
	 * 虚拟化资产类型
	 * 取值范围
	 * {@value com.radixdigit.tcmanager.asset.data.NodeConstant#VIRTUAL_NONE}	
	 * {@value com.radixdigit.tcmanager.asset.data.NodeConstant#VIRTUAL_SERVER}	
	 * {@value com.radixdigit.tcmanager.asset.data.NodeConstant#VIRTUAL_MACHINE}	
	 */
	@Column
	private int virtualType = NodeConstant.VIRTUAL_NONE;
	
	/**
	 * 网络区域ID
	 */
	@Column
	private int netdistrictId;
	
	/**
	 * 资产IP(管理ip)
	 * 支持ipv4和ipv6以及混合模式
	 */
	@Column
	
	/**
	 * IP
	 */
	@Validations(rules={@ValidateType(type=Type.required, errorMsg="asset.verification.ip.null",resource=true, bundle="i18n_asset"), 
			@ValidateType(type=Type.ip, errorMsg="asset.verification.ip.legal",resource=true, bundle="i18n_asset") })
	private String ip;

	/**
	 * 资产接口
	 */
	private List<AssetInterface> interfaces;	
	
	/**
	 * 子网掩码
	 */
	@Column
	private String mask;

	/**
	 * MAC地址
	 */
	@Column
	private String mac;

	/**
	 * 服务端口
	 */
	@Column
	private int servicePort;

	/**
	 * 资产所属单位id (存在部门表时，用该字段关联部门表)
	 */
	@Column
	private long departmentId;
	
	/**
	 * 所属部门
	 */
	@Column
	private String department;
	
	/**
	 * 所属业务系统
	 */
	@Column
	private String business;
	
	/**
	 * 联系人
	 */
	@Column
	private String contact;

	/**
	 * 资产位置
	 */
	@Column
	private String location;

	/**
	 * 制造商
	 */
	@Column
	private String manufacturer;
	
	/**
	 * 资产编码
	 */
	@Column
	private String assetCode;
	

	/**
	 * 序列号
	 */
	@Column
	private String sn;

	/**
	 * 硬件版本号
	 */
	@Column
	private String hardVersion;

	/**
	 * 软件版本号
	 */
	@Column
	private String softVersion;

	/**
	 * 软件安装路径
	 */
	@Column
	private String installPath;
	
	/**
	 * 业务关键度
	 */
	@Column
	private double kpi;

	/**
	 * 机密性 取值(1-5)
	 */
	@Column
	private int confidentiality;

	/**
	 * 完整性 取值(1-5)
	 */
	@Column
	private int integrity;

	/**
	 * 可用性 取值(1-5)
	 */
	@Column
	private int availability;

	/**
	 * 等保等级
	 */
	@Column
	private int protectLevel=1;
	
	/**
	 * 资产价值
	 */
	@Column
	private double value;

	/**
	 * 价值赋值方式
	 */
	@Column
	private int assignType;

	/**
	 * 外部系统id
	 */
	@Column
	private String externalSysid;

	/**
	 * 主资产ID
	 */
	@Column
	private long masterId;
	
	/**
	 * IP转换成10进制数字(IP范围查询用)
	 */
	@Column
	private long ipnum10;
	
	/**
	 * 将IP转换为十六进制字符串
	 * 支持ipv4和ipv6以及混合模式
	 */
	@Column
	private String ipHexadecimal;

	/**
	 * 主从关系类型
	 */
	@Column
	private int innerRelation;

	
	/**
	 * 备用字段1
	 */
	@Column
	private int standby1;

	/**
	 * 备用字段2
	 */
	@Column
	private int standby2;

	/**
	 * 备用字段3
	 */
	@Column
	private long standby3;

	/**
	 * 备用字段4
	 */
	@Column
	private long standby4;

	/**
	 * 备用字段5
	 */
	@Column
	private String standby5;

	/**
	 * 备用字段6
	 */
	@Column
	private String standby6;

	/**
	 * 管理URL
	 */
	@Column
	private String manageUrl = "";
	
	/**
	 * 请求方式(get / post)
	 */
	@Column
	private String method;
	
	/**
	 * 用户名
	 */
	@Column
	private String username;
	
	/**
	 * 密码
	 */
	@Column
	private String password;
	
	/**
	 * 密码加密方式
	 */
	@Column
	private String encryption;
	
	/**
	 * 存放资产的预留字段及对应的值
	 */
	@Column
	private String reserveFields;
	
	public String getReserveFields() {
		return reserveFields;
	}

	public void setReserveFields(String reserveFields) {
		this.reserveFields = reserveFields;
	}

	/**
	 * 扩展属性
	 */
	//将extendProperty由HashMap改为Map
	private Map extendProperty;
	
	/**
	 * 是否内置：1-是；2-否
	 */
	private int builtIn;
	/**
	 * 图标
	 */
	private String icon;
	
	/*-------------------------新增字段-start-------------------------------*/
	/**
	 * 资产购置时间
	 */
	@Column
	private long timePurchase;
	private String timePurchase_str;//用于前台页面显示
	
	/**
	 * 保修期限
	 */
	@Column
	private long expiredDate;
	private String expiredDate_str;//用于前台页面显示
	/**
	 * 表示该资产是否已经过了质保的期限
	 * true:是
	 * false:否
	 */
	private String expiredFlag;
	/*-------------------------新增字段-end-------------------------------*/
	

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getExpiredFlag() {
		return expiredFlag;
	}

	public void setExpiredFlag(String expiredFlag) {
		this.expiredFlag = expiredFlag;
	}

	public String getIp() {
		return ip;
	}

	public void setMask(String mask) {
		this.mask = mask;
	}

	public String getMask() {
		return mask;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	public int getServicePort() {
		return servicePort;
	}

	public void setServicePort(int servicePort) {
		this.servicePort = servicePort;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getHardVersion() {
		return hardVersion;
	}

	public void setHardVersion(String hardVersion) {
		this.hardVersion = hardVersion;
	}

	public String getSoftVersion() {
		return softVersion;
	}

	public void setSoftVersion(String softVersion) {
		this.softVersion = softVersion;
	}

	public double getKpi() {
		return kpi;
	}

	public void setKpi(double kpi) {
		this.kpi = kpi;
	}

	public int getConfidentiality() {
		return confidentiality;
	}

	public void setConfidentiality(int confidentiality) {
		this.confidentiality = confidentiality;
	}

	public int getIntegrity() {
		return integrity;
	}

	public void setIntegrity(int integrity) {
		this.integrity = integrity;
	}

	public int getAvailability() {
		return availability;
	}

	public void setAvailability(int availability) {
		this.availability = availability;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

	public int getAssignType() {
		return assignType;
	}

	public void setAssignType(int assignType) {
		this.assignType = assignType;
	}

	public String getExternalSysid() {
		return externalSysid;
	}

	public void setExternalSysid(String externalSysid) {
		this.externalSysid = externalSysid;
	}

	public int getStandby1() {
		return standby1;
	}

	public void setStandby1(int standby1) {
		this.standby1 = standby1;
	}

	public int getStandby2() {
		return standby2;
	}

	public void setStandby2(int standby2) {
		this.standby2 = standby2;
	}

	public long getStandby3() {
		return standby3;
	}

	public void setStandby3(long standby3) {
		this.standby3 = standby3;
	}

	public long getStandby4() {
		return standby4;
	}

	public void setStandby4(long standby4) {
		this.standby4 = standby4;
	}

	public String getStandby5() {
		return standby5;
	}

	public void setStandby5(String standby5) {
		this.standby5 = standby5;
	}

	public String getStandby6() {
		return standby6;
	}

	public void setStandby6(String standby6) {
		this.standby6 = standby6;
	}

	@Override
	public long getId() {
		return this.id;
	}

	@Override
	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int getCategory() {
		return this.category;
	}

	@Override
	public void setCategory(int category) {
		this.category = category;
	}

	@Override
	public int getManageSwitch() {
		return this.manageSwitch;
	}

	@Override
	public void setManageSwitch(int manageSwitch) {
		this.manageSwitch = manageSwitch;
	}

	@Override
	public int getStatus() {
		return this.status;
	}

	@Override
	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String getDescription() {
		return this.description;
	}

	@Override
	public void setDescription(String desc) {
		this.description = desc;
	}

	@Override
	public long getTimeCreate() {
		return this.timeCreate;
	}

	@Override
	public void setTimeCreate(long timeCreate) {
		this.timeCreate = timeCreate;

	}

	@Override
	public long getTimeModify() {
		return this.timeModify;
	}

	@Override
	public void setTimeModify(long timeModify) {
		this.timeModify = timeModify;

	}

	public void setExtendProperty(Map extendProperty) {
		this.extendProperty = extendProperty;
	}

	public Map getExtendProperty() {
		return extendProperty;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setMasterId(long masterId) {
		this.masterId = masterId;
	}

	public long getMasterId() {
		return masterId;
	}

	public void setInnerRelation(int innerRelation) {
		this.innerRelation = innerRelation;
	}

	public int getInnerRelation() {
		return innerRelation;
	}

	public void setNetdistrictId(int netdistrictId) {
		this.netdistrictId = netdistrictId;
	}

	public int getNetdistrictId() {
		return netdistrictId;
	}

	public void setDepartmentId(long departmentId) {
		this.departmentId = departmentId;
	}

	public long getDepartmentId() {
		return departmentId;
	}

	public long getManageGroupId() {
		return manageGroupId;
	}

	public void setManageGroupId(long manageGroupId) {
		this.manageGroupId = manageGroupId;
	}

	public List<AssetInterface> getInterfaces() {
		return interfaces;
	}

	public void setInterfaces(List<AssetInterface> interfaces) {
		this.interfaces = interfaces;
	}

	public String getAssetCode() {
		return assetCode;
	}

	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}

	public int getVirtualType() {
		return virtualType;
	}

	public void setVirtualType(int virtualType) {
		this.virtualType = virtualType;
	}
	/**
	 * 是否内置：1-是；2-否
	 * @return
	 */
	public int getBuiltIn(){
		return this.builtIn;
	}
	/**
	 * 
	 * @param builtIn
	 */
	public void setBuiltIn(int builtIn){
		this.builtIn=builtIn;
	}
	/**
	 * 图标
	 * @return
	 */
	public String getIcon(){
		return this.icon;
	}
	/**
	 * 
	 * @param icon
	 */
	public void setIcon(String icon){
		this.icon=icon;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public int getProtectLevel() {
		return protectLevel;
	}

	public void setProtectLevel(int protectLevel) {
		this.protectLevel = protectLevel;
	}

	public String getManageUrl() {
		return manageUrl;
	}

	public void setManageUrl(String manageUrl) {
		this.manageUrl = manageUrl;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEncryption() {
		return encryption;
	}

	public void setEncryption(String encryption) {
		this.encryption = encryption;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}
	
	public long getIpnum10() {
		return ipnum10;
	}

	public void setIpnum10(long ipnum10) {
		this.ipnum10 = ipnum10;
	}

	public String getIpHexadecimal() {
		return ipHexadecimal;
	}

	public void setIpHexadecimal(String ipHexadecimal) {
		this.ipHexadecimal = ipHexadecimal;
	}

	public long getTimePurchase() {
		return timePurchase;
	}

	public void setTimePurchase(long timePurchase) {
		this.timePurchase = timePurchase;
	}

	public long getExpiredDate() {
		return expiredDate;
	}

	public void setExpiredDate(long expiredDate) {
		this.expiredDate = expiredDate;
	}

	public String getTimePurchase_str() {
		return timePurchase_str;
	}

	public void setTimePurchase_str(String timePurchase_str) {
		this.timePurchase_str = timePurchase_str;
	}

	public String getExpiredDate_str() {
		return expiredDate_str;
	}

	public void setExpiredDate_str(String expiredDate_str) {
		this.expiredDate_str = expiredDate_str;
	}

	public String getInstallPath() {
		return installPath;
	}

	public void setInstallPath(String installPath) {
		this.installPath = installPath;
	}

	
	
}
