package com.radixdigit.tcmanager.asset.dao.node;

import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.data.node.RadixLink;

@IocBean(fields = { "dataSource" })
public class RadixLinkDao extends NodeDao<RadixLink>{

	/**
	 * 根据ip查询
	 * @param sourceIp
	 * @param destIp
	 * @return
	 */
	public RadixLink queryByIp(String sourceIp, String destIp){
		Condition cnd = Cnd.where("sourceIp", "=", sourceIp).and("endIp", "=", destIp);
		return this.fetch(RadixLink.class, cnd);
	}
}
