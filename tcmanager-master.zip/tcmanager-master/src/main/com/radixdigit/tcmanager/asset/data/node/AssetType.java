/**
 
 * Author: wangxh
 * Created: 2011-4-14
 */
package com.radixdigit.tcmanager.asset.data.node;

import java.io.Serializable;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

import com.radixdigit.tcmanager.asset.data.NodeConstant;

/**
 * 资产类型
 */
@Table("asset_v_type")
public class AssetType implements Serializable {
	/**
	 * 节点ID
	 */
	@Column
	@Id(auto = false)
	private long id;

	/**
	 * 节点名称
	 */
	@Column
	private String name;


	/**
	 * 类型编码
	 */
	@Column
	private String code;


	/**
	 * 类型图标
	 */
	@Column
	private String icon;

	/**
	 * 是否内置：1-是；2-否
	 */
	@Column
	private int builtIn;
	
	
	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	
	public String getName() {
		return this.name;
	}

	
	public void setName(String name) {
		this.name = name;
	}

	
	public String getDescription() {
		return null;
	}

	
	public void setDescription(String desc) {
		return;
	}

	
	public long getTimeCreate() {
		return NodeConstant.RETURN_INVALID;
	}

	
	public void setTimeCreate(long timeCreate) {
		return;

	}

	
	public long getTimeModify() {
		return NodeConstant.RETURN_INVALID;
	}

	
	public void setTimeModify(long timeModify) {
		return;

	}

	public void setBuiltIn(int builtIn) {
		this.builtIn = builtIn;
	}

	public int getBuiltIn() {
		return builtIn;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getIcon() {
		return icon;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	
}
