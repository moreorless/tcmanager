package com.radixdigit.tcmanager.asset.auth.data;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 * 资产认证对象
 */
@Table("asset_auth")
public class AssetAuth {
	
	public static final String PROTOCOL_SNMP = "snmp";
	public static final String PROTOCOL_SSH = "ssh";
	public static final String PROTOCOL_TELNET = "telnet";
	public static final String PROTOCOL_JDBC = "jdbc";
	public static final String PROTOCOL_WMI = "wmi";
	public static final String PROTOCOL_WEBSPHERE_XML = "websphere_xml";
	
	
	/**
	 * 认证ID
	 */
	@Column
	@Id(auto = false)
	private long id;
	/**
	 * IP地址
	 */
	@Column
	private String ip;
	/**
	 * 网络区域ID
	 */
	@Column
	private long netDistrictId;
	/**
	 * URL
	 */
	@Column
	private String url;
	/**
	 * 认证协议
	 */
	@Column
	private String protocol;
	/**
	 * 认证端口
	 */
	@Column
	private int port;
	/**
	 * 实例名（数据库）
	 */
	@Column
	private String instanceName;
	/**
	 * 用户名
	 */
	@Column("username")
	private String user;
	/**
	 * 密码
	 */
	@Column
	private String pwd;
	/**
	 * 特权密码
	 */
	@Column
	private String superPwd;
	/**
	 * SNMP版本
	 */
	@Column
	private int snmpVersion;
	/**
	 * 读团体串
	 */
	@Column
	private String getCommunity;
	/**
	 * 写团体串
	 */
	@Column
	private String setCommunity;
	/**
	 * V3安全等级
	 */
	@Column
	private int v3SecurityLevel;
	/**
	 * V3认证协议
	 */
	@Column
	private int v3AuthProtocol;
	/**
	 * V3认证密钥
	 */
	@Column
	private String v3AuthPwd;
	/**
	 * V3私有协议
	 */
	@Column
	private String v3PrivProtocol;
	/**
	 * V3私有密钥
	 */
	@Column
	private String v3PrivPwd;
	/**
	 * 命令行提示符
	 */
	@Column
	private String cmdPrompt;
	/**
	 * 描述
	 */
	@Column
	private String description;
	/**
	 * 备用字段1
	 */
	@Column
	private int standby1;
	/**
	 * 备用字段2
	 */
	@Column
	private int standby2;
	/**
	 * 备用字段3
	 */
	@Column
	private String standby3;
	/**
	 * 备用字段4
	 */
	@Column
	private String standby4;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public long getNetDistrictId() {
		return netDistrictId;
	}

	public void setNetDistrict(long netDistrictId) {
		this.netDistrictId = netDistrictId;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getSuperPwd() {
		return superPwd;
	}

	public void setSuperPwd(String superPwd) {
		this.superPwd = superPwd;
	}

	public int getSnmpVersion() {
		return snmpVersion;
	}

	public void setSnmpVersion(int snmpVersion) {
		this.snmpVersion = snmpVersion;
	}

	public String getGetCommunity() {
		return getCommunity;
	}

	public void setGetCommunity(String getCommunity) {
		this.getCommunity = getCommunity;
	}

	public String getSetCommunity() {
		return setCommunity;
	}

	public void setSetCommunity(String setCommunity) {
		this.setCommunity = setCommunity;
	}

	public int getV3SecurityLevel() {
		return v3SecurityLevel;
	}

	public void setV3SecurityLevel(int v3SecurityLevel) {
		this.v3SecurityLevel = v3SecurityLevel;
	}

	public int getV3AuthProtocol() {
		return v3AuthProtocol;
	}

	public void setV3AuthProtocol(int v3AuthProtocol) {
		this.v3AuthProtocol = v3AuthProtocol;
	}

	public String getV3AuthPwd() {
		return v3AuthPwd;
	}

	public void setV3AuthPwd(String v3AuthPwd) {
		this.v3AuthPwd = v3AuthPwd;
	}

	public String getV3PrivProtocol() {
		return v3PrivProtocol;
	}

	public void setV3PrivProtocol(String v3PrivProtocol) {
		this.v3PrivProtocol = v3PrivProtocol;
	}

	public String getV3PrivPwd() {
		return v3PrivPwd;
	}

	public void setV3PrivPwd(String v3PrivPwd) {
		this.v3PrivPwd = v3PrivPwd;
	}

	public String getCmdPrompt() {
		return cmdPrompt;
	}

	public void setCmdPrompt(String cmdPrompt) {
		this.cmdPrompt = cmdPrompt;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getStandby1() {
		return standby1;
	}

	public void setStandby1(int standby1) {
		this.standby1 = standby1;
	}

	public int getStandby2() {
		return standby2;
	}

	public void setStandby2(int standby2) {
		this.standby2 = standby2;
	}

	public String getStandby3() {
		return standby3;
	}

	public void setStandby3(String standby3) {
		this.standby3 = standby3;
	}

	public String getStandby4() {
		return standby4;
	}

	public void setStandby4(String standby4) {
		this.standby4 = standby4;
	}
}