package com.radixdigit.tcmanager.asset.polling;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.nutz.dao.Cnd;
import org.nutz.ioc.Ioc;
import org.nutz.mvc.NutConfig;

import com.radixdigit.tcmanager.SetupListener;
import com.radixdigit.tcmanager.alert.data.Alert;
import com.radixdigit.tcmanager.alert.data.Alert.Type;
import com.radixdigit.tcmanager.alert.service.AlertService;
import com.radixdigit.tcmanager.asset.dao.node.LinkDao;
import com.radixdigit.tcmanager.asset.dao.node.RadixLinkDao;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.asset.data.node.Asset;
import com.radixdigit.tcmanager.asset.data.node.AssetLink;
import com.radixdigit.tcmanager.asset.data.node.RadixLink;
import com.radixdigit.tcmanager.asset.polling.RadixPollingService.NetInfoPollingThread;
import com.radixdigit.tcmanager.asset.service.NodeProxyService;
import com.radixdigit.tcmanager.asset.service.node.AssetLinkService;
import com.radixdigit.tcmanager.asset.service.node.AssetService;
import com.radixdigit.tcmanager.asset.service.node.RadixLinkService;
import com.radixdigit.tcmanager.monitor.core.dao.TaskStructDao;
import com.radixdigit.tcmanager.monitor.core.data.TaskStruct;
import com.radixdigit.tcmanager.monitor.core.data.alert.AlertCache;
import com.radixdigit.tcmanager.monitor.ext.radix.data.NetInfo;
import com.radixdigit.tcmanager.monitor.ext.radix.data.NetInfoParser;
import com.radixdigit.tcmanager.monitor.ext.radix.data.PingData;
import com.radixdigit.tcmanager.monitor.ext.radix.data.RadixPingInfo;
import com.radixdigit.tcmanager.monitor.ext.radix.data.RadixPingInfoParser;
import com.radixdigit.tcmanager.sysconfig.service.SysconfigService;

/**
 * 定时维护流控设备网络ping的信息
 * @author gaoxl
 *
 */
public class RadixPingService implements SetupListener {
	private volatile boolean runFlag = false;
	
	/**
	 * 设备状态轮询时间间隔
	 */
	private int pollingInterval = 30000;		// 30秒
	
	private Ioc ioc;
	
	private Thread pollThread = null;
	
	private NodeProxyService nodeProxyService;
	
	private AlertService alertService;
	
	private Map<String, Long> latestLostAlert = new HashMap<>();
	private Map<String, Long> latestDelayALert = new HashMap<>();
	
	
	
	
	@Override
	public void init(NutConfig config) {
		runFlag = true;
		
		ioc = config.getIoc();
		nodeProxyService = ioc.get(NodeProxyService.class);
		alertService = ioc.get(AlertService.class);
		
		pollThread = new Thread(new PollingThread(), "RadixLinkPollingThread");
		pollThread.start();
	}

	@Override
	public void destroy(NutConfig config) {
		runFlag = false;
		pollThread.interrupt();
	}
	
	class PollingThread implements Runnable{

		@Override
		public void run() {
			while (runFlag) {

				TaskStructDao tsDao = ioc.get(TaskStructDao.class);
				// 获取所有流控设备监控任务
				List<TaskStruct> tsList = tsDao.query(TaskStruct.class, Cnd.where("mtype", "=", "radixdigit"));
				
				Set<String> radixIps = new HashSet<>();
				for(TaskStruct ts : tsList){
					radixIps.add(ts.getIp());
				}
				// 删除缓存中已经不存在的流控设备内容
				Iterator<String> radixIpIter = RadixCacheManager.me().getLinkCacheMap().keySet().iterator();
				while(radixIpIter.hasNext()){
					String devIp = radixIpIter.next();
					if(!radixIps.contains(devIp)){
						RadixCacheManager.me().getLinkCacheMap().remove(devIp);
					}
				}
				
				
				if(tsList != null){
					Iterator<TaskStruct> iter = tsList.iterator();
					while(iter.hasNext()){
						TaskStruct ts = iter.next();
						// 读取流控设备ping信息，写入缓存
						RadixPingInfoParser parser = new RadixPingInfoParser(ts.getUrl());
						
						RadixPingInfo pingInfo = parser.getPingInfo();
						
						if(pingInfo != null){
							RadixCacheManager.me().getLinkCacheMap().put(ts.getIp(), pingInfo);
							handlePingInfo(pingInfo);
						}else{
							// 取不到数据，写入null
							//RadixCacheManager.me().getLinkCacheMap().remove(ts.getIp());
							RadixCacheManager.me().getLinkCacheMap().put(ts.getIp(), null);
						}
					}
				}
				
				try {
					Thread.sleep(pollingInterval);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		
		// 自动生成拓扑链路
		private void handlePingInfo(RadixPingInfo pingInfo){
			if(pingInfo == null) return;
			
			AssetService assetService = ioc.get(AssetService.class);
			LinkDao linkDao = ioc.get(LinkDao.class);
			AssetLinkService linkService = ioc.get(AssetLinkService.class);
			
			String sourceIp = pingInfo.getSourceip();
			
			if(pingInfo.getPingdata() == null) return;
			Iterator<PingData> iter = pingInfo.getPingdata().iterator();
			long curTime = System.currentTimeMillis();
			while(iter.hasNext()){
				PingData pingData = iter.next();

				if(pingData == null) continue;
				
				// 如果丢包率超过阈值，产生告警
				int lostThreshold = SysconfigService.me().getCurrentAlertParam().getPingLostThreshold();
				if(pingData.getLost() > lostThreshold){
					Alert alert = new Alert();
					alert.setDevIp(pingData.getDestip());
					alert.setPriority(2);
					alert.setTimeCreated(curTime);
					alert.setAlertSrc(Type.MONITOR);
					alert.setAlertType("link");
					alert.setTitle("链路丢包率告警");
					alert.setDescription("链路丢包率超过告警阈值[" + lostThreshold + "%]，当前值[" + pingData.getLost() +"%]");
					
					long lastOccuredTime = 0;
					if(latestLostAlert.containsKey(pingData.getDestip())){
						lastOccuredTime = latestLostAlert.get(pingData.getDestip());
					}
					long mergeRange = SysconfigService.me().getCurrentAlertParam().getMergeTimeRange();
					if(curTime > lastOccuredTime + mergeRange * 1000){
						alertService.insertAlert(alert);
						latestLostAlert.put(pingData.getDestip(), curTime);
					}
				}
				
				// 如果超过时延阈值，产生告警
				int delayThreashod = SysconfigService.me().getCurrentAlertParam().getPingDelayThreshold();
				if(pingData.getAvg() > delayThreashod){
					Alert alert = new Alert();
					alert.setDevIp(pingData.getDestip());
					alert.setPriority(2);
					alert.setTimeCreated(curTime);
					alert.setAlertSrc(Type.MONITOR);
					alert.setAlertType("link");
					alert.setTitle("链路时延告警");
					alert.setDescription("链路时延超过告警阈值[" + delayThreashod + "ms]，当前值[" + pingData.getAvg() +"ms]");

					long lastOccuredTime = 0;
					if(latestDelayALert.containsKey(pingData.getDestip())){
						lastOccuredTime = latestDelayALert.get(pingData.getDestip());
					}
					long mergeRange = SysconfigService.me().getCurrentAlertParam().getMergeTimeRange();
					if(curTime > lastOccuredTime + mergeRange * 1000){
						alertService.insertAlert(alert);
						latestDelayALert.put(pingData.getDestip(), curTime);
					}
				}
				
				/*
				 * del 20130803 不向数据库添加链路
				 * 
				String destIp = pingData.getDestip();
				
				Asset sourceDev = assetService.fetch(Cnd.where("ip", "=", sourceIp));
				Asset destDev = assetService.fetch(Cnd.where("ip", "=", destIp));
				
				if(sourceDev == null || destDev == null){
					continue;
				}
				NodeProxy sourceProxy = getNodeProxy(sourceDev.getId());
				NodeProxy destProxy = getNodeProxy(destDev.getId());
				
				List<AssetLink> linkList = linkDao.queryBySidEid(sourceProxy.getId(), destProxy.getId());
				
				// 添加连线到数据库中 
				if(linkList == null || linkList.size() == 0){
					AssetLink link = new AssetLink();
					link.setName(sourceIp + "-->" + destIp);
					link.setDescription(sourceIp + "-->" + destIp);
					link.setStartId(sourceProxy.getId());
					link.setEndId(destProxy.getId());
					link.setTimeCreate(curTime);
					link.setTimeModify(curTime);
					link.setWidth(2);

					NodeProxy proxy = new NodeProxy();
					proxy.setNode(link);
					proxy.setNodeType(NodeConstant.NODETYPE_LINK);
					proxy.setpNodeId(sourceProxy.getpNodeId());
					proxy.setpNodeType(NodeConstant.NODETYPE_GROUP);
					proxy.setViewType(NodeConstant.VIEW_MANAGE);
					linkService.addNode(proxy);
				}
				*/
			}
			
		}
		
		private NodeProxy getNodeProxy(long assetId){
			List<NodeProxy> proxyList = nodeProxyService.getProxyByNodeId(assetId, NodeConstant.NODETYPE_ASSET, NodeConstant.VIEW_MANAGE);
			if(proxyList !=null && proxyList.size() > 0){
				return proxyList.get(0);
			}
			return null;
		}
		
	}
	
}
