/**
 
 * Author: wangxh
 * Created: 2011-5-29
 */
package com.radixdigit.tcmanager.asset.dao.node;

import java.util.ArrayList;
import java.util.List;

import org.nutz.dao.Cnd;
import org.nutz.dao.Sqls;
import org.nutz.dao.sql.Sql;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.asset.data.node.AssetLink;

/**
 * @author wangxh
 * 
 */
@IocBean(name = "linkDao", fields = { "dataSource" })
public class LinkDao extends NodeDao<AssetLink> {

	/**
	 * 根据连线两端连接的节点ID，查询连线对象
	 * @param ids
	 * @return
	 */
	public List<AssetLink> queryByLinkedId(long... ids){
		if(ids==null|| ids.length==0){
			return new ArrayList<AssetLink>();
		}
		Cnd cnd=Cnd.where("startId","in",ids);
		cnd.or("endId","in",ids);
		return this.query(AssetLink.class,cnd,null);
	}
	
	/**
	 * 根据起始节点和结束节点ID 查找Link
	 * @param startId
	 * @param endId
	 * @return
	 */
	public List<AssetLink> queryBySidEid(long startId, long endId){
		if(startId ==0L|| endId == 0L){
			return new ArrayList<AssetLink>();
		}
		Cnd cnd=Cnd.where("startId","=",startId).and("endId","=",endId);
		return this.query(AssetLink.class,cnd,null);
	}
}
