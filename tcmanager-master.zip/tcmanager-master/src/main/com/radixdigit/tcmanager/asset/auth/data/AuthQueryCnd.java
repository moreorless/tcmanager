package com.radixdigit.tcmanager.asset.auth.data;

import java.io.Serializable;

/**
 * 认证信息查询条件
 */

public class AuthQueryCnd implements Serializable {
	/**
	 * 认证ID
	 */
	private long id;

	/**
	 * ip地址
	 */
	private String ip;
	/**
	 * 端口号
	 */
	private int port;
	/**
	 * 数据库实例名
	 */
	private String instanceName;
	/**
	 * URL
	 */
	private String url;
	/**
	 * 认证协议
	 */
	private String protocol;

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getIp() {
		return ip;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public int getPort() {
		return port;
	}

	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	public String getInstanceName() {
		return instanceName;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getProtocol() {
		return protocol;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getId() {
		return id;
	}

}
