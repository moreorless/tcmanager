package com.radixdigit.tcmanager.asset.service.node;

import java.util.List;

import org.nutz.dao.Cnd;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.data.node.AssetType;
import com.radixdigit.tcmanager.commons.service.TblIdsEntityService;

@IocBean(fields="dao")
public class AssetTypeService  extends TblIdsEntityService<AssetType> {

	public AssetType getByCode(String code){
		return dao().fetch(AssetType.class, Cnd.where("code", "=", code));
	}
	
	public AssetType getByName(String name){
		return dao().fetch(AssetType.class, Cnd.where("code", "=", name));
	}
	
	public List<AssetType> getAllTypes(){
		return dao().query(AssetType.class, null);
	}
}
