/**
 
 * Author: wangxh
 * Created: 2011-4-24
 */
package com.radixdigit.tcmanager.asset.data;

import java.io.Serializable;
import java.util.Properties;

/**
 * 节点常量定义
 * @author wangxh
 * 
 */
public final class NodeConstant implements Serializable {

	// --视图分类
	public static final int VIEW_MANAGE = 1;// 管理目录
	public static final int VIEW_CLASSIFY = 2;// 分类目录
	public static final int VIEW_SUBNET = 3;// 子网
	public static final int VIEW_BUSSINESS = 4;// 业务
	public static final int VIEW_SECUREDOMAIN = 5;// 安全域
	public static final int VIEW_RACK = 6;// 机架
	public static final int VIEW_ASSETTYPE = 7;// 资产类型目录
	public static final int VIEW_VIRTUAL = 8;// 虚拟化视图
	public static final int VIEW_VIRTUAL_NET = 9;// 虚拟化网络、端口组
	public static final int VIEW_VIRTUAL_DC = 10;// 虚拟化数据中心
	public static final int VIEW_VIRTUAL_CLUSTER = 11;// 虚拟化集群

	//--节点类型
	public static final int NODETYPE_ASSET = 1;// 资产
	public static final int NODETYPE_LINK = 2;// 连接
	public static final int NODETYPE_PIXEL = 3;// 辅助图元
	public static final int NODETYPE_GROUP = 4;// 组
	public static final int NODETYPE_RACK=5;	  // 机架
	public static final int NODETYPE_BUSINESS=6; // 业务
	public static final int RADIX_LINK = 7;		// radix链路
	
	// --虚拟化类型
	public static final int VIRTUAL_NONE = 0;		// 非虚拟化资产
	public static final int VIRTUAL_SERVER = 1;	// 虚拟服务器
	public static final int VIRTUAL_MACHINE = 2;	// 虚拟机
	public static final int VIRTUAL_HOST = 3; // (ESX、ESXi)主机
	public static final int VIRTUAL_NETWORK = 4; // 标准交换机网络(包括vlan)
	public static final int VIRTUAL_DVS_PORTGROUP = 5; // 分布式交换机端口组
	public static final int VIRTUAL_DATASTORE = 6; // 数据存储
	public static final int VIRTUAL_CENTERS = 7;//virtual centers
	public static final int VIRTUAL_DATACENTERS = 8; //datacenters
	public static final int VIRTUAL_CLUSTERS = 9; //Clusters
	public static final int VIRTUAL_RESOURCEPOOLS = 10; //resource pools
	public static final int VIRTUAL_VTD = 11; //vIDS
	public static final int VIRTUAL_UTM = 12; //vUTM
	public static final int VIRTUAL_VSS = 13; //标准交换机vSwitch
	public static final int VIRTUAL_VDS = 14; //分布式交换机Distribute vSwitch
	public static final int VIRTUAL_HOST_PORTGROUP = 15; // 标准交换机端口组
	
	public static final int VIRTUAL_VTJ = 16; //vTJ 天镜
	public static final int VIRTUAL_VTDSCENTER = 17; //vTdscenter 控制中心
	

	//--拓扑多态性 （表asset_relation中polymorphic字段）
	/*默认拓扑多态性为 nodeInfoPanel.jsp中，主机选项的组合*/
	public static final int POLYMOPHIC_TOPO_DEFAULT = NodeConstant.POLYMOPHIC_HOST2DATASTORE|NodeConstant.POLYMOPHIC_HOST2NET|NodeConstant.POLYMOPHIC_HOST2VM; 
	public static final int POLYMOPHIC_HOST2VM        =  0B00000001; // 主机到虚拟机
	public static final int POLYMOPHIC_HOST2NET       =  0B00000010; // 主机到网络
	public static final int POLYMOPHIC_HOST2DATASTORE =  0B00000100; // 主机到数据存储
	public static final int POLYMOPHIC_VM2NET         =  0B00001000; //虚拟机到网络
	public static final int POLYMOPHIC_VM2DATASTORE   =  0B00010000; //虚拟机到数据存储
	public static final int POLYMOPHIC_NETWORK_VIEW   =  0B00100000; // 网络视图
	
	// --节点状态
	public static final int STATUS_RUNNING = 1;//运行
	public static final int STATUS_UP = 1;//运行
	public static final int STATUS_STOP = 2;//停止
	public static final int STATUS_DOWN = 2;//停止
	public static final int STATUS_DISPLAY = 3;//显示
	public static final int STATUS_HIDE = 4;//隐藏
	public static final int STATUS_ENABLE = 5;//可用
	public static final int STATUS_DISABLE = 6;//不可用
	public static final int STATUS_ERROR = 7;//错误
	public static final int STATUS_ALERT = 8;//告警
	public static final int STATUS_NORMAL = 9;//正常
	public static final int STATUS_SELECTED = 10;//选中
	public static final int STATUS_UNSELECTED = 11;//没选中
	
	//--关联关系
	public static final int RELATE_BEARING=0;//服务承载
	public static final int RELATE_BACKUP=1;//冗余备份
	public static final int RELATE_VIRTUAL=2;//虚拟设备	
	
	//是否为系统内置
	public static final int BUILTDIN=1;//系统内置
	public static final int CUSTOM=2;//用户自定义
	
	//--节点管理状态
	public static final int MANAGE_ON = 1;//接受管理
	public static final int MANAGE_OFF = 0;//不管理
	
	//树的根节点编号
	public static final int ID_ROOT=0;
	public static final int UNGROUPED=1;//未分配组
	
	//标识拓扑
	public static final int TOPO_GROUPED = Integer.MAX_VALUE;
	//add by tanf
	public static final int MANAGE_ROOT_ID=1;//管理域根节点
	public static final int CLASSIFY_ROOT_ID=2;//资产分类根节点
	public static final int AllASSET_ID=0;//全部资产节点ID
	public static final int SUBNET_ROOT_ID=3;//拓扑根节点
	public static final int RACK_ROOT_ID=4;//机架根节点
	
	//线型
	public static final int LINE_STRAIGHT=0;//直线
	public static final int LINE_CURVE=1;//曲线
	public static final int LINE_POLY=2;//折线
	
	//线的虚实
	public static final int LINE_SOLID=0;//实线
	public static final int LINE_DOTTED=0;//虚线
	
	//导出内容
	public static final int EXPORT_ASSET=0;//资产
	public static final int EXPORT_ALL=1;//全部
	public static final int EXPORT_ENTITY=2;//实体资产（不含应用服务、虚拟系统）
	
	
	//返回结果
	public static final int RETURN_ERROR=-1;//错误，意义同NULL
	public static final int RETURN_INVALID=0;//无效操作（无异常抛出） 
	public static final int RETURN_NORMAL=1;//正常值
	
	//操作
	public static final int ACTION_WITH=1;//对节点和映射关系进行操作
	public static final int ACTION_LINKS=2;//只对映射关系进行操作
	public static final int ACTION_POINT=3;//只更新坐标
	
	//图形类型
	public static final int GRAPHTYPE_DEFAULT=1;//默认
	public static final int GRAPHTYPE_DETAIL=2;//详图
	public static final int GRAPHTYPE_SKETCH=3;//略图
	
	//属性类型--qianyin 资产属性自定义
	public final static int PROP_TYPE_STRING=0;//字符串
	public final static int PROP_TYPE_NUMBER=1;//数字
	public final static int PROP_TYPE_ENUM=2;//枚举值
	public final static int PROP_TYPE_DATE=3;//日期
	public final static int PROP_TYPE_DATETIME=4;//日期+时间
	public final static int PROP_TYPE_IP=5;//IP
	public final static int PROP_TYPE_PWD=6;//密码
	public final static int PROP_TYPE_BLOB=7;//BLOB
	
	// 扩展属性
	private Properties properties = new Properties();

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public Properties getProperties() {
		return properties;
	}
}
