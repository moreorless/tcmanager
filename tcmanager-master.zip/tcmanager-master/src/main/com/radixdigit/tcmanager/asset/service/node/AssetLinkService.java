/**
 
 * Author: wangxh
 * Created: 2011-5-26
 */
package com.radixdigit.tcmanager.asset.service.node;

import java.util.List;

import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.dao.NodeProxyDao;
import com.radixdigit.tcmanager.asset.dao.node.LinkDao;
import com.radixdigit.tcmanager.asset.dao.node.NodeDao;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.asset.data.node.AssetLink;

/**
 * 资产连接服务
 * 
 * @author wangxh
 */
@IocBean(name = "assetLinkService")
public class AssetLinkService extends NodeService<AssetLink>{

	
	private LinkDao linkDao;
	@Inject("refer:linkDao")
	
	@Override
	public void setNodeDao(NodeDao<AssetLink> dao) {
		setDao(dao);
		linkDao = (LinkDao)dao;
	}

	@Inject("refer:nodeProxyDao")
	private NodeProxyDao proxyDao;
	
	@Override
	public int clearLinks(long... endIds) {
		//根据连线两端ID，查询连线本身ID
		List<AssetLink> ls=((LinkDao)dao()).queryByLinkedId(endIds);
		if(ls==null || ls.size()==0){
			return NodeConstant.RETURN_INVALID;
		}
			
		int length=ls.size();
		long [] linkIds=new long[length];
		for(int i=0;i<length;i++){
			linkIds[i]=ls.get(i).getId();
		}
		
		//删除连线的关联关系
		nodeProxyDao.deleteProxyByNodeId(NodeConstant.NODETYPE_LINK, 0, linkIds);
		
		//删除连线本身
		return ((LinkDao)dao()).deleteById(linkIds);
	}

	/**
	 * 根据连线Id获取连线对象，已填充连线两端的节点代理数据。
	 * @param linkId
	 * @return
	 */
	public AssetLink getLink(long linkId){
		AssetLink link = linkDao.fetch(AssetLink.class, linkId);
		if(link != null){
			// 填充连线两端的代理节点
			NodeProxy startNodeProxy = proxyDao.getProxyByProxyId(link.getStartId());
			NodeProxy endNodeProxy = proxyDao.getProxyByProxyId(link.getEndId());
			
			link.setStartNodeProxy(startNodeProxy);
			link.setEndNodeProxy(endNodeProxy);
		}
		return link;
	}
	
}
