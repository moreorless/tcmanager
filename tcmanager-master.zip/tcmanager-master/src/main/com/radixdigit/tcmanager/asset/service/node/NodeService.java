/**
 
 * Author: wangxh
 * Created: 2011-6-2
 */
package com.radixdigit.tcmanager.asset.service.node;

import java.util.List;

import org.nutz.dao.Condition;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.lang.Mirror;
import org.nutz.log.Log;
import org.nutz.log.Logs;
import org.nutz.service.EntityService;

import com.radixdigit.tcmanager.asset.dao.NodeProxyDao;
import com.radixdigit.tcmanager.asset.dao.node.NodeDao;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeInterface;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.commons.mvc.Pager;
import com.radixdigit.tcmanager.commons.service.TblIdsEntityService;


/**
 * 节点服务通用接口
 * 
 * @author wangxh
 * @param <T>
 * 
 */
public abstract class NodeService<T extends NodeInterface> extends TblIdsEntityService<T> {

	@Inject("refer:nodeProxyDao")
	public NodeProxyDao nodeProxyDao;

	private Mirror<T> mirror;
	private static final Log log = Logs.getLog(EntityService.class);

	@SuppressWarnings("unchecked")
	public NodeService() {
		try {
			Class<T> entryClass = (Class<T>) Mirror.getTypeParam(getClass(),0);
			mirror = Mirror.me(entryClass);
			if (log.isDebugEnabled())
				log.debugf("Get TypeParams for self : %s", entryClass.getName());
		}
		catch (Throwable e) {
			if (log.isWarnEnabled())
				log.warn("!!!Fail to get TypeParams for self!", e);
		}
	}
	
	public int getNodeType(){
		return mirror.born().getCategory();
	}
	
	/**
	 * 设置节点dao
	 * @param dao
	 */
	public abstract void setNodeDao(NodeDao<T> dao);
	
	/**
	 * 获取组内的直属节点代理
	 * 
	 * @param groupId
	 * @param viewType
	 * @return
	 */
	public List<NodeProxy> getProxysInGroup(long groupId, int viewType) {
		return ((NodeDao) dao()).queryProxyInGroup(groupId, viewType);

	}

	/**
	 * 获取组内的直属节点（用于分页）
	 * 
	 * @param groupId
	 * @param viewType
	 * @param pager
	 * @return
	 */
	public Pager<T> getNodesInGroup(long groupId, int viewType, Pager<T> pager) {
		return ((NodeDao) dao()).queryNodeInGroup(groupId, viewType, null, pager);
	}

	/**
	 * 获取组内的直属节点（用于分页）
	 * 
	 * @param groupId
	 * @param viewType
	 * @param cnd 查询条件
	 * @param pager
	 * @return
	 */
	public Pager<T> getNodesInGroup(long groupId, int viewType, Condition cnd, Pager<T> pager) {
		return ((NodeDao) dao()).queryNodeInGroup(groupId, viewType, cnd, pager);
	}
	
	/**
	 * 添加节点及拓扑关系
	 * 
	 * @param proxy
	 * @return
	 */
	public NodeProxy addNode(NodeProxy proxy) {
		if (proxy == null || proxy.getNode() == null)
			return null;
		T t = (T) proxy.getNode();
		t.setId(getTblMaxIdWithUpdate());
		T node = null;
		try {
			node = dao().insert(t);
		}
		catch (Exception e) {
			log.error("add Node error", e);
			return null;
		}

		if (node != null) {
			proxy.setNodeId(node.getId());
			proxy.setNodeType(node.getCategory());
			
			NodeProxy[] nodeProxys = nodeProxyDao.addNodeProxy(proxy);
			if (nodeProxys != null && nodeProxys.length > 0) {
				return nodeProxys[0];
			}
		}
		return null;
	}

	/**
	 * 删除节点及拓扑关系
	 * 
	 * @param ids
	 * @return
	 */
	public int deleteNodes(long... ids) {
		if (ids == null || ids.length == 0) {
			return NodeConstant.RETURN_INVALID;
		}

		int result = ((NodeDao) dao()).deleteById(ids);
		if (result > 0) {
			clearLinks(ids);
			return deleteProxysByNodeId(0, ids);
		} else {
			return NodeConstant.RETURN_INVALID;
		}
	}

	/**
	 * 删除关联关系
	 * 
	 * @param viewType
	 * @param proxyIds
	 * @return
	 */
	protected int deleteProxysByNodeId(int viewType, long... proxyIds){
		return nodeProxyDao.deleteProxyByNodeId(getNodeType(), viewType, proxyIds);
	}

	/**
	 * 修改节点属性
	 * 
	 * @param nodes
	 * @return
	 */
	public int updateNodes(T... nodes) {
		if (nodes == null || nodes.length == 0)
			return NodeConstant.RETURN_INVALID;
		return dao().update(nodes);
	}

	/**
	 * 根据节点ID获取节点代理
	 * 
	 * @param nodeId
	 * @param viewType
	 * @return
	 */
	public List<NodeProxy> getProxyById(long nodeId, int viewType) {
		return ((NodeDao) dao()).queryProxyById(nodeId, viewType);
	}

	/**
	 * 根据节点ID获取节点对象
	 * 
	 * @param ids
	 * @return
	 */
	public List<T> getById(long... ids) {
		return ((NodeDao) this.dao()).queryById(ids);
	}

	/**
	 * 查询节点所归属的节点组
	 * 
	 * @param viewType
	 * @param nodeIds
	 * @return 节点组ID列表
	 */
	public long[] getGroupsOfNode(int viewType, long... nodeIds){
		List<NodeProxy> proxys = this.nodeProxyDao.queryGroupByNodeId(	viewType,
				getNodeType(),	nodeIds);
		if (proxys != null && proxys.size() > 0) {
			long[] groupIds = new long[proxys.size()];
			int i = 0;
			for (NodeProxy proxy : proxys) {
				groupIds[i] = proxy.getpNodeId();
				i++;
			}
			return groupIds;
		}
		return null;
	}
	
	public void updateStatus(NodeInterface node){
		((NodeDao)this.dao()).updateStatus(node);
	}

	/**
	 * 删除节点的连线
	 * 
	 * @param ids
	 *            节点ID
	 * @return
	 */
	public abstract int clearLinks(long... ids);

}
