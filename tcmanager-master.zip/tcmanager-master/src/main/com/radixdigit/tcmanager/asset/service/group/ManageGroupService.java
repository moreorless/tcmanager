/**
 
 * Author: wangxh
 * Created: 2011-6-3
 */
package com.radixdigit.tcmanager.asset.service.group;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.nutz.dao.Dao;
import org.nutz.ioc.Ioc;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.dao.group.ManageGroupDao;
import com.radixdigit.tcmanager.asset.dao.group.NodeGroupDao;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeInterface;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.asset.data.group.ManageGroup;
import com.radixdigit.tcmanager.asset.service.NodeProxyService;
import com.radixdigit.tcmanager.asset.service.node.AssetLinkService;
import com.radixdigit.tcmanager.asset.service.node.AssetService;

/**
 * @author wangxh
 * 
 */

@IocBean(name="manageGroupService")
public class ManageGroupService extends NodeGroupService<ManageGroup> {

	@Inject("refer:manageGroupDao")
	@Override
	public void setNodeGroupDao(NodeGroupDao<ManageGroup> dao) {
		setDao(dao);
	}
	@Override
	public NodeGroupDao<ManageGroup> getNodeGroupDao(){
		return (NodeGroupDao)dao();
	}

	@Inject("refer:assetLinkService")
	private AssetLinkService linkService;

	@Inject("refer:nodeProxyService")
	private NodeProxyService nodeProxyService;
	
	@Inject("refer:assetService")
	private AssetService assetService;
	
	@Override
	public int getViewType() {
		return NodeConstant.VIEW_MANAGE;
	}

	@Override
	protected int clearRecurve(long... ids) {
		for (long id : ids) {
			Map<Integer, long[]> idMap = getNodesRecursive(id);			
			nodeProxyService.deleteProxy(idMap.get(0));
			assetService.deleteNodes(idMap.get(NodeConstant.NODETYPE_ASSET));
			linkService.deleteNodes(idMap.get(NodeConstant.NODETYPE_LINK));
			deleteGroups(idMap.get(NodeConstant.NODETYPE_GROUP));
		}
		return ids.length;
	}
	
	/**
	 * 删除组本身及连线
	 * @param ids
	 */
	private void deleteGroups(long... ids) {
		if (ids == null || ids.length == 0) {
			return ;
		}

		int result = ((ManageGroupDao) dao()).deleteById(ids);
		if (result > 0) {
			clearLinks(ids);
		}
	}

	/**
	 * 递归读取组、子组内的所有节点信息（包括子组、资产、辅助图元、连接等）
	 * 
	 * @param groupId
	 * @param viewType
	 * @return
	 */
	public Map<Integer, long[]> getNodesRecursive(long groupId) {
		
		//递归获取所有节点代理
		List<NodeProxy> proxys = nodeProxyService.getProxysRecursive(groupId,
				NodeConstant.VIEW_MANAGE);
		
		//将当前组代理加入集合
		NodeProxy currentGroup=nodeProxyService.getProxyByNodeId(groupId, NodeConstant.NODETYPE_GROUP,NodeConstant.VIEW_MANAGE).get(0);
		proxys.add(currentGroup);
		
		//按节点类型提取节点ID的集合
		List<Long> groupIds = new ArrayList<Long>();
		List<Long> assetIds = new ArrayList<Long>();
		List<Long> linkIds = new ArrayList<Long>();
		List<Long> pixelIds = new ArrayList<Long>();
		

		long[] proxyIdsl = new long[proxys.size()];
		int i = 0;
		for (NodeProxy proxy : proxys) {
			//组装节点关系ID集合
			proxyIdsl[i] = proxy.getId();
			i++;

			switch (proxy.getNodeType()) {
			case NodeConstant.NODETYPE_ASSET:
				assetIds.add(proxy.getNodeId());
				break;
			case NodeConstant.NODETYPE_LINK:
				linkIds.add(proxy.getNodeId());
				break;
			case NodeConstant.NODETYPE_PIXEL:
				pixelIds.add(proxy.getNodeId());
				break;
			case NodeConstant.NODETYPE_GROUP:
				groupIds.add(proxy.getNodeId());
				break;
			default:
				break;
			}
		}

		int[] idLength = new int[] { groupIds.size() + 1, assetIds.size(),
				linkIds.size(), pixelIds.size() };
		long[] groupIdsl = new long[idLength[0]];
		long[] assetIdsl = new long[idLength[1]];
		long[] linkIdsl = new long[idLength[2]];
		long[] pixelIdsl = new long[idLength[3]];

		Map<Integer, long[]> result = new HashMap<Integer, long[]>();
		result.put(NodeConstant.NODETYPE_GROUP, groupIdsl);
		result.put(NodeConstant.NODETYPE_ASSET, assetIdsl);
		result.put(NodeConstant.NODETYPE_LINK, linkIdsl);
		result.put(NodeConstant.NODETYPE_PIXEL, pixelIdsl);
		result.put(0, proxyIdsl);//节点关系

		groupIdsl[0] = groupId;
		for (int j = 1; j < idLength[0]; j++) {
			groupIdsl[j] = groupIds.get(j-1);
		}
		for (int j = 0; j < idLength[1]; j++) {
			assetIdsl[j] = assetIds.get(j);
		}
		for (int j = 0; j < idLength[2]; j++) {
			linkIdsl[j] = linkIds.get(j);
		}
		for (int j = 0; j < idLength[3]; j++) {
			pixelIdsl[j] = pixelIds.get(j);
		}
		return result;
	}

	
	/**
	 * 读取节点的组代理
	 * 组节点信息已自动赋值
	 * @param nodeId
	 * @param nodeType
	 * @return
	 */
	public ManageGroup getParentGroupOfNode(long nodeId, int nodeType) {
		List<NodeProxy> proxys = this.nodeProxyDao.queryGroupByNodeId(
				NodeConstant.VIEW_MANAGE, nodeType, nodeId);
		ManageGroup group = null;
		if(proxys.size() > 0) {
		 	group = this.fetch(proxys.get(0).getpNodeId());
		}

		return group;
	}

}
