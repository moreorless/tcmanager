/**
 
 * Author: wangxh
 * Created: 2011-4-17
 */
package com.radixdigit.tcmanager.asset.data;

import java.io.Serializable;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 * 节点代理（包含节点对象和节点之间的关系，用于拓扑图绘制）
 * 
 * @author wangxh
 * 
 */
@Table("asset_relation")
public class NodeProxy implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7980119374519996587L;

	/**
	 * NodeProxyID,即节点关系表的主键ID
	 */
	@Column
	@Id(auto = false)
	private long id;

	/**
	 * 节点id
	 */
	@Column
	private long nodeId;

	/**
	 * 节点类型
	 */
	@Column
	private int nodeType;

	/**
	 * 节点对象
	 */

	private NodeInterface node;

	/**
	 * 父节点id
	 */
	@Column
	private long pNodeId;

	/**
	 * 父节点类型
	 */
	@Column
	private int pNodeType;
	
	/**
	 * 横坐标
	 */
	@Column
	private long pointX = 80;

	/**
	 * 纵坐标
	 */
	@Column
	private long pointY = 80;

	/**
	 * 视图类型
	 */
	@Column
	private int viewType;
	
	/**
	 * 多态值，使同一个拓扑图可以保存为多种展现形式。
	 * nodeId + groupId + polymorphic的组合, 确定在不同形态下，节点和组的对应关系。
	 */
	@Column
	private int polymorphic = 0;
	
	/**
	 * 图形类型：默认、详图、略图
	 */
	@Column
	private int graphType;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getNodeId() {
		return nodeId;
	}

	public void setNodeId(long nodeId) {
		this.nodeId = nodeId;
	}

	public long getpNodeId() {
		return pNodeId;
	}

	public void setpNodeId(long pNodeId) {
		this.pNodeId = pNodeId;
	}

	public int getNodeType() {
		return nodeType;
	}

	public void setNodeType(int nodeType) {
		this.nodeType = nodeType;
	}

	public int getpNodeType() {
		return pNodeType;
	}

	public void setpNodeType(int pNodeType) {
		this.pNodeType = pNodeType;
	}

	public long getPointX() {
		return pointX;
	}

	public void setPointX(long pointX) {
		this.pointX = pointX;
	}

	public long getPointY() {
		return pointY;
	}

	public void setPointY(long pointY) {
		this.pointY = pointY;
	}

	public int getViewType() {
		return viewType;
	}

	public void setViewType(int viewType) {
		this.viewType = viewType;
	}

	public NodeInterface getNode() {
		return node;
	}

	public void setNode(NodeInterface node) {
		this.node = node;
	}

	public void setGraphType(int graphType) {
		this.graphType = graphType;
	}

	public int getGraphType() {
		return graphType;
	}

	public int getPolymorphic() {
		return polymorphic;
	}

	public void setPolymorphic(int polymorphic) {
		this.polymorphic = polymorphic;
	}

	@Override
	public String toString() {
		String msg = "Proxy -- nodeId=" + getNodeId() + ", nodetype=" + getNodeType();
		if(getNode() != null){
			msg += (", nodeName=" + getNode().getName());
		}
		return msg;
	}

	
	/**
	 * 比较两个NodeProxy对象
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NodeProxy other = (NodeProxy) obj;
		if (nodeId != other.nodeId)
			return false;
		if (nodeType != other.nodeType)
			return false;
		if (pNodeId != other.pNodeId)
			return false;
		if (pNodeType != other.pNodeType)
			return false;
		return true;
	}
	
	
}
