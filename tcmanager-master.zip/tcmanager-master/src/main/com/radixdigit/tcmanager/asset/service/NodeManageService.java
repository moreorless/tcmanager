package com.radixdigit.tcmanager.asset.service;

import org.nutz.ioc.Ioc;
import org.nutz.mvc.NutConfig;

import com.radixdigit.tcmanager.SetupListener;
import com.radixdigit.tcmanager.asset.auth.service.AssetAuthService;
import com.radixdigit.tcmanager.asset.dao.node.AssetDao;
import com.radixdigit.tcmanager.asset.dao.node.LinkDao;

/**
 * 节点管理服务
 * 
 * @author wangxh
 * 
 */

public class NodeManageService implements SetupListener {

	/**
	 * 单例对象
	 */
	private static NodeManageService service = new NodeManageService();

	/**
	 * 获取单例
	 * 
	 * @return
	 */
	public static NodeManageService getInstance() {
		return service;
	}

	private NodeManageService() {}

	
	private AssetDao assetDao;

	private LinkDao linkDao;

	/**
	 * 系统关闭是，自动停止后台线程
	 */
	@Override
	public void destroy(NutConfig arg0) {
	}

	@Override
	public void init(NutConfig config) {
		if (config != null) {
			Ioc ioc = config.getIoc();
			assetDao = ioc.get(AssetDao.class);
			linkDao = ioc.get(LinkDao.class);
			
			// 从ioc容器获取
			ioc.get(AssetAuthService.class);
		}
	}

	/**
	 * 清除冗余节点
	 * 
	 */
	public void clearRedundantNodes() {
		assetDao.clearRedundantNodes();
		linkDao.clearRedundantNodes();
	}

	/**
	 * 导出全部拓扑数据（资产及所有与资产相关的接口、连接、图元、视图、关联关系等）
	 * 
	 * @return
	 */
	public int exportAll() {

		return 0;
	}

	/**
	 * 导入全部拓扑数据
	 * 
	 * @param filePath
	 * @return
	 */
	public int importALL(String filePath) {
		return 0;
	}

}
