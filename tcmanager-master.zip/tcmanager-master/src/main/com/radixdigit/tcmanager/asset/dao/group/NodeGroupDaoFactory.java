/**
 
 * Author: gaoxl
 * Created: 2012-6-20
 */
package com.radixdigit.tcmanager.asset.dao.group;

import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeInterface;

@IocBean
public class NodeGroupDaoFactory {

	@Inject("refer:manageGroupDao")
	private ManageGroupDao manageGroupDao;

	/**
	 * 获取组dao
	 * @param viewType
	 * @return
	 */
	public NodeGroupDao<? extends NodeInterface> getNodeGroupDao(int viewType){
		
		NodeGroupDao<? extends NodeInterface> groupDao = null; 
		
		switch (viewType) {
			case NodeConstant.VIEW_MANAGE:
				groupDao = manageGroupDao;
				break;
			
			default:
				break;
		}
		
		return groupDao;
	}
	
}
