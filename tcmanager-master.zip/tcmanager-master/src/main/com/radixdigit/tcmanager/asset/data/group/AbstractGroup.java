/**
 
 * Author: gaoxl
 * Created: 2012-6-15
 */
package com.radixdigit.tcmanager.asset.data.group;

import java.io.Serializable;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;

import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeInterface;


/**
 * 抽象组
* @Author: gaoxl
 */
public abstract class AbstractGroup implements NodeInterface, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8418831757505804715L;

	@Column
	@Id(auto = false)
	private long id;
	
	@Column
	private String name;
	
	/**
	 * 节点类型
	 */
	private int category = NodeConstant.NODETYPE_GROUP;
	
	/**
	 * 管理开关
	 */
	@Column
	private int manageSwitch;
	
	/**
	 * 组状态
	 */
	@Column
	private int status;

	/**
	 * 描述
	 */
	@Column
	private String description;

	/**
	 * 创建时间
	 */
	@Column
	private long timeCreate;

	/**
	 * 修改时间
	 */
	@Column
	private long timeModify;

	
//	/**
//	 * 视图类型
//	 */
//	private int viewType;
	
	/**
	 * 是否内置：1-是；2-否
	 */
	@Column
	private int builtIn;
	
	/**
	 * 图标
	 */
	@Column
	private String icon;
	
	
	@Override
	public long getId() {
		return id;
	}
	
	@Override
	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int getCategory() {
		return category;
	}

	@Override
	public void setCategory(int category) {
		this.category = category;
	}

	@Override
	public int getManageSwitch() {
		return manageSwitch;
	}

	@Override
	public void setManageSwitch(int manageSwitch) {
		this.manageSwitch = manageSwitch;
	}

	@Override
	public int getStatus() {
		return status;
	}

	@Override
	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public void setDescription(String desc) {
		this.description = desc;
	}

	@Override
	public long getTimeCreate() {
		return timeCreate;
	}

	@Override
	public void setTimeCreate(long createTime) {
		this.timeCreate = createTime;

	}

	@Override
	public long getTimeModify() {
		return timeModify;
	}

	@Override
	public void setTimeModify(long modifyTime) {
		this.timeModify = modifyTime;

	}

	
	public void setBuiltIn(int builtIn) {
		this.builtIn = builtIn;
	}

	public int getBuiltIn() {
		return builtIn;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getIcon() {
		return icon;
	}
	/**
	 * 获取组的视图类型
	 * @return
	 */
	abstract public int getViewType();

}
