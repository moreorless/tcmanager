package com.radixdigit.tcmanager.asset.module;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.dao.sql.OrderBy;
import org.nutz.ioc.Ioc;
import org.nutz.ioc.annotation.InjectName;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.lang.Mirror;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Chain;
import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.Param;

import ch.ethz.ssh2.log.Logger;

import com.radixdigit.tcmanager.alert.service.AlertService;
import com.radixdigit.tcmanager.annotation.AuthBy;
import com.radixdigit.tcmanager.asset.auth.data.AssetAuth;
import com.radixdigit.tcmanager.asset.auth.data.AuthQueryCnd;
import com.radixdigit.tcmanager.asset.auth.service.AssetAuthService;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeInterface;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.asset.data.TopoNode;
import com.radixdigit.tcmanager.asset.data.group.ManageGroup;
import com.radixdigit.tcmanager.asset.data.node.Asset;
import com.radixdigit.tcmanager.asset.data.node.AssetLink;
import com.radixdigit.tcmanager.asset.data.node.AssetType;
import com.radixdigit.tcmanager.asset.polling.RadixCacheManager;
import com.radixdigit.tcmanager.asset.service.NodeProxyService;
import com.radixdigit.tcmanager.asset.service.group.ManageGroupService;
import com.radixdigit.tcmanager.asset.service.node.AssetLinkService;
import com.radixdigit.tcmanager.asset.service.node.AssetService;
import com.radixdigit.tcmanager.asset.service.node.AssetTypeService;
import com.radixdigit.tcmanager.commons.mvc.Pager;
import com.radixdigit.tcmanager.monitor.core.config.BasicDataManager;
import com.radixdigit.tcmanager.monitor.core.data.TaskStruct;
import com.radixdigit.tcmanager.monitor.ext.radix.data.PingData;
import com.radixdigit.tcmanager.monitor.ext.radix.data.RadixPingInfo;
import com.radixdigit.tcmanager.monitor.service.ProMonitorService;
import com.radixdigit.tcmanager.monitor.view.data.Monitor;
import com.radixdigit.tcmanager.monitor.view.data.snapshot.SnapshotData;
import com.radixdigit.tcmanager.sysconfig.service.SysconfigService;

@IocBean
@InjectName
@AuthBy(check=false)
@At("/asset")
public class AssetModule {
	private static String OPERATION_ADD = "add";
	private static String OPERATION_EDIT ="edit";
	private static String OPERATION_READ ="read";
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Inject
	private AssetService assetService;
	
	@Inject
	private NodeProxyService nodeProxyService;
	
	@Inject
	private ManageGroupService manageGroupService;
	
	@Inject
	private AssetAuthService assetAuthService;
	
	@Inject
	private AssetTypeService assetTypeService;
	
	@Inject
	private AssetLinkService assetLinkService;
	
	@Inject
	private ProMonitorService proMonitorService;
	
	@Inject
	private AlertService alertService;
	
	private String obscurePwd = "#!#tempwd#!#";
	
	@At
	@Ok("jsp:jsp.asset.main")
	public void main(){
		
	}
	
	@At
	@Ok("jsp:jsp.asset.list")
	public Pager<Asset> list(HttpServletRequest request, Ioc ioc, @Param("groupId") long groupId,
			@Param("..") Pager<Asset> pager){
		
		Condition condition = null;
		if (pager.getSidx() != null) { // 设置排序字段和方向
			condition = Cnd.orderBy();
			Mirror.me(OrderBy.class).invoke(condition, pager.getSord(), pager.getSidx());
		}
		
		Pager<Asset> result = assetService.getNodesInGroup(groupId, NodeConstant.VIEW_MANAGE, pager);
		
		List<AssetType> typelist = assetTypeService.getAllTypes();
		Map<String, String> codeToNameMap = new HashMap<>();
		for(AssetType aType : typelist){
			codeToNameMap.put(aType.getCode(), aType.getName());
		}
		request.setAttribute("codeToNameMap", codeToNameMap);
		return result;
	}
	
	
	@At
	@Ok("jsp:jsp.asset.edit")
	public void prepare(HttpServletRequest request, @Param("assetId") long assetId, @Param("operation") String operation){
		Asset asset = new Asset();
		if(OPERATION_ADD.equals(operation)){
			
		}else if(OPERATION_EDIT.equals(operation) || OPERATION_READ.equals(operation)){
			asset = assetService.fetch(assetId);

			AuthQueryCnd aqCnd = new AuthQueryCnd();
			aqCnd.setIp(asset.getIp());
			AssetAuth auth = assetAuthService.queryAuthByCndFromDB(aqCnd);
			if(auth != null){
				request.setAttribute("authparams", auth);
			}
			
			// 查询监控器
			TaskStruct ts = proMonitorService.getTaskStructByAssetId(assetId);
			request.setAttribute("monitor", ts);
		}
		request.setAttribute("asset", asset);
		
	}
	
	
	@At
	@Chain("validate")
	@Ok("jsp:jsp.asset.editOk")
	public void add(HttpServletRequest request, @Param("..") Asset asset, @Param("groupId") long groupId, 
			@Param("::authparams.") AssetAuth assetAuth, @Param("::monitor.") TaskStruct ts){
		
		// 保存资产
		NodeProxy proxy =new NodeProxy();
		proxy.setNode(asset);
		proxy.setNodeType(NodeConstant.NODETYPE_ASSET);
		proxy.setpNodeId(groupId);
		proxy.setpNodeType(NodeConstant.NODETYPE_GROUP);
		proxy.setViewType(NodeConstant.VIEW_MANAGE);
		
		proxy = assetService.addNode(proxy);
		
		// 保存认证信息
		if(!"none".equals(assetAuth.getProtocol())){
			assetAuth.setIp(asset.getIp());
			assetAuthService.addAuth(assetAuth);
		}
		
		// 创建监控器
		ts = wrapTaskStruct(ts, asset, assetAuth);
		proMonitorService.insertMonitor(ts, assetAuth);
		
	}
	
	private String getMtype(String devtype){
		return proMonitorService.getMtype(devtype);
	}
	
	private TaskStruct wrapTaskStruct(TaskStruct ts, Asset asset, AssetAuth assetAuth){
		ts.setAssetId(asset.getId());
		ts.setIp(asset.getIp());
		ts.setName(asset.getName());
		
		ts.setProtocol(assetAuth.getProtocol());
		ts.setPort(assetAuth.getPort());
		
		if(assetAuth.getUrl() != null){
			ts.setUrl(assetAuth.getUrl());
		}
		
		String mType = getMtype(asset.getType());
		ts.setMtype(mType);
		int mTypeId = BasicDataManager.getInstance().getGlobalDefinitions().getMTypeMeta(mType).getMTypeId();
		ts.setMtypeId(mTypeId);
		
		if(asset.getManageSwitch() == 1){
			ts.setTask(true);
			ts.setEnabled(true);
		}else{
			ts.setTask(false);
			ts.setEnabled(false);
		}
		ts.setCollector("local");
		return ts;
	}
	
	@At
	@Chain("validate")
	@Ok("jsp:jsp.asset.editOk")
	public void edit(HttpServletRequest request, Ioc ioc, @Param("..") Asset asset, @Param("groupId") long groupId, 
			@Param("::authparams.") AssetAuth assetAuth,  @Param("::monitor.") TaskStruct ts){
		assetService.updateNodes(asset);
		
		AssetAuth oldAuth = assetAuthService.fetch(assetAuth.getId());
		// 删除原有的认证信息
		Condition cnd = Cnd.where("ip", "=", asset.getIp());	
		assetAuthService.clear(cnd);
		// 保存认证信息
		if(!"none".equals(assetAuth.getProtocol())){
			assetAuth.setIp(asset.getIp());
			
			// 若密码未修改，则使用原有信息
			if(obscurePwd.equals(assetAuth.getPwd())){
				assetAuth.setPwd(oldAuth.getPwd());
			}
			if(obscurePwd.equals(assetAuth.getGetCommunity())){
				assetAuth.setGetCommunity(oldAuth.getGetCommunity());
			}
			if(obscurePwd.equals(assetAuth.getSetCommunity())){
				assetAuth.setSetCommunity(oldAuth.getSetCommunity());
			}
			if(obscurePwd.equals(assetAuth.getSuperPwd())){
				assetAuth.setSuperPwd(oldAuth.getSuperPwd());
			}
			if(obscurePwd.equals(assetAuth.getV3AuthPwd())){
				assetAuth.setV3AuthPwd(oldAuth.getV3AuthPwd());
			}
			if(obscurePwd.equals(assetAuth.getV3PrivPwd())){
				assetAuth.setV3PrivPwd(oldAuth.getV3PrivPwd());
			}
			
			assetAuthService.addAuth(assetAuth);
		}
		
		// 更新监控器
		if(ts.getId() != 0){
			ts = wrapTaskStruct(ts, asset, assetAuth);
			proMonitorService.updateMonitor(ts, assetAuth);
		}
		
	}
	
	@At
	@Ok("jsp:jsp.asset.editOk")
	public int delete(@Param("assetIds") long... assetIds){
		
		// 首先删除监控器
		for(long assetId : assetIds){
			Asset asset = assetService.fetch(assetId);
			List<TaskStruct> tsList = proMonitorService.getTaskStructsByIp(asset.getIp());
			if(tsList != null){
				for(TaskStruct ts : tsList){
					proMonitorService.deleteMonitor(ts.getId());
				}
			}
			
		}
		
		int result = assetService.deleteNodes(assetIds);
		return result;
	}
	
	/**
	 * 删除资产
	 * @param assetIds
	 * @return
	 */
	@At
	@Ok("json")
	@Fail("json")
	public int deleteAssetAjax(@Param("assetIds") long... assetIds){
		return delete(assetIds);
	}
	
	/**
	 * 删除连线
	 * @param ioc
	 * @param ids
	 * @return
	 */
	@At
	@Ok("json")
	public int deleteLinkAjax(Ioc ioc, @Param("linkIds") long... linkIds) {
		AssetLinkService linkService = ioc.get(AssetLinkService.class);
		return linkService.deleteNodes(linkIds);
	}
	
	@At
	@Ok("jsp:jsp.asset.editOk")
	public int deleteLink(Ioc ioc,  @Param("linkIds") long... linkIds){
		AssetLinkService linkService = ioc.get(AssetLinkService.class);
		return linkService.deleteNodes(linkIds);
	}
	
	/**
	 * 拓扑图
	 */
	@At
	@Ok("jsp:jsp.asset.topo")
	public void topo(HttpServletRequest request, @Param("groupId") long groupId){
		request.setAttribute("groupObj", manageGroupService.fetch(groupId));
		
		request.setAttribute("typelist", assetTypeService.getAllTypes());
		
		// 链路告警阀值
		int lostThreshold = SysconfigService.me().getCurrentAlertParam().getPingLostThreshold();
		int delayThreshold = SysconfigService.me().getCurrentAlertParam().getPingDelayThreshold();
		request.setAttribute("lostThreshold", lostThreshold);
		request.setAttribute("delayThreshold", delayThreshold);
	}
	
	
	/**
	 * 读取拓扑数据
	 * @param request
	 * @param groupId
	 * @return
	 */
	@At
	@Ok("json")
	@Fail("json")
	public List<NodeProxy> getTopoData(HttpServletRequest request, @Param("groupId") long groupId){
		List<NodeProxy> proxyList = nodeProxyService.getProxysInGroup(groupId, NodeConstant.VIEW_MANAGE);
		return proxyList;
	}
	
	/**
	 * 读取组内最新5分钟新添加的流控设备检测链路
	 * @param groupId
	 * @return
	 */
	@At
	@Ok("json")
	@Fail("json")
	public List<NodeProxy> getLastedRadixLink(@Param("groupId") long groupId){
		long startTime = System.currentTimeMillis() - 300*1000;
		Condition cnd = Cnd.where("pNodeId", "=", groupId).and("pNodeType", "=", NodeConstant.NODETYPE_GROUP)
				.and("nodeType", "=", NodeConstant.NODETYPE_LINK).and("viewType", "=", NodeConstant.VIEW_MANAGE);
		List<NodeProxy> linkProxyList = nodeProxyService.getProxysInGroup(cnd);
		if(linkProxyList != null){
			Iterator<NodeProxy> iter = linkProxyList.iterator();
			while(iter.hasNext()){
				NodeProxy proxy = iter.next();
				if(proxy.getNode() == null || proxy.getNode().getTimeCreate() < startTime){
					iter.remove();
				}
			}
		}
		return linkProxyList;
	}
	
	
	/**
	 * 保存拓扑图 (只保存资产、子组的位置信息即可)
	 * 
	 * @param request
	 * @param ioc
	 * @param nodes
	 * @param groupId
	 */
	@At("/saveTopo")
	@Ok("json")
	@Fail("json")
	public void saveTopo(HttpServletRequest request, Ioc ioc,
			@Param("Node") TopoNode[] nodes, @Param("Link") AssetLink[] links,
			@Param("groupId") long groupId) {
		List<NodeProxy> proxyList = nodeProxyService.getProxysInGroup(groupId, NodeConstant.VIEW_MANAGE);
		// 拓扑节点
		Map<Long, TopoNode> nodeMap = new HashMap<Long, TopoNode>();
		if (nodes != null) {
			for (TopoNode node : nodes) {
				nodeMap.put(node.getId(), node);
			}
		}
		// 连线
		Map<Long, AssetLink> linkMap = new HashMap<Long, AssetLink>();
		if (links != null) {
			for (AssetLink link : links) {
				linkMap.put(link.getId(), link);
			}
		}

		Iterator<NodeProxy> iter = proxyList.iterator();
		TopoNode tmpTopoNode = null;
		AssetLink tmpTopoLink = null;
		while (iter.hasNext()) {
			NodeProxy proxy = iter.next();
			int nodeType = proxy.getNodeType();
			switch (nodeType) {
			case NodeConstant.NODETYPE_ASSET:
				tmpTopoNode = nodeMap.get(proxy.getId());
				if (tmpTopoNode != null) {
					proxy.setPointX(tmpTopoNode.getX());
					proxy.setPointY(tmpTopoNode.getY());
					proxy.setGraphType(tmpTopoNode.getViewMode());
					nodeProxyService.updateProxy(proxy);
				}
				break;

			case NodeConstant.NODETYPE_GROUP:
				tmpTopoNode = nodeMap.get(proxy.getId());
				if (tmpTopoNode != null) {
					proxy.setPointX(tmpTopoNode.getX());
					proxy.setPointY(tmpTopoNode.getY());
					nodeProxyService.updateProxy(proxy);
				}
				break;
			case NodeConstant.NODETYPE_LINK:
				if (linkMap != null && linkMap.size() > 0) {
					tmpTopoLink = linkMap.get(proxy.getId());
					if (tmpTopoLink != null) {
						// 获取连线
						NodeInterface nodeInter = nodeProxyService
								.getNodeByProxy(proxy);
						AssetLink topoLink = (AssetLink) nodeInter;
						topoLink.setColor(tmpTopoLink.getColor());
						topoLink.setEndPointShape(tmpTopoLink
								.getEndPointShape());
						topoLink.setStartPointShape(tmpTopoLink
								.getStartPointShape());
						topoLink.setShape(tmpTopoLink.getShape());
						topoLink.setWidth(tmpTopoLink.getWidth());

						proxy.setNode(topoLink);
						// 修改连线颜色、形状等
						nodeProxyService.updateNode(proxy);
					}
				}
				break;
			default:
				break;
			}
		}
		
		ManageGroup mGroup = manageGroupService.fetch(groupId);
		mGroup.setPosSaved(true);
		manageGroupService.updateNodes(mGroup);
		
	}

	@At("/insertLink")
	@Ok("json")
	@Fail("json")
	// @AdaptBy(type=JsonAdaptor.class)
	public NodeProxy insertLink(Ioc ioc, @Param("edge") AssetLink link, @Param("groupId") long groupId) {
		AssetLinkService linkService = ioc.get(AssetLinkService.class);

		link.setTimeCreate(System.currentTimeMillis());
		link.setTimeModify(System.currentTimeMillis());

		NodeProxy proxy = new NodeProxy();
		proxy.setNode(link);
		proxy.setNodeType(NodeConstant.NODETYPE_LINK);
		proxy.setpNodeId(groupId);
		proxy.setpNodeType(NodeConstant.NODETYPE_GROUP);
		proxy.setViewType(NodeConstant.VIEW_MANAGE);

		return linkService.addNode(proxy);
	}
	
	@At
	@Ok("jsp:jsp.asset.nodeInfoPanel")
	public void loadAssetInfo(HttpServletRequest request, @Param("assetId") long assetId){
		Asset asset = assetService.fetch(assetId);
		request.setAttribute("asset", asset);
		
		TaskStruct ts = proMonitorService.getTaskStructByAssetId(assetId);
		
		if(ts != null){
			Monitor monitorObj = proMonitorService.getMonitorByTask(ts);
			request.setAttribute("monitorObj", monitorObj);
			// 读取可用率
			request.setAttribute("usability", monitorObj.getUsability());
		}
		if(ts != null && ts.isEnabled()){
			SnapshotData snapshotData = proMonitorService.getSnapshotData(ts.getMtype(), ts.getId());
			request.setAttribute("snapshotData", snapshotData);

			// 读取当天告警
			long timeEnd = System.currentTimeMillis();
			Calendar cal = Calendar.getInstance(); 
			cal.set(Calendar.HOUR_OF_DAY, 0); 
			cal.set(Calendar.SECOND, 0); 
			cal.set(Calendar.MINUTE, 0); 
			cal.set(Calendar.MILLISECOND, 0);
			long timeBegin = cal.getTimeInMillis();
			int alertCount = alertService.getUnhandledAlertCount(ts.getId(), timeBegin, timeEnd);
			request.setAttribute("alertCount", alertCount);
		}
		request.setAttribute("taskstruct", ts);
		
	}
	
	@At
	@Ok("jsp:jsp.asset.linkInfoPanel")
	public void loadLinkInfo(HttpServletRequest request, @Param("sourceId") long sourceId, @Param("targetId") long targetId){
		
		NodeProxy sourceProxy = nodeProxyService.getProxyByProxyId(sourceId);
		NodeProxy destProxy = nodeProxyService.getProxyByProxyId(targetId);
		if(sourceProxy != null && destProxy != null){
			// 起始设备为流控设备
			if(sourceProxy.getNode() instanceof Asset){
				Asset sourceDev  = (Asset)sourceProxy.getNode();
				if(sourceDev.getType().contains("radixdigit") || destProxy.getNode() instanceof Asset){
					Asset destDev  = (Asset)destProxy.getNode();
					String sourceIp = sourceDev.getIp();
					String destIp = destDev.getIp();
					
					request.setAttribute("sourceIp", sourceIp);
					request.setAttribute("destIp", destIp);
					
					RadixPingInfo pingInfo = RadixCacheManager.me().getLinkCacheMap().get(sourceIp);
					if(pingInfo != null){
						PingData pingData = pingInfo.getPingData(destIp);
						request.setAttribute("pingData", pingData);
					}
				}
			}
		}
	}
	
	
	/**
	 * 检测名称合法 -- 目前仅检测重名
	 * 
	 * @param request
	 * @param ioc
	 * @param name
	 * @return true 合法, false 非法
	 */
	@At
	@Ok("json")
	public boolean isValidName(HttpServletRequest request, Ioc ioc,
			@Param("name") String name, @Param("id") long id,
			@Param("operation") String operation) {
		AssetService as = ioc.get(AssetService.class);

		Asset asset = as.queryByName(name);

		if (asset != null) { // 存在重名
			if (OPERATION_ADD.equals(operation)) {
				return false;
			} else if (OPERATION_EDIT.equals(operation)) {
				if (asset.getId() != id) {
					return false;
				} else {
					return true;
				}
			}
		}

		return true;
	}
	
	
	/**
	 * 检测IP合法 -- 当前组中是否存在重复IP
	 * 
	 * @param request
	 * @param ioc
	 * @param name
	 * @return true 合法, false 非法
	 */
	@At
	@Ok("json")
	public boolean isIpValid(HttpServletRequest request, Ioc ioc,
			@Param("ip") String ip, @Param("id") long id, @Param("groupId") long groupId,
			@Param("operation") String operation) {
		
		// 获取当前组下的所有资产
		List<NodeProxy> proxys = assetService.getProxysInGroup(groupId, NodeConstant.VIEW_MANAGE);
		
		boolean isIpExsit = false;
		long theAssetId = 0;
		for(NodeProxy proxy : proxys){
			if(proxy.getNodeType() == NodeConstant.NODETYPE_ASSET){
				Asset asset = (Asset)proxy.getNode();
				if(asset.getIp().equals(ip)){
					isIpExsit = true;
					theAssetId = asset.getId();
					break;
				}
			}
		}

		if (isIpExsit) { // 存在重名
			if (OPERATION_ADD.equals(operation)) {
				return false;
			} else if (OPERATION_EDIT.equals(operation)) {
				if (theAssetId != id) {
					return false;
				} else {
					return true;
				}
			}
		}

		return true;
	}
	
	/**
	 * 连通性测试
	 * @param request
	 * @param asset
	 * @param groupId
	 * @param assetAuth
	 * @param ts
	 * @return	1 连通, 0 不连通, -1 协议未定义, -2 "测试失败,请确认参数填写完整!"
	 */
	@At
	@Ok("json")
	@Fail("json")
	public int testConnectivity(HttpServletRequest request, @Param("..") Asset asset, @Param("groupId") long groupId, 
			@Param("::authparams.") AssetAuth assetAuth, @Param("::monitor.") TaskStruct ts) {
		int result = -2;
		
		AssetAuth oldAuth = assetAuthService.fetch(assetAuth.getId());
		// 若密码未修改，则使用原有信息
		if(obscurePwd.equals(assetAuth.getPwd())){
			assetAuth.setPwd(oldAuth.getPwd());
		}
		if(obscurePwd.equals(assetAuth.getGetCommunity())){
			assetAuth.setGetCommunity(oldAuth.getGetCommunity());
		}
		if(obscurePwd.equals(assetAuth.getSetCommunity())){
			assetAuth.setSetCommunity(oldAuth.getSetCommunity());
		}
		if(obscurePwd.equals(assetAuth.getSuperPwd())){
			assetAuth.setSuperPwd(oldAuth.getSuperPwd());
		}
		if(obscurePwd.equals(assetAuth.getV3AuthPwd())){
			assetAuth.setV3AuthPwd(oldAuth.getV3AuthPwd());
		}
		if(obscurePwd.equals(assetAuth.getV3PrivPwd())){
			assetAuth.setV3PrivPwd(oldAuth.getV3PrivPwd());
		}
		
		if(ts != null && assetAuth != null){
			ts = wrapTaskStruct(ts, asset, assetAuth);
			
			try{
				result = proMonitorService.testConnectivity(ts, assetAuth);
			}catch (Exception e) {
				logger.equals(e);
			}
		}
		return result;
	}
	
	
	
	
}
