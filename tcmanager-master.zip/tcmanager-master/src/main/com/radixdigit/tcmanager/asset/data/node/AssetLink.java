/**
 
 * Author: wangxh
 * Created: 2011-4-14
 */
package com.radixdigit.tcmanager.asset.data.node;

import java.io.Serializable;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeInterface;
import com.radixdigit.tcmanager.asset.data.NodeProxy;


/**
 * 资产连接
 * @author wangxh
 *
 */
@Table("asset_link")
public class AssetLink implements NodeInterface, Serializable {
	/**
	 * 连接id
	 */
	@Column
	@Id(auto = false)
	private long id;

	/**
	 * 连接名称
	 */
	@Column
	private String name = "";

	/**
	 * 节点类型
	 */
	
	private int category = NodeConstant.NODETYPE_LINK;

	/**
	 * 管理开关：是否接受管理
	 */
	@Column
	private int manageSwitch = 0;

	/**
	 * 状态
	 */
	@Column
	private int status;

	/**
	 * 描述
	 */
	@Column
	private String description;

	/**
	 * 创建时间
	 */
	@Column
	private long timeCreate;

	/**
	 * 修改时间
	 */
	@Column
	private long timeModify;

	//--专有属性
	
	/**
	 * 连接类型
	 */
	@Column
	private int type;
	
		
	/**
	 * 连线起始节点ID
	 */
	@Column
	private long startId;
	
	/**
	 * 连线起始节点端口描述
	 */
	@Column
	private String startPortdesc;
	
	/**
	 * 连线起始节点端口
	 */
	@Column
	private int startPort;
	
	/**
	 * 起始点形状
	 */
	@Column
	private int startPointShape;
	
	/**
	 * 连线结束节点ID
	 */
	@Column
	private long endId;
	
	/**
	 * 连线结束节点端口描述
	 */
	@Column
	private String endPortdesc;
	
	/**
	 * 连线结束节点端口
	 */
	@Column
	private int endPort;
	
	/**
	 * 结束点形状
	 */
	@Column
	private int endPointShape;
	
	/**
	 * 连线宽度
	 */
	@Column
	private float width;
	
	/**
	 * 连线颜色
	 */
	@Column
	private int color;
	
	/**
	 * 连线形状
	 */
	@Column
	private int shape;
	
	/**
	 * 是否内置：1-是；2-否
	 */
	private int builtIn;
	/**
	 * 图标
	 */
	private String icon;
	
	/**
	 * 流量告警阀值上限
	 */
	@Column
	private long flowThresholdHigh = 0;
	
	/**
	 * 流量告警阀值下限
	 */
	@Column
	private long flowThresholdLow = 0;
	
	/**
	 * 连线起点的节点代理
	 */
	private NodeProxy startNodeProxy;
	/**
	 * 连线终点的节点代理
	 */
	private NodeProxy endNodeProxy;
	
	/**
	 * 链路丢包率(%)
	 */
	private float lost;
	/**
	 * 时延(ms)
	 */
	private float delay;
	
	
	public long getStartId() {
		return startId;
	}

	public void setStartId(long startId) {
		this.startId = startId;
	}

	public String getStartPortdesc() {
		return startPortdesc;
	}

	public void setStartPortdesc(String startPortdesc) {
		this.startPortdesc = startPortdesc;
	}

	public int getStartPort() {
		return startPort;
	}

	public void setStartPort(int startPort) {
		this.startPort = startPort;
	}

	public int getStartPointShape() {
		return startPointShape;
	}

	public void setStartPointShape(int startPointShape) {
		this.startPointShape = startPointShape;
	}

	public long getEndId() {
		return endId;
	}

	public void setEndId(long endId) {
		this.endId = endId;
	}

	public String getEndPortdesc() {
		return endPortdesc;
	}

	public void setEndPortdesc(String endPortdesc) {
		this.endPortdesc = endPortdesc;
	}

	public int getEndPort() {
		return endPort;
	}

	public void setEndPort(int endPort) {
		this.endPort = endPort;
	}

	public int getEndPointShape() {
		return endPointShape;
	}

	public void setEndPointShape(int endPointShape) {
		this.endPointShape = endPointShape;
	}

	public float getWidth() {
		return width;
	}

	public void setWidth(float width) {
		this.width = width;
	}

	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}

	public int getShape() {
		return shape;
	}

	public void setShape(int shape) {
		this.shape = shape;
	}


	
	@Override
	public long getId() {
		return this.id;
	}

	@Override
	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int getCategory() {
		return this.category;
	}

	@Override
	public void setCategory(int category) {
		this.category = category;
	}

	@Override
	public int getManageSwitch() {
		return this.manageSwitch;
	}

	@Override
	public void setManageSwitch(int manageSwitch) {
		this.manageSwitch = manageSwitch;
	}

	@Override
	public int getStatus() {
		return this.status;
	}

	@Override
	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String getDescription() {
		return this.description;
	}

	@Override
	public void setDescription(String desc) {
		this.description = desc;
	}

	@Override
	public long getTimeCreate() {
		return this.timeCreate;
	}

	@Override
	public void setTimeCreate(long timeCreate) {
		this.timeCreate = timeCreate;

	}

	@Override
	public long getTimeModify() {
		return this.timeModify;
	}

	@Override
	public void setTimeModify(long timeModify) {
		this.timeModify = timeModify;

	}

	public void setType(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}
	/**
	 * 是否内置：1-是；2-否
	 * @return
	 */
	public int getBuiltIn(){
		return this.builtIn;
	}
	/**
	 * 
	 * @param builtIn
	 */
	public void setBuiltIn(int builtIn){
		this.builtIn=builtIn;
	}
	/**
	 * 图标
	 * @return
	 */
	public String getIcon(){
		return this.icon;
	}
	/**
	 * 
	 * @param icon
	 */
	public void setIcon(String icon){
		this.icon=icon;
	}

	public NodeProxy getStartNodeProxy() {
		return startNodeProxy;
	}

	public void setStartNodeProxy(NodeProxy startNodeProxy) {
		this.startNodeProxy = startNodeProxy;
	}

	public NodeProxy getEndNodeProxy() {
		return endNodeProxy;
	}

	public void setEndNodeProxy(NodeProxy endNodeProxy) {
		this.endNodeProxy = endNodeProxy;
	}

	public long getFlowThresholdHigh() {
		return flowThresholdHigh;
	}

	public void setFlowThresholdHigh(long flowThresholdHigh) {
		this.flowThresholdHigh = flowThresholdHigh;
	}

	public long getFlowThresholdLow() {
		return flowThresholdLow;
	}

	public void setFlowThresholdLow(long flowThresholdLow) {
		this.flowThresholdLow = flowThresholdLow;
	}

	public float getLost() {
		return lost;
	}

	public void setLost(float lost) {
		this.lost = lost;
	}

	public float getDelay() {
		return delay;
	}

	public void setDelay(float delay) {
		this.delay = delay;
	}
	
	
	
}
