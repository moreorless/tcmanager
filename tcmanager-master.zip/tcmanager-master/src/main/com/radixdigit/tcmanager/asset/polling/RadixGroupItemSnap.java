package com.radixdigit.tcmanager.asset.polling;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.radixdigit.tcmanager.monitor.ext.radix.data.NetInfo;
public class RadixGroupItemSnap {

	private long timestamp;
	
	private List<NetInfo> netInfo = new ArrayList<>();

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public List<NetInfo> getNetInfo() {
		return netInfo;
	}

	public void setNetInfo(List<NetInfo> netInfo) {
		this.netInfo = netInfo;
	}

	
	
}
