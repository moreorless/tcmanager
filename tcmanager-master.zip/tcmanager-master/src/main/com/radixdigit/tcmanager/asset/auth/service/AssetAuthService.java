package com.radixdigit.tcmanager.asset.auth.service;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.dao.sql.OrderBy;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.lang.Mirror;

import com.radixdigit.tcmanager.asset.auth.dao.AssetAuthDao;
import com.radixdigit.tcmanager.asset.auth.data.AssetAuth;
import com.radixdigit.tcmanager.asset.auth.data.AuthQueryCnd;
import com.radixdigit.tcmanager.commons.mvc.Pager;
import com.radixdigit.tcmanager.commons.service.TblIdsEntityService;
import com.radixdigit.tcmanager.util.IPComparatorHandler;

/**
 * 资产认证服务
 * 
 * @author wangxh
 * 
 */
@IocBean(name="assetAuthService",create="init")
public class AssetAuthService extends TblIdsEntityService<AssetAuth> {

	@Inject("refer:assetAuthDao")
	public void setUserDao(AssetAuthDao dao) {
		setDao(dao);
	}

	/**
	 * 认证记录缓存,String为ip、url、protocol、port、instancename的组合串
	 */
	private Map<String, AssetAuth> authMap = null;

	/**
	 * AssetAuthService单例
	 */
	private static AssetAuthService authService=new AssetAuthService();

	/**
	 * 获取AssetAuthService单例对象
	 * 
	 * @return
	 */
	public static AssetAuthService getInstance() {
		return authService;
	}
	
	private AssetAuthService(){}
	
	/**
	 * 初始化缓存
	 */
	public void init() {
		if (authMap == null) {
			authMap = new HashMap<String, AssetAuth>();
		} else {
			authMap.clear();
		}

		List<AssetAuth> auths = (List<AssetAuth>) paging(null, null).getData();
		StringBuilder sbuilder = new StringBuilder();
		for (AssetAuth auth : auths) {
			sbuilder.setLength(0);
			sbuilder.append((auth.getIp() == null) ? "" : auth.getIp());
			sbuilder.append((auth.getUrl() == null) ? "" : auth.getUrl());
			sbuilder.append((auth.getProtocol() == null) ? "" : auth
					.getProtocol());
			sbuilder.append(auth.getPort());
			sbuilder.append((auth.getInstanceName() == null) ? "" : auth
					.getInstanceName());
			authMap.put(sbuilder.toString().toLowerCase(), auth);
		}
	}

	/**
	 * 从数据库查询认证记录
	 * 
	 * @param AuthQueryCnd
	 *            查询对象。  aqc为null时表示获取全部记录。
	 * @param pager
	 *            页对象。pager为null时表示不分页。
	 * @return
	 */
	private Pager<AssetAuth> paging(AuthQueryCnd aqc, Pager<AssetAuth> pager) {

		org.nutz.dao.pager.Pager nutzPager = null;
		Condition condition = null;
		if (aqc != null) {
			condition = AssetAuthDao.createCnd(aqc);
		}
		if (pager != null) {
			nutzPager = this.dao().createPager(pager.getPage(),
					pager.getPageSize());
		} else {
			pager = new Pager<AssetAuth>();
		}
		List<AssetAuth> auths = this.query(condition, nutzPager);
		pager.setRecords(this.count(condition));
		pager.setData(auths);
		return pager;
	}

	/**
	 * 通过ID查询认证记录
	 * 
	 * @param id
	 * @return
	 */
	public AssetAuth queryAuthById(long id) {

		return authMap.get(travel(id));
	}

	/**
	 * 通过组合条件查询认证记录
	 * 该方法的调用有隐含的限制条件：必须设置ip、url、protocol、port、instance参数，否则查询不到结果
	 * 
	 * @param aqc
	 * @return 认证记录
	 */
	@Deprecated
	public AssetAuth queryAuthByCnd(AuthQueryCnd aqc) {
		
		String ip = aqc.getIp();
		String url = aqc.getUrl();
		String protocol = aqc.getProtocol();
		int port = aqc.getPort();
		String instance = aqc.getInstanceName();

		StringBuilder sbuilder = new StringBuilder();
		sbuilder.append(ip == null ? "" : ip);
		sbuilder.append(url == null ? "" : url);
		sbuilder.append(protocol == null ? "" : protocol);
		sbuilder.append(port);
		sbuilder.append(instance == null ? "" : instance);

		return authMap.get(sbuilder.toString().toLowerCase());
	}
	
	/**
	 * 通过组合条件从数据库查询认证记录
	 * @param aqc
	 * @return
	 */
	public AssetAuth queryAuthByCndFromDB(AuthQueryCnd aqc){
		return dao().fetch(AssetAuth.class, AssetAuthDao.createCnd(aqc));
	}

	/**
	 * 根据组合条件从数据库查询多个认证记录
	 * @param aqc
	 * @return
	 */
	public List<AssetAuth> queryAuthListFromDB(AuthQueryCnd aqc){
		return dao().query(AssetAuth.class, AssetAuthDao.createCnd(aqc), null);
	}
	
	/**
	 * 分页查询全部认证记录
	 * 
	 * @param pager
	 *            分页对象
	 * @return 包含查询结果的分页对象
	 */
	public Pager<AssetAuth> queryAllAuth(Pager<AssetAuth> pager) {
		String sidx = pager.getSidx();
		String sord = pager.getSord();
		Cnd	condition = null;
		if (sidx != null) { 
			condition = (Cnd) Cnd.orderBy();
			Mirror.me(OrderBy.class).invoke(condition, sord, sidx);
		}
		List<AssetAuth> auths = query(condition, this.dao().createPager(pager.getPage(), pager.getPageSize()));
		List<IPComparatorHandler> ipList = new ArrayList<IPComparatorHandler>();
		List<AssetAuth> newauths = new LinkedList<AssetAuth>();
		pager.setRecords(this.count(condition));
		if("ip".equals(sidx) && auths != null && auths.size()>0){
			//如果是IP字段排序，则做特殊处理，按照ip分段数字排序
			for(AssetAuth asset : auths){
				String ip = asset.getIp();
				if(ip!=null && !ip.trim().equals("")){
					IPComparatorHandler ipObj=new IPComparatorHandler(ip,asset);
					ipList.add(ipObj);
				}else{
					newauths.add(asset);
				}
			}
			if(ipList!=null && ipList.size()>0){
				Collections.sort(ipList, IPComparatorHandler.IPComparator);//默认为正序排列
				auths=new ArrayList<AssetAuth>();
				if(pager.getSord()!=null && pager.getSord().equals("desc")){//倒序排序
					for(int i=ipList.size()-1;i>=0;i--){
						AssetAuth asset = (AssetAuth) ipList.get(i).getAsset();
						newauths.add(asset);
					}
				}else{
					for(IPComparatorHandler objHandler:ipList){
						AssetAuth asset = (AssetAuth) objHandler.getAsset();
						newauths.add(asset);
					}
				}
				pager.setData(newauths);
			}
		}else{		
			newauths.addAll(auths);
		}
		pager.setData(newauths);
		return pager;
	}

	public Pager<AssetAuth> queryByIps(Condition condition,Pager<AssetAuth> pager) {
		List<AssetAuth> auths = query(condition, this.dao().createPager(pager.getPage(), pager.getPageSize()));
		pager.setRecords(this.count(condition));
		pager.setData(auths);
		return pager;
	}
	/**
	 * 使用ip获取资产snmp协议认证对象
	 * @param ip
	 * @return
	 */
	public AssetAuth querySnmpAuthByIp(String ip){
		Condition condition = Cnd.where(Cnd.exps("ip", "=", ip).and("protocol", "=", AssetAuth.PROTOCOL_SNMP));
		return this.fetch(condition);
	}
	
	/**
	 * 使用ip获取资产ssh协议认证对象
	 * @param ip
	 * @return
	 */
	public AssetAuth querySshAuthByIp(String ip){
		Condition condition = Cnd.where(Cnd.exps("ip", "=", ip).and("protocol", "=", AssetAuth.PROTOCOL_SSH));
		return this.fetch(condition);
	}
	/**
	 * 更新一条认证记录
	 * 
	 * @param auth
	 *            认证对象
	 * @return 更新的记录条数
	 */
	public int updateAuth(AssetAuth auth) {
		
		int result = this.dao().update(auth);
		
		if (result > 0) {
			init();
		}
		return result;
	}

	/**
	 * 更新多条认证记录
	 * 
	 * @param auths
	 *            认证对象列表
	 * @return 更新的记录条数
	 */
	public int updateAuths(List<AssetAuth> auths) {
		int result = this.dao().update(auths);
		if (result > 0) {
			init();
		}
		return result;
	}


	/**
	 * 根据ID删除认证记录
	 * 
	 * @param Ids
	 *            认证ID
	 * @return 影响的行数
	 * 
	 */
	public int delAuths(long... ids) {

		int result = 0;
		if (ids.length > 1) {
			result = ((AssetAuthDao) this.dao()).deleteAuths(ids);
			if (result > 0) {
				init();
			}
		} else {
			result = this.delete(ids[0]);
			if (result > 0) {
				authMap.remove(travel(ids[0]));
			}
		}
		return result;
	}

	/**
	 * 添加一条认证记录
	 * 
	 * @param auth
	 *            要被添加的认证对象
	 * @return 添加后的认证对象
	 */
	public AssetAuth addAuth(AssetAuth auth) {
		
		AssetAuth result = null;
		AuthQueryCnd aqc = new AuthQueryCnd();
		aqc.setIp(auth.getIp());
		aqc.setProtocol(auth.getProtocol());
		aqc.setPort(auth.getPort());
		aqc.setUrl(auth.getUrl());
		aqc.setInstanceName(auth.getInstanceName());
		if (checkAuth(aqc) == null) {
			auth.setId(getTblMaxIdWithUpdate());
			result = this.dao().insert(auth);
		}
		if (result != null) {
			StringBuilder sbuilder = new StringBuilder();
			sbuilder.append(auth.getIp() == null ? "" : auth.getIp());
			sbuilder.append(auth.getUrl() == null ? "" : auth.getUrl());
			sbuilder.append(auth.getProtocol() == null ? "" : auth
					.getProtocol());
			sbuilder.append(auth.getPort());
			sbuilder.append(auth.getInstanceName() == null ? "" : auth
					.getInstanceName());
			authMap.put(sbuilder.toString().toLowerCase(), result);
		}
		return result;

	}

	/**
	 * 清空认证记录
	 * 
	 * @return 影响的行数
	 */
	public int delall() {
		int result = clear();
		init();
		return result;
	}

	/**
	 * 检查是否存在重复认证记录
	 * 
	 * @param aqc
	 *            查询条件
	 * @return 对象本身
	 */
	public AssetAuth checkAuth(AuthQueryCnd aqc) {
		Condition condition = AssetAuthDao.createCnd(aqc);
		return fetch(condition);
	}
	
	/**
	 * 遍历认证信息缓存
	 * 
	 * @param id
	 * @return
	 */
	private String travel(long id) {
		AssetAuth value = null;
		Iterator<?> iter = this.authMap.entrySet().iterator();
		while (iter.hasNext()) {
			@SuppressWarnings("unchecked")
			Entry<String, AssetAuth> entry = (Entry<String, AssetAuth>) iter
					.next();
			String key = (String) entry.getKey();
			value = (AssetAuth) entry.getValue();
			if (value.getId() == id) {
				return key;
			}
		}
		return null;
	}
	
	/**
	 * 根据认证对象组装key
	 * @param auth
	 * @return
	 */
	private String createKey(AssetAuth auth){
		StringBuilder sbuilder=new StringBuilder();
		sbuilder.append((auth.getIp() == null) ? "" : auth.getIp());
		sbuilder.append((auth.getUrl() == null) ? "" : auth.getUrl());
		sbuilder.append((auth.getProtocol() == null) ? "" : auth
				.getProtocol());
		sbuilder.append(auth.getPort());
		sbuilder.append((auth.getInstanceName() == null) ? "" : auth
				.getInstanceName());
		return sbuilder.toString();
	}
}
