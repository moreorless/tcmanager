/**
 
 * Author: wangxh
 * Created: 2011-5-24
 */
package com.radixdigit.tcmanager.asset.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.nutz.dao.Condition;
import org.nutz.dao.Dao;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.dao.NodeProxyDao;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeInterface;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.asset.service.node.AssetLinkService;
import com.radixdigit.tcmanager.commons.service.TblIdsEntityService;

/**
 * 节点代理服务
 * 
 * @author wangxh
 * 
 */
@IocBean(name = "nodeProxyService")
public class NodeProxyService extends TblIdsEntityService<NodeProxy> {

	@Inject("refer:nodeProxyDao")
	public void setUserDao(Dao dao) {
		setDao(dao);
	}

	@Inject("refer:assetLinkService")
	private AssetLinkService linkService;

	/**
	 * 添加拓扑关系
	 * 
	 * @param proxys
	 * @return
	 */
	public NodeProxy[] addProxy(NodeProxy... proxys) {
		return ((NodeProxyDao) this.dao()).addNodeProxy(proxys);
	}
	/**
	 * 获取拓扑节点
	 * @param proxy
	 * @return
	 */
	public NodeInterface getNodeByProxy(NodeProxy proxy){
		return ((NodeProxyDao) this.dao()).getNodeByProxy(proxy);
	}
	/**
	 * 修改拓扑节点
	 * @param proxy
	 * @return
	 */
	public int updateNode(NodeProxy proxy){
		return ((NodeProxyDao) this.dao()).updateNode(proxy);
	}

	/**
	 * 删除拓扑关系
	 * 
	 * @param proxyIds
	 * @return
	 */
	public int deleteProxy(long... proxyIds) {
		linkService.clearLinks(proxyIds);// 删除连接线
		return ((NodeProxyDao) this.dao()).deleteNodeProxy(proxyIds);

	}

	/**
	 * 修改拓扑关系
	 * 
	 * @param proxys
	 * @return
	 */
	public int updateProxy(NodeProxy... proxys) {
		if (proxys == null || proxys.length == 0) {
			return NodeConstant.RETURN_INVALID;
		}
		return this.dao().update(proxys);
	}

	/**
	 * 读取组内的所有直属节点（包括资产、辅助图元、连接以及组对象）
	 * 
	 * @param groupId
	 *            组ID
	 * @param viewType
	 *            视图类型,见NodeConstant
	 */
	public List<NodeProxy> getProxysInGroup(long groupId, int viewType) {
		return ((NodeProxyDao) this.dao())
				.queryProxysInGroup(groupId, viewType);
	}

	public List<NodeProxy> getProxysInGroup(long groupId, int viewType, int polymorphic){
		return ((NodeProxyDao) this.dao())
				.queryProxysInGroup(groupId, viewType, polymorphic);
	}
	
	/**
	 * 读取组内的所有直属节点信息（包括资产、辅助图元、连接以及组对象）
	 * @param cnd 查询条件
	 * @return
	 */
	public List<NodeProxy> getProxysInGroup(Condition cnd) {
		return ((NodeProxyDao) this.dao()).queryProxysInGroup(cnd);
	}
	
	/**
	 * 递归读取组、子组内的所有节点信息（包括子组、资产、辅助图元、连接等）
	 * 
	 * @param groupId
	 * @param viewType
	 * @return
	 */
	public List<NodeProxy> getProxysRecursive(long groupId, int viewType) {
		List<NodeProxy> ls = getProxysInGroup(groupId, viewType);
		List<NodeProxy> temp=new ArrayList<NodeProxy>();
//		int i = 0;
		for (NodeProxy proxy : ls) {
			if (proxy.getNodeType() == NodeConstant.NODETYPE_GROUP) {
				long id = proxy.getId();
//				ls.remove(i);
				temp.addAll(getProxysRecursive(id, viewType));
			}
//			i++;
		}
		ls.addAll(temp);
		return ls;
	}

	/**
	 * 清除组内的所有数据
	 * @param groupId
	 * @param viewType
	 */
	public void clearGroupRecursive(long groupId, int viewType){
		List<NodeProxy> proxyList = getProxysRecursive(groupId, viewType);
		Iterator<NodeProxy> iter = proxyList.iterator();
		while(iter.hasNext()){
			NodeProxy proxy = iter.next();
			((NodeProxyDao)dao()).deleteProxyAndNode(proxy);
		}
	}
	
	
	/**
	 * 根据节点ID查询节点代理
	 * @param nodeId
	 * @param nodeType
	 * @param viewType
	 * @return
	 */
	public List<NodeProxy> getProxyByNodeId(long nodeId,int nodeType,int viewType){
		List<NodeProxy> proxys=((NodeProxyDao)dao()).queryProxysByNodeId(nodeType, viewType, nodeId);
		if(proxys!=null && proxys.size()>0){
			return proxys;
		}else{
			return new ArrayList<NodeProxy>();
		}
	}
	/**
	 * 根据proxyId获取节点代理
	 * @param proxyId
	 * @return
	 */
	public NodeProxy getProxyByProxyId(long proxyId){
		return ((NodeProxyDao)dao()).getProxyByProxyId(proxyId);
	}
	/**
	 * 根据nodeId获取NodeProxy对象列表
	 * @param pgid
	 * @return
	 */
	public List<NodeProxy> getProxyByNodeId(long nodeId) {
		List<NodeProxy> nodeList = ((NodeProxyDao) this.dao()).getProxyByNodeId(nodeId);
		return nodeList;
	}
	
}
