
package com.radixdigit.tcmanager.asset.data.node;

import java.io.Serializable;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

import com.radixdigit.tcmanager.asset.data.NodeInterface;


/**
 * 资产接口
 * @author wangxh
 *
 */
@Table("asset_interface")
public class AssetInterface implements NodeInterface, Serializable {
	/**
	 * 接口id
	 */
	@Column
	@Id(auto = false)
	private long id;

	/**
	 * 接口名称
	 */
	@Column
	private String name;

	/**
	 * 节点类型
	 */
	
	private int category;

	/**
	 * 管理开关：是否接受管理
	 */
	@Column
	private int manageSwitch;

	/**
	 * 状态
	 */
	@Column
	private int status;

	/**
	 * 描述
	 */
	@Column
	private String description;

	/**
	 * 创建时间
	 */
	@Column
	private long timeCreate;

	/**
	 * 修改时间
	 */
	@Column
	private long timeModify;

	//--专有属性
	
	/**
	 * 接口ip
	 */
	@Column
	private String ip;
	
	/**
	 * 接口序号
	 */
	@Column
	private long indexNumber;
	/**
	 * 
	 */
	@Column
	private String mask;
	
	/**
	 * 接口MAC
	 */
	@Column
	private String mac;
	
	/**
	 * 接口带宽
	 */
	@Column
	private int bandwidth;
	
	/**
	 * 上行或下行方向 1：上行 2：下行 
	 */
	@Column
	private int direction;
	
	/**
	 * 接口类型
	 */
	@Column
	private int type;

	/**
	 * 资产ID
	 */
	@Column
	private long assetId;
	
	/**
	 * 是否内置：1-是；2-否
	 */
	private int builtIn;
	/**
	 * 图标
	 */
	private String icon;
	
	@Override
	public long getId() {
		return this.id;
	}

	@Override
	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int getCategory() {
		return this.category;
	}

	@Override
	public void setCategory(int category) {
		this.category = category;
	}

	@Override
	public int getManageSwitch() {
		return this.manageSwitch;
	}

	@Override
	public void setManageSwitch(int manageSwitch) {
		this.manageSwitch = manageSwitch;
	}

	@Override
	public int getStatus() {
		return this.status;
	}

	@Override
	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String getDescription() {
		return this.description;
	}

	@Override
	public void setDescription(String desc) {
		this.description = desc;
	}

	@Override
	public long getTimeCreate() {
		return this.timeCreate;
	}

	@Override
	public void setTimeCreate(long timeCreate) {
		this.timeCreate = timeCreate;

	}

	@Override
	public long getTimeModify() {
		return this.timeModify;
	}

	@Override
	public void setTimeModify(long timeModify) {
		this.timeModify = timeModify;

	}

	public void setType(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

	public void setIndex(long index) {
		this.indexNumber = index;
	}

	public long getIndex() {
		return indexNumber;
	}

	public void setMask(String mask) {
		this.mask = mask;
	}

	public String getMask() {
		return mask;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	public String getMac() {
		return mac;
	}

	public void setBandwidth(int bandwidth) {
		this.bandwidth = bandwidth;
	}

	public int getBandwidth() {
		return bandwidth;
	}

	public void setAssetId(long assetId) {
		this.assetId = assetId;
	}

	public long getAssetId() {
		return assetId;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getIp() {
		return ip;
	}

	public void setDirection(int direction) {
		this.direction = direction;
	}

	public int getDirection() {
		return direction;
	}
	/**
	 * 是否内置：1-是；2-否
	 * @return
	 */
	public int getBuiltIn(){
		return this.builtIn;
	}
	/**
	 * 
	 * @param builtIn
	 */
	public void setBuiltIn(int builtIn){
		this.builtIn=builtIn;
	}
	/**
	 * 图标
	 * @return
	 */
	public String getIcon(){
		return this.icon;
	}
	/**
	 * 
	 * @param icon
	 */
	public void setIcon(String icon){
		this.icon=icon;
	}
}
