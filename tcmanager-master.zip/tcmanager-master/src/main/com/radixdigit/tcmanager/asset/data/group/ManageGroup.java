/**
 
 * Author: wangxh
 * Created: 2011-4-14
 */
package com.radixdigit.tcmanager.asset.data.group;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Table;

import com.radixdigit.tcmanager.asset.data.NodeConstant;

/**
 * 资产管理组
 * 
 * @author wangxh
 * 
 */
@Table("asset_v_manage")
public class ManageGroup extends AbstractGroup {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 6337563729652722172L;

	/**
	 * 价值
	 */
	@Column
	private int value;

	/**
	 * 联系人
	 */
	@Column
	private String contact;

	/**
	 * 背景图
	 */
	@Column
	private String bgImage;
	
	/**
	 * 背景颜色
	 */
	@Column
	private int bgColor = -1;
	
	/**
	 * 界面辅助图形url串
	 */
	@Column
	private String graphUrl;

	/**
	 * 拓扑图的位置是否保存过，若没有，在界面上进行自动布局
	 */
	@Column
	private boolean posSaved;
	
	public int getBgColor() {
		return bgColor;
	}

	public void setBgColor(int bgColor) {
		this.bgColor=bgColor;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getContact() {
		return contact;
	}

	public void setBgImage(String bgImage) {
		this.bgImage = bgImage;
	}

	public String getBgImage() {
		return bgImage;
	}

	public void setGraphUrl(String graphUrl) {
		this.graphUrl = graphUrl;
	}

	public String getGraphUrl() {
		return graphUrl;
	}

	
	
	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	@Override
	public int getViewType() {
		return NodeConstant.VIEW_MANAGE;
	}

	public boolean isPosSaved() {
		return posSaved;
	}

	public void setPosSaved(boolean posSaved) {
		this.posSaved = posSaved;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
