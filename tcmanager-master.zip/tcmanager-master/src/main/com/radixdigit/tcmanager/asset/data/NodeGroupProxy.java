/**
 
 * Author: wangxh
 * Created: 2011-5-17
 */
package com.radixdigit.tcmanager.asset.data;

import java.util.ArrayList;
import java.util.List;

/**
 * 组对象代理,通过此对象可以生成对象树
 * @author wangxh
 *
 * 
 */
public class NodeGroupProxy implements java.io.Serializable{
	/**
	 * 当前组节点。
	 */
	private  NodeInterface node;
	
	/**
	 * 孩子节点
	 */
	private List<NodeGroupProxy> children = new ArrayList<NodeGroupProxy>();
	
	/**
	 * 视图类型
	 */
	private int viewType;
	
	public NodeInterface getNode() {
		return node;
	}

	public void setNode(NodeInterface node) {
		this.node = node;
	}

	public List<NodeGroupProxy> getChildren() {
		return children;
	}

	public void setChildren(List<NodeGroupProxy> children) {
		this.children.clear();
		this.children.addAll(children);
	}

	public void setViewType(int viewType) {
		this.viewType = viewType;
	}

	public int getViewType() {
		return viewType;
	}
	
	/**
	 * 删除所有孩子节点
	 */
	public void deleteChildren(){
		this.children.clear();
	}

}
