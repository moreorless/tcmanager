package com.radixdigit.tcmanager.asset.dao.node;

import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.dao.sql.OrderBy;
import org.nutz.dao.Sqls;
import org.nutz.dao.entity.Entity;
import org.nutz.dao.impl.NutDao;
import org.nutz.dao.sql.Sql;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.lang.Mirror;

import com.radixdigit.tcmanager.asset.dao.NodeProxyDao;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeInterface;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.commons.mvc.Pager;

public abstract class NodeDao<T extends NodeInterface> extends NutDao {

	private Mirror<T> mirror = null;
	private Class<T> entryClass = null;
	
	/**
	 * 数据类对应的数据表,从泛型参数初始化
	 */
	private String entityTableName = null;
	
	private static final Logger logger = Logger.getLogger(NodeDao.class);
	
	@Inject("refer:nodeProxyDao")
	private NodeProxyDao nodeProxyDao;
	
	public NodeDao(){
		try {
			entryClass = (Class<T>) Mirror.getTypeParam(getClass(),0);
			mirror = Mirror.me(entryClass);
			logger.debug("Get TypeParams for self : " + entryClass.getName());
		}
		catch (Throwable e) {
			logger.warn("!!!Fail to get TypeParams for self!", e);
		}
	}
	
	public Class<T> getEntryClass(){
		return entryClass;
	}
	
	/**
	 * 获取数据类对应的表名
	 * @return
	 */
	public String getEntityTableName(){
		if(entityTableName == null && entryClass != null){
			Entity<T> entity = getEntity(entryClass);
			entityTableName = entity.getTableName();
		}

		return entityTableName;
	}
	
	/**
	 * 获取节点类型
	 * @return
	 */
	public int getNodeType(){
		return mirror.born().getCategory();
	}
	
	/**
	 * 查询所有直属节点代理
	 * 默认提供一个效率不高的通用实现，先从asset_relation表读取关联关系，然后获取每个关联关系对应的节点对象
	 * 如果需要提高效率，可采用关联表读取的方式，在子类中进行优化
	 * 
	 * @param groupId
	 * @param viewType
	 * @return
	 */
	public List<NodeProxy> queryProxyInGroup(long groupId, int viewType){
		Condition cnd = Cnd.where("nodeType", "=", getNodeType()).and("pNodeType", "=", NodeConstant.NODETYPE_GROUP)
				.and("pNodeId", "=", groupId).and("viewType", "=", viewType);
		List<NodeProxy> nodeProxyList = nodeProxyDao.query(NodeProxy.class, cnd, null);
		Iterator<NodeProxy> iter = nodeProxyList.iterator();
		while(iter.hasNext()){
			NodeProxy proxy = iter.next();
			proxy.setNode(nodeProxyDao.getNodeByProxy(proxy));
		}
		return nodeProxyList;
	}

	/**
	 * 查询所有直属节点对象（分页）
	 * 
	 * @param groupId
	 * @param viewType
	 * @param pager
	 * @return
	 */
	public Pager<T> queryNodeInGroup(long groupId, int viewType, Pager<T> pager){
		return queryNodeInGroup(groupId, viewType, null, pager);
	}
	
	/**
	 * 查询所有直属节点对象（分页）
	 * 
	 * @param groupId
	 * @param viewType
	 * @param cnd 查询条件
	 * @param pager
	 * @return
	 */
	public Pager<T> queryNodeInGroup(long groupId, int viewType, Condition cnd, Pager<T> pager){
		Condition appendCnd = Cnd.where("pNodeId", "=", groupId)
				.and("viewType", "=", viewType)
				.and("nodeType", "=", getNodeType())
				.and("pNodeType", "=", NodeConstant.NODETYPE_GROUP); 
				
			List<NodeProxy> proxys = this.query(NodeProxy.class, appendCnd, null);

			if (proxys != null && proxys.size() > 0) {
				long[] nodeIds = new long[proxys.size()];
				for (int i = 0; i < proxys.size(); i++) {
					nodeIds[i] = proxys.get(i).getNodeId();
				}
				
				if (nodeIds.length == 0) {
					return null;
				}
				Condition newCnd = Cnd.where("id", "IN", nodeIds);
				
				// 从分页信息提取条件
				if (pager != null && pager.getSidx() != null) { //设置排序字段和方向
					Mirror.me(OrderBy.class).invoke(newCnd, pager.getSord(), pager.getSidx());
				}
				
				return enPager(pager, mergeCondition(newCnd, cnd));
			} else {
				return pager;
			}

	}
	
	/**
	 * 合并查询条件
	 * @param cnd		原查询条件
	 * @param appendCnd	待合并的条件
	 * @return
	 */
	protected Condition mergeCondition(Condition cnd, Condition appendCnd){
		if(appendCnd == null) return cnd;
		
		Condition newCondition = null;
		// " WHERE pNodeId=1 AND viewType=1 AND nodeType=1 AND pNodeType=4"
		String appendWhere = appendCnd.toSql(getEntity(entryClass));
		
		Pattern where = Pattern.compile("^[ \t]*WHERE[ \t]+", Pattern.CASE_INSENSITIVE);
		
		if(cnd == null){
			newCondition = appendCnd;
		}else{
			String conStr = cnd.toSql(getEntity(entryClass));
			if (conStr == null) {
				newCondition = appendCnd;
			} else if (where.matcher(conStr).find()) {
				newCondition = Cnd.wrap(conStr.replaceFirst("^[ \t]*WHERE[ \t]+", appendWhere + " AND "));
			} else {
				newCondition = Cnd.wrap(appendWhere + " " + conStr);
			}
		}
		
		return newCondition;
	}

	
	protected Pager<T> enPager(Pager<T> pager, Condition cnd) {
		org.nutz.dao.pager.Pager nutzPager = null;
		if (pager != null) {
			nutzPager = this.createPager(pager.getPage(), pager.getPageSize());
		} else {
			pager = new Pager<T>();
		}
		List<T> ls = this.query(entryClass, cnd, nutzPager);
		pager.setRecords(this.count(entryClass, cnd));
		pager.setData(ls);
		return pager;
	}
	
	/**
	 * 根据节点ID删除节点（不含拓扑关系）
	 * 
	 * @param ids
	 * @return
	 */
	public int deleteById(long... ids){
		if(ids==null || ids.length==0){
			return 0;
		}
		return this.clear(entryClass, Cnd.where("id", "in", ids));
	}


	/**
	 * 根据节点ID查询节点代理
	 * 
	 * @param nodeId
	 * @param viewType
	 * @return
	 */
	public List<NodeProxy> queryProxyById(long nodeId, int viewType){
		List<NodeProxy> result = null;

		Cnd cnd = Cnd.where("nodeId", "=", nodeId);
		cnd.and("nodeType", "=", getNodeType());
		cnd.and("viewType", "=", viewType);

		T node = this.fetch(entryClass, nodeId);
		if (node != null) {
			result = this.query(NodeProxy.class, cnd, null);
			for (NodeProxy proxy : result) {
				proxy.setNode(node);
			}
		}
		return result;
	}

	/**
	 * 根据节点ID查询节点对象（分页）
	 * 
	 * @param pager
	 * @param ids
	 * @return
	 */
	public Pager<T> queryById(Pager<T> pager, long... ids){
		if (ids.length == 0) {
			return null;
		}
		Condition cnd = Cnd.where("id", "IN", ids);
		return enPager(pager, cnd);
	}
	
	/**
	 * 根据节点ID查询节点对象（不分页）
	 * 
	 * @param ids
	 * @return
	 */
	public List<T> queryById(long... ids){
		return this.query(entryClass, Cnd.where("id", "IN", ids), null);
	}
	
	/**
	 * 清除冗余节点
	 */
	public void clearRedundantNodes(){
		Sql sql = Sqls
				.create("delete from " + getEntityTableName() + " where id not in (select distinct nodeId from asset_relation)");
		this.execute(sql);

	}
	
	/**
	 * 根据节点ID,查询它所归属于哪些节点组（仅限关系对象，不含组对象）
	 * 
	 * @param viewType
	 * @param nodeIds
	 * @return
	 */
	public List<NodeProxy> queryGroupByNodeId(int viewType, long... nodeIds){
		Cnd cnd = Cnd.where("nodeId", "in", nodeIds);
		if (viewType != 0) {
			cnd.and("viewType", "=", viewType);
		}
		cnd.and("pNodeType", "=", NodeConstant.NODETYPE_GROUP);
		cnd.and("nodeType", "=", getNodeType());
		return this.query(NodeProxy.class, cnd, null);
	}
	
	/**
	 * 更新节点状态信息
	 * @param node
	 */
	public void updateStatus(NodeInterface node){
		Sql sqls = Sqls.create("update " + getEntityTableName() + " set status=" + node.getStatus() + " where id=" + node.getId());
		this.execute(sqls);
	}
	
}
