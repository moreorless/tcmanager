package com.radixdigit.tcmanager.asset.auth.dao;

import java.util.List;

import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.dao.util.cri.SqlExpressionGroup;
import org.nutz.dao.impl.NutDao;
import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.auth.data.AssetAuth;
import com.radixdigit.tcmanager.asset.auth.data.AuthQueryCnd;


@IocBean(name = "assetAuthDao", fields = { "dataSource" })
public class AssetAuthDao extends NutDao {

	
	/**
	 * 组装查询条件
	 * 
	 * @param aqc 查询对象
	 * @return 组装后的查询条件
	 */
	public static Condition createCnd(AuthQueryCnd aqc) {

		// ID查询
		if (aqc.getId() != 0L) {
			return Cnd.where("id", "=", aqc.getId());
		}

		// 复合主键查询
		String ip = aqc.getIp();
		String url = aqc.getUrl();
		String protocol = aqc.getProtocol();
		String instance = aqc.getInstanceName();
		int port = aqc.getPort();

		Cnd cnd = null;
		SqlExpressionGroup e = null;

		if (ip != null && ip.length() > 0) {
			cnd = Cnd.where("ip", "=", ip);
		}
		if (url != null && url.length() > 0) {
			e = Cnd.exps("url", "=", url);
			cnd = (cnd == null) ? Cnd.where(e) : cnd.and(e);
		}
		if (protocol != null && protocol.length() > 0) {
			e = Cnd.exps("protocol", "=", protocol);
			cnd = (cnd == null) ? Cnd.where(e) : cnd.and(e);
		}
		if (port != 0) {
			e = Cnd.exps("port", "=", port);
			cnd = (cnd == null) ? Cnd.where(e) : cnd.and(e);
		}
		if (instance != null && instance.length() > 0) {
			e = Cnd.exps("instanceName", "=", instance);
			cnd = (cnd == null) ? Cnd.where(e) : cnd.and(e);
		}
		return cnd;
	}

	
	/**
	 * 根据ID删除多条认证记录
	 * 
	 * @param Ids
	 *            认证ID数组
	 * @return 影响的行数
	 * 
	 */
	public int deleteAuths(long[] ids) {	
		return this.clear(AssetAuth.class, Cnd.where("id", "in", ids));
	}
	
}
