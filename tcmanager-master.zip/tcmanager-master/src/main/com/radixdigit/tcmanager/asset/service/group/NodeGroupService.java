/**
 
 * Author: wangxh
 * Created: 2011-6-3
 */
package com.radixdigit.tcmanager.asset.service.group;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.nutz.ioc.Ioc;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.lang.Mirror;
import org.nutz.log.Log;
import org.nutz.log.Logs;
import org.nutz.service.EntityService;

import com.radixdigit.tcmanager.asset.dao.NodeProxyDao;
import com.radixdigit.tcmanager.asset.dao.group.NodeGroupDao;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.NodeGroupProxy;
import com.radixdigit.tcmanager.asset.data.NodeInterface;
import com.radixdigit.tcmanager.asset.data.NodeProxy;
import com.radixdigit.tcmanager.asset.data.group.AbstractGroup;
import com.radixdigit.tcmanager.asset.service.node.AssetLinkService;
import com.radixdigit.tcmanager.commons.mvc.Pager;
import com.radixdigit.tcmanager.commons.service.TblIdsEntityService;
import com.radixdigit.tcmanager.util.dao.TblMaxIdHelper;
/**
 * @author wangxh
 *
 */
public abstract class NodeGroupService <T extends NodeInterface> extends TblIdsEntityService<T>{
	
	public static String NODE_GROUP_ENTITY_NAME = "asset_nodegroup";
	
	private Mirror<T> mirror;
	private static final Log log = Logs.getLog(EntityService.class);
	
	@Inject("refer:nodeProxyDao")
	protected NodeProxyDao nodeProxyDao;
	
	@Inject("refer:assetLinkService")
	private AssetLinkService linkService;
	
	@SuppressWarnings("unchecked")
	public NodeGroupService() {
		try {
			Class<T> entryClass = (Class<T>) Mirror.getTypeParam(getClass(),0);
			mirror = Mirror.me(entryClass);
			if (log.isDebugEnabled())
				log.debugf("Get TypeParams for self : %s", entryClass.getName());
		}
		catch (Throwable e) {
			if (log.isWarnEnabled())
				log.warn("!!!Fail to get TypeParams for self!", e);
		}
	}
	
	/**
	 * 设置组dao
	 * @param dao
	 */
	public abstract void setNodeGroupDao(NodeGroupDao<T> dao);
	/**
	 * 获取组dao
	 * @return
	 */
	public abstract NodeGroupDao<T> getNodeGroupDao();
	
	/**
	 * 获取服务类关联的视图类型
	 * @return	视图类型, 参见NodeContant.VIEW_
	 */
	public int getViewType(){
		return ((AbstractGroup)(mirror.born())).getViewType();
	}
	
	/**
	 * 获取整个组的树结构
	 * @return
	 */
	public NodeGroupProxy getGroupTree(){
		return getGroupRecurve(getRootNodeId());
	}
	
	/**
	 * 递归获取资产组的树结构
	 * @param groupId
	 *            起点组ID
	 * @return
	 */
	public NodeGroupProxy getGroupRecurve(long groupId) {
		NodeGroupProxy proxy = new NodeGroupProxy();
		if (groupId==NodeConstant.ID_ROOT) {// 根节点
			T node = mirror.born();
			node.setId(NodeConstant.ID_ROOT);
			node.setCategory(NodeConstant.NODETYPE_GROUP);
			node.setManageSwitch(NodeConstant.MANAGE_ON);
			node.setStatus(NodeConstant.STATUS_RUNNING);
			node.setName("root");
			proxy.setNode(node);
		} else {// 非根节点，先组装当前节点对象
			List<T> ls = getNodeGroupDao().queryById(groupId);
			if (ls == null || ls.size() == 0) {
				return null;
			} else {
				proxy.setNode(ls.get(0));
			}
		}
		proxy.setChildren(createGroupProxy(groupId));
		return proxy;
	}
	private List<NodeGroupProxy> createGroupProxy(long groupId) {
		List<NodeGroupProxy> proxys = new ArrayList<NodeGroupProxy>();
		Pager<T> pager = getNodeGroupDao().queryNodeInGroup(groupId, null);
		List<T> groups = pager.getData();
		if (groups != null) {
			for (NodeInterface group : groups) {
				NodeGroupProxy proxy = new NodeGroupProxy();
				proxy.setNode(group);
				List<NodeGroupProxy> children = createGroupProxy(group.getId());
				if (!children.isEmpty()) {
					proxy.setChildren(children);
				}
				proxys.add(proxy);
			}
		}
		return proxys;
	}
	/**
	 * 获取组内的直属节点代理
	 * 
	 * @param groupId
	 * @param viewType
	 * @return
	 */
	public List<NodeProxy> getProxysInGroup(long groupId) {
		return ((NodeGroupDao) dao()).queryProxyInGroup(groupId);

	}

	/**
	 * 递归查找子组代理（不填充节点内容）
	 * @param groupId		当前组id
	 * @return
	 */
	public List<NodeProxy> getSubGroupProxyRecurse(long groupId){
		return ((NodeGroupDao) dao()).querySubGroupProxyRecurse(groupId);
	}
	
	
	/**
	 * 获取组内的直属节点（用于分页）
	 * 
	 * @param groupId
	 * @param viewType
	 * @param pager
	 * @return
	 */
	public Pager<T> getNodesInGroup(long groupId, Pager<T> pager) {
		return ((NodeGroupDao) dao()).queryNodeInGroup(groupId, pager);
	}

	/**
	 * 添加节点及拓扑关系
	 * 
	 * @param proxy
	 * @return
	 */
	public NodeProxy addNode(NodeProxy proxy) {
		if (proxy == null || proxy.getNode() == null)
			return null;
		T t = (T) proxy.getNode();
		if(t.getId() == 0){
			t.setId(getTblMaxIdWithUpdate());
		}
		T node = dao().insert(t);
		if (node != null) {
			proxy.setNodeId(node.getId());
			proxy.setNodeType(node.getCategory());
			
			NodeProxy[] nodeProxys = nodeProxyDao.addNodeProxy(proxy);
			if (nodeProxys != null && nodeProxys.length > 0) {
				return nodeProxys[0];
			}	
		} 
		return null;
	}
	
	/**
	 * 添加节点及拓扑关系
	 * 	   导入导出,需要设定id,不能自动累加id
	 * @param proxy
	 * @return
	 * @author tianming
	 */
	public NodeProxy addNode_NoId(NodeProxy proxy) {
		if (proxy == null || proxy.getNode() == null)
			return null;
		T t = (T) proxy.getNode();
		//t.setId(getTblMaxIdWithUpdate());
		T node = dao().insert(t);
		if (node != null) {
			proxy.setNodeId(node.getId());
			proxy.setNodeType(node.getCategory());
			
			NodeProxy[] nodeProxys = nodeProxyDao.addNodeProxy(proxy);
			if (nodeProxys != null && nodeProxys.length > 0) {
				return nodeProxys[0];
			}	
		}
		return null;
	}

	/**
	 * 删除节点及拓扑关系
	 * 
	 * @param ids
	 * @return
	 */
	public int deleteNodes(long... ids) {
		if (ids == null || ids.length == 0) {
			return 0;
		}
		return clearRecurve(ids);
	}



	/**
	 * 修改节点属性
	 * 
	 * @param nodes
	 * @return
	 */
	public int updateNodes(T... nodes) {
		if (nodes == null || nodes.length == 0)
			return NodeConstant.RETURN_INVALID;
		return dao().update(nodes);
	}

	/**
	 * 根据节点ID获取节点代理
	 * 
	 * @param nodeId
	 * @param viewType
	 * @return
	 */
	public NodeProxy getProxyById(long nodeId) {
		return ((NodeGroupDao) dao()).queryProxyById(nodeId);
	}

	/**
	 * 根据节点ID获取节点对象
	 * 
	 * @param ids
	 * @return
	 */
	public List<T> getById(long... ids) {
		return ((NodeGroupDao) this.dao()).queryById(ids);
	}
	
	/**
	 * 查询节点所归属的节点组
	 * 
	 * @param nodeId
	 * @param nodeType		节点类型(资产、组等)
	 * @return 节点组ID列表
	 */
	public long[] getGroupsOfNode(long nodeId, int nodeType){
		 
		
		List<NodeProxy> proxys = this.nodeProxyDao.queryGroupByNodeId(
				getViewType(), nodeType,
				nodeId);
		if (proxys != null && proxys.size() > 0) {
			long[] groupIds = new long[proxys.size()];
			int i = 0;
			for (NodeProxy proxy : proxys) {
				groupIds[i] = proxy.getpNodeId();
				i++;
			}
			return groupIds;
		}
		return null;
	}
	
	/**
	 * 检查是否有重名
	 * @param name
	 * @return
	 */
	public T checkName(String name){
		return  (T) ((NodeGroupDao) dao()).checkName(name);
	}

	/**
	 * 删除节点的连线
	 * @param ids 节点ID
	 * @return
	 */
	protected  int clearLinks(long... ids){
		/*List<NodeProxy> ls = nodeProxyDao.queryProxysByNodeId(
				NodeConstant.NODETYPE_GROUP, NodeConstant.VIEW_MANAGE, ids);*/
		List<NodeProxy> ls = nodeProxyDao.queryProxysByNodeId(
				NodeConstant.NODETYPE_GROUP, getViewType(), ids);
		if (ls == null || ls.size() == 0) {
			return NodeConstant.RETURN_INVALID;
		}

		int length = ls.size();
		long[] proxyIds = new long[length];
		for (int i = 0; i < length; i++) {
			proxyIds[i] = ls.get(i).getId();
		}

		return linkService.clearLinks(proxyIds);
	}
	
	/**
	 * 递归删除组节点、和与改组相关的关联关系，不删除组内的资产节点等	
	 * @param ids
	 * @return
	 */
	protected int clearRecurve(long... ids){
		NodeGroupProxy gProxy = null;
		for (long id : ids) {
			gProxy = getGroupRecurve(id);
			List<Long> idList = new ArrayList<Long>();
			getGroupId(gProxy, idList);
			long[] gIds = new long[idList.size()];
			for (int i = 0; i < gIds.length; i++) {
				gIds[i] = idList.get(i);
			}

			// 删除组节点
			getNodeGroupDao().deleteById(gIds);

			// 删除关系
			nodeProxyDao.deleteProxyByNodeId(NodeConstant.NODETYPE_GROUP,
					getViewType(), gIds);
		}

		return ids.length;
	}
	/**
	 * 递归获取组ID
	 * 
	 * @param proxy
	 * @param ids
	 */
	private void getGroupId(NodeGroupProxy proxy, List<Long> ids) {
		ids.add(proxy.getNode().getId());
		List<NodeGroupProxy> proxys = proxy.getChildren();
		if (proxys != null && proxys.size() > 0) {
			for (NodeGroupProxy ngproxy : proxys) {
				getGroupId(ngproxy, ids);
			}
		}
	}
	/**
	 * 获取该组的根节点
	 * @return
	 */
	public NodeInterface getRootNode(){
		List<NodeProxy> proxyList = nodeProxyDao.queryProxysInGroup(NodeConstant.ID_ROOT, getViewType());
		if(proxyList.size() > 0){
			return proxyList.get(0).getNode();
		}
		return null;
	}
	
	/**
	 * 获取该组的根节点id，即asset_relation表中，父节点为0的节点
	 * @return
	 */
	public long getRootNodeId(){
		List<NodeProxy> proxyList = nodeProxyDao.queryProxysInGroup(NodeConstant.ID_ROOT, getViewType());
		if(proxyList.size() > 0){
			NodeProxy proxy = proxyList.get(0);				// NodeConstant.ID_ROOT下只有一个子节点，即该组的根节点
			return proxy.getNodeId();
		}
		return NodeConstant.ID_ROOT;
	}
	
	/**
	 * 重写父类的三个方法，确保实现该抽象类的子类对象能够生成互不相同的id。
	 */
	@Override
	protected long getTblMaxId() {
		
		return TblMaxIdHelper.getTblMaxId(this.dao(), NODE_GROUP_ENTITY_NAME);

	}
	
	@Override
	protected void updateTblMaxId() {
		
		TblMaxIdHelper.updateTblMaxId(this.dao(), NODE_GROUP_ENTITY_NAME);
		
	}
	
	/**
	 * 获取一个新的ID，并同时更新sys_tblids表中的记录
	 * @return 新的ID值
	 */
	@Override
	protected long getTblMaxIdWithUpdate() {
		
		return TblMaxIdHelper.getTblMaxIdWithUpdate(this.dao(), NODE_GROUP_ENTITY_NAME);
		
	}


}
