/**
 
 * Author: wangxh
 * Created: 2011-5-27
 */
package com.radixdigit.tcmanager.asset.dao.group;

import org.nutz.ioc.loader.annotation.IocBean;

import com.radixdigit.tcmanager.asset.data.group.ManageGroup;

/**
 * @author wangxh
 * 
 */
@IocBean(name = "manageGroupDao", fields = { "dataSource" })
public class ManageGroupDao extends NodeGroupDao<ManageGroup> {



}
