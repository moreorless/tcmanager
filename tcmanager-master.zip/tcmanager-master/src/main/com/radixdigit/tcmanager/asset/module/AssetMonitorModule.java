package com.radixdigit.tcmanager.asset.module;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.nutz.ioc.Ioc;
import org.nutz.ioc.annotation.InjectName;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.Param;

import com.radixdigit.tcmanager.alert.base.IAlertAction;
import com.radixdigit.tcmanager.alert.data.Alert;
import com.radixdigit.tcmanager.alert.service.AlertService;
import com.radixdigit.tcmanager.annotation.AuthBy;
import com.radixdigit.tcmanager.asset.auth.data.AssetAuth;
import com.radixdigit.tcmanager.asset.auth.data.AuthQueryCnd;
import com.radixdigit.tcmanager.asset.auth.service.AssetAuthService;
import com.radixdigit.tcmanager.asset.data.NodeConstant;
import com.radixdigit.tcmanager.asset.data.node.Asset;
import com.radixdigit.tcmanager.asset.data.node.AssetType;
import com.radixdigit.tcmanager.asset.polling.RadixCacheManager;
import com.radixdigit.tcmanager.asset.service.node.AssetService;
import com.radixdigit.tcmanager.asset.service.node.AssetTypeService;
import com.radixdigit.tcmanager.monitor.core.DefaultTask;
import com.radixdigit.tcmanager.monitor.core.MonitorDispatcherService;
import com.radixdigit.tcmanager.monitor.core.TaskContext;
import com.radixdigit.tcmanager.monitor.core.alert.Operator;
import com.radixdigit.tcmanager.monitor.core.config.beans.global.StatusItem;
import com.radixdigit.tcmanager.monitor.core.config.beans.global.StatusRestriction;
import com.radixdigit.tcmanager.monitor.core.config.beans.mversion.Concerns;
import com.radixdigit.tcmanager.monitor.core.dao.MonitorDao;
import com.radixdigit.tcmanager.monitor.core.data.ConcernsEntry;
import com.radixdigit.tcmanager.monitor.core.data.DefineConstant;
import com.radixdigit.tcmanager.monitor.core.data.TaskStruct;
import com.radixdigit.tcmanager.monitor.core.data.alert.AlertSetting;
import com.radixdigit.tcmanager.monitor.core.service.ConcernsEntryService;
import com.radixdigit.tcmanager.monitor.ext.radix.data.NetInfo;
import com.radixdigit.tcmanager.monitor.ext.radix.data.NetInfoParser;
import com.radixdigit.tcmanager.monitor.ext.radix.data.PingData;
import com.radixdigit.tcmanager.monitor.ext.radix.data.RadixPingInfo;
import com.radixdigit.tcmanager.monitor.service.ProMonitorService;
import com.radixdigit.tcmanager.monitor.view.data.InterfaceItemData;
import com.radixdigit.tcmanager.monitor.view.data.Monitor;
import com.radixdigit.tcmanager.monitor.view.data.MonitorProtocol;
import com.radixdigit.tcmanager.monitor.view.data.MonitorVersion;
import com.radixdigit.tcmanager.monitor.view.data.snapshot.SnapshotData;
import com.radixdigit.tcmanager.util.SerializeUtil;
import com.sun.org.apache.xalan.internal.xsltc.compiler.util.NodeType;

/**
 * 设备监控controller
 * @author gaoxl
 *
 */
@IocBean
@InjectName
@AuthBy(check=false)
@At("/asset/monitor/")
public class AssetMonitorModule {

	@Inject
	AssetService assetService;
	
	@Inject
	AssetAuthService assetAuthService;
	
	@Inject
	AssetTypeService assetTypeService;
	
	@Inject
	ProMonitorService proMonitorService;
	
	@Inject
	AlertService alertService;
	
	@Inject
	MonitorDao monitorDao;
	
	@Inject
	private ConcernsEntryService concernsEntryService;
	
	@Inject("refer:$setup_MonitorDispatcherService")
	private MonitorDispatcherService dispatcherService;
	
	@At
	@Ok("jsp:jsp.asset.monitor")
	public void detail(HttpServletRequest request, @Param("assetId") long assetId){
		Asset asset = assetService.fetch(assetId);
		request.setAttribute("asset", asset);
		
		AssetType assetType = assetTypeService.getByCode(asset.getType());
		request.setAttribute("assetType", assetType);
		
		TaskStruct ts = proMonitorService.getTaskStructByAssetId(assetId);
		request.setAttribute("taskStruct", ts);
		
		if(ts!=null){
			Monitor monitorObj = proMonitorService.getMonitorByTask(ts);
			request.setAttribute("monitorObj", monitorObj);
			
			request.setAttribute("usability", monitorObj.getUsability());
		}
		
		if(ts != null && ts.isEnabled()){
			SnapshotData snapshotData = proMonitorService.getSnapshotData(ts.getMtype(), ts.getId());
			request.setAttribute("snapshotData", snapshotData);

			// 读取接口数据
			Map<Integer, InterfaceItemData> interfaceItems = proMonitorService.getInterfaceItems(ts);
			request.setAttribute("interfaceItems", interfaceItems);
			
			// 读取告警
			long timeEnd = System.currentTimeMillis();
			Calendar cal = Calendar.getInstance(); 
			cal.set(Calendar.HOUR_OF_DAY, 0); 
			cal.set(Calendar.SECOND, 0); 
			cal.set(Calendar.MINUTE, 0); 
			cal.set(Calendar.MILLISECOND, 0);
			long timeBegin = cal.getTimeInMillis();
			List<Alert> alertList = alertService.getAlertsByMonitorId(ts.getId(), timeBegin, timeEnd);
			int alertCount = 0;
			if(alertList != null) alertCount = alertList.size();
			request.setAttribute("alertCount", alertCount);
			request.setAttribute("alertList", alertList);
			
			
		}
		
	}
	
	/**
	 * 启用设备监控
	 * @param assetId
	 */
	@At
	@Ok("json")
	@Fail("json")
	public void startMonitor(@Param("assetId") long assetId){
		Asset asset = assetService.fetch(assetId);
		
		asset.setManageSwitch(NodeConstant.MANAGE_ON);
		assetService.updateNodes(asset);

		// 启动监控调度
		TaskStruct ts = proMonitorService.getTaskStructByAssetId(assetId);
		if(!ts.isTask()) {
			ts.setTask(true);
			monitorDao.updateTaskStructOnly(ts);
		}
		
		proMonitorService.setStartTask(ts.getId());
		
	}
	/**
	 * 停止设备监控
	 * @param assetId
	 */
	@At
	@Ok("json")
	@Fail("json")
	public void stopMonitor(@Param("assetId") long assetId){
		Asset asset = assetService.fetch(assetId);
		
		asset.setManageSwitch(NodeConstant.MANAGE_OFF);
		assetService.updateNodes(asset);
		
		// 停止设备监控任务
		TaskStruct ts = proMonitorService.getTaskStructByAssetId(assetId);
		proMonitorService.setStopTask(ts.getId());
		
	}
	
	
	/**
	 * 根据设备类型获取版本列表
	 * @param ioc
	 * @param devtype  设备类型
	 * @return
	 */
	@At
	@Ok("json")
	@Fail("json")
	public List<MonitorVersion> searchMonitorVerson(Ioc ioc, @Param("devtype") String devtype) {
		String mtype = proMonitorService.getMtype(devtype);
		return proMonitorService.getVersionsByType(mtype);
	}
	
	/**
	 * 根据设备类型获取协议列表
	 * @param devtype
	 * @return
	 */
	@At
	@Ok("json")
	@Fail("json")
	public List<MonitorProtocol> searchMonitorProtocol(@Param("devtype") String devtype){
		String mtype = proMonitorService.getMtype(devtype);
		return proMonitorService.getProtocolsByType(mtype);
	}
	
	/**
	 * 读取设备的监控快照数据
	 * @param assetId
	 * @return
	 */
	@At
	@Ok("json")
	@Fail("json")
	public SnapshotData getSnapShotData(long assetId){
		SnapshotData snapshotData = null;
		TaskStruct ts = proMonitorService.getTaskStructByAssetId(assetId);
		if(ts != null){
			snapshotData = proMonitorService.getSnapshotData(ts.getMtype(), ts.getId());
		}
		return snapshotData;
	}
	
	/**
	 * 查看接口信息
	 * @param assetId	 设备id	
	 * @param ifIndexId	 接口序号
	 */
	@At
	@Ok("jsp:jsp.asset.interface")
	public void viewInterface(HttpServletRequest request, @Param("assetId") long assetId,
			@Param("ifIndexId") int ifIndexId){
		Asset asset = assetService.fetch(assetId);
		TaskStruct ts = proMonitorService.getTaskStructByAssetId(assetId);
		String concernskey = "ifStatus";
		ConcernsEntry concernsEntry = proMonitorService.getConcernsEntrysByKey(ts.getId(), concernskey, ifIndexId);
		String ifName = concernsEntry.getIndexName();
		request.setAttribute("taskStruct", ts);
		request.setAttribute("asset", asset);
		request.setAttribute("ifName", ifName);
	}
	
	/**
	 * 查看接口信息
	 * @param assetId	 设备id	
	 * @param ifIndexId	 接口序号
	 */
	@At
	@Ok("jsp:jsp.asset.interface")
	public void viewRadixInterface(HttpServletRequest request, @Param("assetId") long assetId,
			@Param("ifIndexId") int ifIndexId){
		Asset asset = assetService.fetch(assetId);
		TaskStruct ts = proMonitorService.getTaskStructByAssetId(assetId);
		String concernskey = "radixFlowTotal";
		ConcernsEntry concernsEntry = proMonitorService.getConcernsEntrysByKey(ts.getId(), concernskey, ifIndexId);
		String ifName = concernsEntry.getIndexName();
		request.setAttribute("taskStruct", ts);
		request.setAttribute("asset", asset);
		request.setAttribute("ifName", ifName);
	}
	
	/**
	 * 设置接口告警阈值
	 * @param request
	 * @param taskId
	 * @param ifIndexId
	 */
	@At
	@Ok("jsp:jsp.asset.monitor.setalert")
	public void setIfAlert(HttpServletRequest request, @Param("taskId") long taskId, 
			@Param("ifIndex") int ifIndex){
		List<ConcernsEntry> entryList = concernsEntryService.getIfEntryList(taskId, ifIndex);
		request.setAttribute("entryList", entryList);
		
		request.setAttribute("isInterfaceEntry", true);
		prepareAlertParams(request, entryList);
	}
	
	/**
	 * 设置流控设备的接口告警阈值
	 * @param request
	 * @param taskId
	 * @param ifIndexId
	 */
	@At
	@Ok("jsp:jsp.asset.monitor.setalert")
	public void setRadixIfAlert(HttpServletRequest request, @Param("taskId") long taskId, 
			@Param("ifIndex") int ifIndex){
		List<ConcernsEntry> entryList = concernsEntryService.getRadixIfEntryList(taskId, ifIndex);
		request.setAttribute("entryList", entryList);
		
		request.setAttribute("isInterfaceEntry", true);
		prepareAlertParams(request, entryList);
	}
	
	@At
	@Ok("jsp:jsp.asset.monitor.chart")
	public void viewCpu(HttpServletRequest request, @Param("taskId") long taskId){
		List<ConcernsEntry> entryList = new ArrayList<>();
		ConcernsEntry concernsEntry = concernsEntryService.getAverCpuUsageEntry(taskId);
		if(concernsEntry != null)  entryList.add(concernsEntry);
		request.setAttribute("entryList", entryList);
	}
	
	@At
	@Ok("jsp:jsp.asset.monitor.setalert")
	public void setCpuAlert(HttpServletRequest request, @Param("taskId") long taskId){
		List<ConcernsEntry> entryList = new ArrayList<>();
		ConcernsEntry concernsEntry = concernsEntryService.getAverCpuUsageEntry(taskId);
		if(concernsEntry != null) entryList.add(concernsEntry);
		request.setAttribute("entryList", entryList);
		
		prepareAlertParams(request, entryList);
	}
	
	@At
	@Ok("jsp:jsp.asset.monitor.chart")
	public void viewMem(HttpServletRequest request, @Param("taskId") long taskId){
		List<ConcernsEntry> entryList = new ArrayList<>();
		ConcernsEntry concernsEntry = concernsEntryService.getMemUsageEntry(taskId);
		if(concernsEntry != null)  entryList.add(concernsEntry);
		request.setAttribute("entryList", entryList);
	}
	
	@At
	@Ok("jsp:jsp.asset.monitor.setalert")
	public void setMemAlert(HttpServletRequest request, @Param("taskId") long taskId){
		List<ConcernsEntry> entryList = new ArrayList<>();
		ConcernsEntry concernsEntry = concernsEntryService.getMemUsageEntry(taskId);
		if(concernsEntry != null) entryList.add(concernsEntry);
		request.setAttribute("entryList", entryList);
		
		prepareAlertParams(request, entryList);
	}
	
	@At
	@Ok("jsp:jsp.asset.monitor.chart")
	public void viewDisk(HttpServletRequest request, @Param("taskId") long taskId){
		List<ConcernsEntry> entryList = concernsEntryService.getDiskUsageEntry(taskId);
		request.setAttribute("entryList", entryList);
	}
	@At
	@Ok("jsp:jsp.asset.monitor.setalert")
	public void setDiskAlert(HttpServletRequest request, @Param("taskId") long taskId){
		List<ConcernsEntry> entryList = concernsEntryService.getDiskUsageEntry(taskId);
		
		request.setAttribute("entryList", entryList);
		
		prepareAlertParams(request, entryList);
		
		
	}
	
	private void prepareAlertParams(HttpServletRequest request, List<ConcernsEntry> entryList){
		// 操作符map
		Map<Long, List<Operator>> opListMap = new HashMap<Long, List<Operator>>();
		// 状态值map
		Map<Long, Collection<StatusItem>> statusListMap = new HashMap<>();
		
		if(entryList != null){
			for(ConcernsEntry concernsEntry : entryList){
				if(concernsEntry == null) continue;
				
				List<Operator> opList = proMonitorService.getOpListByType(concernsEntry.getType());
				if(opList == null) continue;
				
				opListMap.put(concernsEntry.getId(), opList);
				
				if(concernsEntry.getType() == DefineConstant.TYPE_STATUS)
				{
					Concerns concerns = proMonitorService.getConcernsByEntryId(concernsEntry.getId());
					Collection<StatusItem> statusList = new ArrayList<StatusItem>();
					StatusRestriction sr = concerns.getStatusRestriction();
					if(sr != null){
						statusList = sr.listStatus();
						statusListMap.put(concernsEntry.getId(), statusList);
					}
					
				}
			}
			
		}
		request.setAttribute("opListMap", opListMap);
		request.setAttribute("statusListMap", statusListMap);
		
		Map<Long, AlertSetting> alertSettingMap = new HashMap<>();
		
		if(entryList != null){
			for(ConcernsEntry concernsEntry : entryList){
				if(concernsEntry == null) continue;
				String alertSettingXml = concernsEntry.getAlertSetting();
				if(alertSettingXml != null && alertSettingXml.trim().length() > 0)
				{
					AlertSetting alertSetting = (AlertSetting)SerializeUtil.getInstance(AlertSetting.class).fromXml(alertSettingXml);
					alertSettingMap.put(concernsEntry.getId(), alertSetting);
				}
			}
		}
		request.setAttribute("alertSettingMap", alertSettingMap);
	}
	
	
	@At("/saveAlertSetting")
	@Ok("json")
	public String saveAlertSetting(@Param("::alertSetting.") Map<Long, AlertSetting> alertSettingMap, 
			@Param("applyToAll") boolean applyToAll,
			@Param("taskId") long taskId, Ioc ioc, HttpServletRequest request)
	{
		ProMonitorService service = ioc.get(ProMonitorService.class, "proMonitorService");
		ConcernsEntryService concernsEntryService = ioc.get(ConcernsEntryService.class,"concernsEntryService");
		
		String saveResult = "";
		
		Collection<AlertSetting> alertSettringColl = alertSettingMap.values();
		Iterator<AlertSetting> iter = alertSettringColl.iterator();
		
		while(iter.hasNext()){
			AlertSetting alertSetting = iter.next();
			
			long concernsId = alertSetting.getConcernsEntryId();
			
			if(!applyToAll){
				alertSetting.setActions(new ArrayList<IAlertAction>());
				saveResult = service.saveAlertSetting(alertSetting);
			}else{
				List<ConcernsEntry> concernsEntrys = concernsEntryService.getConcernsEntrysByTaskIdAndConcernsId(taskId, concernsId);
				List<AlertSetting> alertSettingList = new ArrayList<AlertSetting>();
				for(int i=0;i<concernsEntrys.size();i++){
					ConcernsEntry concernsEntry = concernsEntrys.get(i);
					alertSetting.setConcernsEntryId(concernsEntry.getId());
					
					AlertSetting alertSet = new AlertSetting();
					alertSet.setConcernsEntryId(concernsEntry.getId());
					alertSet.setValueType(alertSetting.getValueType());
					alertSet.setIsInit1(alertSetting.getIsInit1());
					alertSet.setIsInit2(alertSetting.getIsInit2());
					alertSet.setIsInit3(alertSetting.getIsInit3());
					alertSet.setIsInit4(alertSetting.getIsInit4());
					alertSet.setOperator(alertSetting.getOperator());
					alertSet.setOperator1(alertSetting.getOperator1());
					alertSet.setOperator2(alertSetting.getOperator2());
					alertSet.setOperator3(alertSetting.getOperator3());
					alertSet.setOperator4(alertSetting.getOperator4());
					alertSet.setThreshold(alertSetting.getThreshold());
					alertSet.setThreshold1(alertSetting.getThreshold1());
					alertSet.setThreshold2(alertSetting.getThreshold2());
					alertSet.setThreshold3(alertSetting.getThreshold3());
					alertSet.setThreshold4(alertSetting.getThreshold4());
					alertSet.setPriority(alertSetting.getPriority());
					alertSet.setPriority1(alertSetting.getPriority1());
					alertSet.setPriority2(alertSetting.getPriority2());
					alertSet.setPriority3(alertSetting.getPriority3());
					alertSet.setPriority4(alertSetting.getPriority4());
					alertSet.setIsAlertAction1(alertSetting.getIsAlertAction1());
					alertSet.setIsAlertAction2(alertSetting.getIsAlertAction2());
					alertSet.setIsAlertAction3(alertSetting.getIsAlertAction3());
					alertSet.setIsAlertAction4(alertSetting.getIsAlertAction4());
					alertSet.setIsAlertSet1(alertSetting.getIsAlertSet1());
					alertSet.setIsAlertSet2(alertSetting.getIsAlertSet2());
					alertSet.setIsAlertSet3(alertSetting.getIsAlertSet3());
					alertSet.setIsAlertSet4(alertSetting.getIsAlertSet4());
					alertSet.setThresholdNum1(alertSetting.getThresholdNum1());
					alertSet.setThresholdNum2(alertSetting.getThresholdNum2());
					alertSet.setThresholdNum3(alertSetting.getThresholdNum3());
					alertSet.setThresholdNum4(alertSetting.getThresholdNum4());
					alertSet.setThresholdCounterReset1(alertSetting.getThresholdCounterReset1());
					alertSet.setThresholdCounterReset2(alertSetting.getThresholdCounterReset2());
					alertSet.setThresholdCounterReset3(alertSetting.getThresholdCounterReset3());
					alertSet.setThresholdCounterReset4(alertSetting.getThresholdCounterReset4());
					alertSet.setResumeAlert(alertSetting.getResumeAlert());
					alertSet.setActions(new ArrayList<IAlertAction>());
					
					alertSettingList.add(alertSet);
					
				}
				
				saveResult = service.saveAlertSettings(alertSettingList);
			}
			
		}
		
			
		return saveResult;
	}
	
	/**
	 * 查看流控设备的网络信息
	 */
	@At
	@Ok("jsp:jsp.asset.monitor.radix_netinfo")
	public void viewRadixNetInfo(HttpServletRequest request, 
			@Param("taskId") long taskId, @Param("key") String key, @Param("num") int num,
			@Param("type") String type){	
		TaskStruct ts = proMonitorService.getTaskStructById(taskId);
		NetInfoParser parser = new NetInfoParser(ts.getUrl());
		
		if(key == null || key.trim().equals("")){
			key = "rate";
		}
		
		Map<String, String> params = new HashMap<>();
		params.put("key", key);
		if(num > 0){
			params.put("num", num + "");
		}
		
		params.put("type", type);
		List<NetInfo> netinfoList = parser.getNetInfo(params);
		request.setAttribute("netinfoList", netinfoList);
	}
	
	/**
	 * 获取流控设备网络信息
	 * @param request
	 * @param taskId
	 * @param key
	 * @param num
	 * @param type
	 * @return
	 */
	@At
	@Ok("json")
	public List<NetInfo> getRadixNetInfo(HttpServletRequest request, 
			@Param("taskId") long taskId, @Param("key") String key, @Param("num") int num,
			@Param("type") String type){
		TaskStruct ts = proMonitorService.getTaskStructById(taskId);
		NetInfoParser parser = new NetInfoParser(ts.getUrl());
		Map<String, String> params = new HashMap<>();
		params.put("type", type);
		
		if(key == null || key.trim().equals("")){
			key = "rate";
		}
		params.put("key", key);
		if(num > 0){
			params.put("num", num + "");
		}
		return parser.getNetInfo(params);
	}
	
	/**
	 * 查看流控设备的网络信息
	 */
	@At
	@Ok("jsp:jsp.asset.monitor.radix_groupinfo")
	public void viewRadixGroupInfo(HttpServletRequest request, 
			@Param("taskId") long taskId){
		TaskStruct ts = proMonitorService.getTaskStructById(taskId);
		NetInfoParser parser = new NetInfoParser(ts.getUrl());
		
		Map<String, String> params = new HashMap<>();
		params.put("type", "group");
		List<NetInfo> groupinfoList = parser.getNetInfo(params);
		request.setAttribute("groupinfoList", groupinfoList);
	}
	
	/**
	 * 流控设备的链路ping信息.
	 * @param request
	 * @param sourceIp
	 */
	@At
	@Ok("jsp:jsp.asset.monitor.radix_link")
	public void viewRadixLinkInfo(HttpServletRequest request, @Param("sourceIp") String sourceIp){
		RadixPingInfo pingInfo = RadixCacheManager.me().getLinkCacheMap().get(sourceIp);
		request.setAttribute("pingInfo", pingInfo);
		
		List<Asset> list = assetService.queryByIp(sourceIp);
		if(list != null && list.size() > 0){
			TaskStruct ts = monitorDao.getTaskStructByAssetId(list.get(0).getId());
			request.setAttribute("taskstruct", ts);
		}
	}
	
	/**
	 * 返回设备的状态
	 * @param assetIds
	 * @return	1 设备运行正常 0 未建立监控任务或任务停止 -1 设备不连通 -2 设备有告警
	 */
	@At
	@Ok("json")
	public Map<Long, Integer> getStatus(@Param("assetIds") long[] assetIds){
		Map<Long, Integer> result = new HashMap<>();
		
		for(long assetId : assetIds){
			TaskStruct ts = proMonitorService.getTaskStructByAssetId(assetId);
			if(ts == null){			// 未建立监控任务
				result.put(assetId, 0);
				continue;
			}
			DefaultTask task = dispatcherService.getByTaskId(ts.getId());
			if(task == null){		// 任务未启动
				result.put(assetId, 0);
				continue;
			}
			
			TaskContext tCxt = task.getContext();
			if(tCxt == null){
				result.put(assetId, 0);
				continue;
			}
			
			if(!tCxt.isUsability()){
				result.put(assetId, -1);		// 不连通
				continue;
			}
			
			// 读取当天告警数量
			long timeEnd = System.currentTimeMillis();
			Calendar cal = Calendar.getInstance(); 
			cal.set(Calendar.HOUR_OF_DAY, 0); 
			cal.set(Calendar.SECOND, 0); 
			cal.set(Calendar.MINUTE, 0); 
			cal.set(Calendar.MILLISECOND, 0);
			long timeBegin = cal.getTimeInMillis();
			int alertCount = alertService.getUnhandledAlertCount(ts.getId(), timeBegin, timeEnd);
			if(alertCount > 0){				// 有告警
				result.put(assetId, -2);
				continue;
			}else{
				result.put(assetId, 1);		// 正常
				continue;
			}
		}
		
		return result;
	}
}
