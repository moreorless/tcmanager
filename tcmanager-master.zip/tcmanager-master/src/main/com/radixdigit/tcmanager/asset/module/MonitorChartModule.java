package com.radixdigit.tcmanager.asset.module;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jofc2.model.Chart;
import jofc2.model.Text;
import jofc2.model.axis.XAxis;
import jofc2.model.axis.XAxisLabels;
import jofc2.model.axis.YAxis;
import jofc2.model.axis.YAxisLabels;
import jofc2.model.elements.AbstractDot;
import jofc2.model.elements.AreaChart;
import jofc2.model.elements.PieChart;
import jofc2.model.elements.AnimatedElement.OnShow;
import jofc2.model.elements.LineChart;
import jofc2.model.axis.Label;
import gauge.GaugeChart;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.nutz.ioc.Ioc;
import org.nutz.ioc.annotation.InjectName;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.json.Json;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.Param;

import com.radixdigit.tcmanager.annotation.AuthBy;
import com.radixdigit.tcmanager.asset.polling.RadixCacheManager;
import com.radixdigit.tcmanager.asset.polling.RadixDeviceCache;
import com.radixdigit.tcmanager.asset.polling.RadixGroupItemSnap;
import com.radixdigit.tcmanager.monitor.core.data.ConcernsEntry;
import com.radixdigit.tcmanager.monitor.core.data.DefineConstant;
import com.radixdigit.tcmanager.monitor.core.data.TaskStruct;
import com.radixdigit.tcmanager.monitor.core.service.ConcernsEntryService;
import com.radixdigit.tcmanager.monitor.ext.radix.data.NetInfo;
import com.radixdigit.tcmanager.monitor.ext.radix.data.NetInfoParser;
import com.radixdigit.tcmanager.monitor.service.ProMonitorService;

@IocBean
@InjectName
@AuthBy(check=false)
@At("/monitor/chart/")
@Ok("chart")
@Fail("json")
public class MonitorChartModule {

	@Inject
	private ConcernsEntryService concernsEntryService;
	
	@Inject
	private ProMonitorService proMonitorService;
	
	@At
	public GaugeChart gaugeChart(@Param("value") String value){
		if(value == null || value.equals("undefined")){
			value = "0";
		}
		try{
			new Double(value).floatValue();
		}catch(Exception e){
			value = "0";
		}
		GaugeChart chart = new GaugeChart();
		
		/* 速度表的刻盘，0-70做成红色，70-80做成黄色，80以上做成绿色 */
		chart.setShowAlerts(true); //是否显示告警区域

		float[] alertAlphas=new float[3]; 
		alertAlphas[0]=(float)0.5;
		alertAlphas[1]=(float)0.4;
		alertAlphas[2]=(float)0.6;
		
		int[] alertColors=new int[3]; 
		alertColors[0]=0x00FF00;
		alertColors[1]=0xFFFF00;
		alertColors[2]=0xDD0000;
		
		int[] alertRatios=new int[3]; 
		alertRatios[0]=(int)70;
		alertRatios[1]=(int)90;
		alertRatios[2]=(int)100;	
		
		//设置告警区域
		chart.setAlertAlphas(alertAlphas); //告警区域透明度
		chart.setAlertColors(alertColors); //告警区域颜色序列
		chart.setAlertRatios(alertRatios); //告警区域比例

		
		chart.setValue(new Double(value).floatValue());
		chart.setValueUnit("%");
		chart.setShowCenter(true);
		return chart;
	}
	
	/**
	 * 生成指标的时间统计图
	 * @param ioc
	 * @param taskId
	 * @param concernsEntryId
	 * @param startTime
	 * @param endTime
	 * @param step  hour/day/month
	 * @return
	 */
	@At
	public Chart getEntryLineChart(Ioc ioc, @Param("taskId") long taskId, @Param("concernsEntryId") long concernsEntryId, 
			@Param("startTime") long startTime, @Param("endTime") long endTime, @Param("range") String range){
		Chart chart = new Chart();
		
		if(taskId == 0 || concernsEntryId == 0){
			return null;
		}
		
		ConcernsEntry entry = concernsEntryService.fetch(concernsEntryId);
		//chart.setTitle(new Text(entry.getIndexName()));
		
		if(!"custom".equals(range)){
			long[] timeRange = getTimeRange(range);
			startTime = timeRange[0];
			endTime = timeRange[1];
		}
		
		// 读取历史数据
		List<Map<String, Object>> tempResult = proMonitorService.getHistoryData(taskId, concernsEntryId, startTime, endTime);
		LineChart lc = new LineChart().setDotStyle(new AbstractDot.Style(AbstractDot.Style.Type.DOT, null,2 /* 数据点半径 */, 1 /* 数据点与连线间的间隔 */)).setWidth(3);
		lc.setOnShow(new OnShow(OnShow.TYPE_POPUP)); // 设置显示动画效果
		
		double maxValue = 1;
		for(Map<String, Object> item : tempResult){
			Number tempMax = (Number) item.get("value");
			if(tempMax.floatValue() > maxValue)
				maxValue = tempMax.doubleValue();
			
			Long time = Long.valueOf(item.get("time").toString());
			LineChart.ScatterDot sc = new LineChart.ScatterDot(time/1000,tempMax);
			//sc.setTooltip(tempMax + " (" + sf.format(new Date(a)) + ")");
			lc.addDots(sc);
		}
		lc.setColour("#0099ff");
		chart.addElements(lc);
		
		// x轴数据
		XAxis xAxis = new XAxis();
		XAxisLabels xlabels = new XAxisLabels();
		xlabels.setRotation(Label.Rotation.HALF_DIAGONAL);
		xlabels.setText(getLabelText(range));
		
		TaskStruct ts = proMonitorService.getTaskStructById(taskId);
		int tsInterval = ts.getSchedulingCycle();
		
		long xStep = getFixedXStep(startTime, endTime, tsInterval);
		xAxis.setRange(startTime/1000, endTime/1000, xStep);
		xAxis.setXAxisLabels(xlabels);
		chart.setXAxis(xAxis);
		
		// y轴数据
		YAxis yAxis = new YAxis();
		yAxis.setRange(0, maxValue, getFixedYStep(maxValue));
		YAxisLabels yAxisLabels=new YAxisLabels();
		
		String unit = entry.getUnit();
		if(entry.getType() == DefineConstant.TYPE_PERCENTAGE){
			unit = "%";
		}
		yAxisLabels.setText("#val#" + unit);
		yAxis.setYAxisLabels(yAxisLabels);
		
		chart.setYAxisAutoRange(false);
		chart.setYAxis(yAxis);
		chart.setYAxisAutoRange(false);
		
		return chart;
	}
	
	/**
	 * 获取合适的x轴步长
	 * @param startTime
	 * @param endTime
	 * @param tsInterval
	 * @return
	 */
	private long getFixedXStep(long startTime, long endTime, long tsInterval){
		long xStep = tsInterval;
		
		long timeRange = (endTime - startTime) / 1000;
		if(timeRange <= 3600){
			return xStep;			// 一小时内数据，直接使用监控步长
		}else if(timeRange > 3600 && timeRange <= 3600*24){
			return 3600;			// 一天内数据，步长为1小时
		}else if(timeRange > 3600 * 24 && timeRange <= 3600 * 24 * 30){
			return 3600 * 24;		// 一月内数据，步长为1天
		}else{
			return 3600 * 24 * 7;	// 一周为步长
		}
		
	}
	/**
	 * 计算一个合适的y轴步长
	 * @param maxValue
	 * @return
	 */
	private long getFixedYStep(double maxValue){
		long step = 1;
		if(step >= maxValue) return step;
		
		while(step < maxValue){
			step *= 10;
		}
		return step/10;
	}
	
	/**
	 * 计算起止时间
	 * @param rangeType
	 * @return
	 */
	private long[] getTimeRange(String rangeType){
		long endTime = System.currentTimeMillis();
		long startTime = endTime;
		long senconds = 0;
		switch (rangeType) {
		case "hour":
			senconds = 3600;
			break;
		case "day":
			senconds = 3600 * 24;
			break;
		case "week":
			senconds = 3600 * 24 * 7;
			break;
		case "month":
			senconds = 3600 * 24 * 30;
			break;
		case "year":
			senconds = 3600 * 24 * 365;
			break;
		default:
			break;
		}
		
		startTime = endTime - senconds*1000;
		return new long[]{startTime, endTime};
	}
	
	private String getLabelText(String rangeType){
		String labelText = "#date:m-d#";
		switch (rangeType) {
		case "hour":
		case "day":
			labelText = "#date:H:i#";
			break;
		case "week":
		case "month":
		case "year":
			labelText = "#date:m-d#";
			break;
		default:
			break;
		}
		return labelText;
	}
	
	/**
	 * 生成接口的统计图
	 * @param taskId		监控任务id
	 * @param indexId		接口序号
	 * @param type			数据类型
	 * @param startTime		起始时间
	 * @param endTime		结束时间
	 * @param range			时间范围类型
	 * @return
	 */
	@At
	public Chart getIfChart(@Param("taskId") long taskId, @Param("indexId") int indexId, @Param("type") String type,
			@Param("startTime") long startTime, @Param("endTime") long endTime, @Param("range") String range){
		
		String chartTitle = "";
		String inConcernsKey = "";
		String outConcernsKey = "";
		switch (type) {
		case "flux":
			chartTitle = "接口流量统计";
			inConcernsKey = "ifInFlux";
			outConcernsKey = "ifOutFlux";
			break;
		case "utilization":
			chartTitle =  "接口利用率统计";
			inConcernsKey = "ifInUtilization";
			outConcernsKey = "ifOutUtilization";
			break;
		case "error":
			chartTitle = "接口错误率统计";
			inConcernsKey = "ifInError";
			outConcernsKey = "ifOutError";
			break;
		case "lost":
			chartTitle = "接口丢包率统计";
			inConcernsKey = "ifInLost";
			outConcernsKey = "ifOutLost";
			break;
		default:
			break;
		}
		
		if(!"custom".equals(range)){
			long[] timeRange = getTimeRange(range);
			startTime = timeRange[0];
			endTime = timeRange[1];
		}
		
		Chart chart = new Chart();
		chart.setTitle(new Text(chartTitle));
		
		// 接收数据
		ConcernsEntry inEntry = concernsEntryService.getEntryByKey(taskId, inConcernsKey, indexId);
		List<Map<String, Object>> inResult = proMonitorService.getHistoryData(taskId, inEntry.getId(), startTime, endTime);
		LineChart lc = new LineChart().setDotStyle(new AbstractDot.Style(AbstractDot.Style.Type.DOT, null,2 /* 数据点半径 */, 1 /* 数据点与连线间的间隔 */)).setWidth(3);
		lc.setOnShow(new OnShow(OnShow.TYPE_POPUP)); // 设置显示动画效果
		
		double maxValue = 1;
		for(Map<String, Object> item : inResult){
			Number tempMax = (Number) item.get("value");
			if(tempMax.floatValue() > maxValue)
				maxValue = tempMax.doubleValue();
			
			Long time = Long.valueOf(item.get("time").toString());
			LineChart.ScatterDot sc = new LineChart.ScatterDot(time/1000,tempMax);
			lc.addDots(sc);
		}
		lc.setGradientFill(true);
		lc.setColour("#32B7FE");
		lc.setText("接收");
		chart.addElements(lc);
		
		// 发送数据
		ConcernsEntry outEntry = concernsEntryService.getEntryByKey(taskId, outConcernsKey, indexId);
		List<Map<String, Object>> outResult = proMonitorService.getHistoryData(taskId, outEntry.getId(), startTime, endTime);
		
		lc = new LineChart().setDotStyle(new AbstractDot.Style(AbstractDot.Style.Type.DOT, null,2 /* 数据点半径 */, 1 /* 数据点与连线间的间隔 */)).setWidth(3);
		lc.setOnShow(new OnShow(OnShow.TYPE_POPUP)); // 设置显示动画效果
		
		for(Map<String, Object> item : outResult){
			Number tempMax = (Number) item.get("value");
			if(tempMax.floatValue() > maxValue)
				maxValue = tempMax.doubleValue();
			
			Long time = Long.valueOf(item.get("time").toString());
			LineChart.ScatterDot sc = new LineChart.ScatterDot(time/1000,tempMax);
			lc.addDots(sc);
		}
		lc.setColour("#CC1B1B");
		lc.setText("发送");
		chart.addElements(lc);
		
		// x轴数据
		XAxis xAxis = new XAxis();
		XAxisLabels xlabels = new XAxisLabels();
		xlabels.setRotation(Label.Rotation.HALF_DIAGONAL);
		xlabels.setText(getLabelText(range));
		
		
		TaskStruct ts = proMonitorService.getTaskStructById(taskId);
		int tsInterval = ts.getSchedulingCycle();
		
		long xStep = getFixedXStep(startTime, endTime, tsInterval);
		xAxis.setRange(startTime/1000, endTime/1000, xStep);
		xAxis.setXAxisLabels(xlabels);
		chart.setXAxis(xAxis);
		
		// y轴数据
		YAxis yAxis = new YAxis();
		yAxis.setRange(0, maxValue, getFixedYStep(maxValue));
		YAxisLabels yAxisLabels=new YAxisLabels();
		
		String unit = inEntry.getUnit();
		if(inEntry.getType() == DefineConstant.TYPE_PERCENTAGE){
			unit = "%";
		}
		yAxisLabels.setText("#val#" + unit);
		yAxis.setYAxisLabels(yAxisLabels);
		
		chart.setYAxisAutoRange(false);
		chart.setYAxis(yAxis);
		chart.setYAxisAutoRange(false);
		
		return chart;
	}
	
	/**
	 * 生成流控设备接口的统计图
	 * @param taskId		监控任务id
	 * @param indexId		接口序号
	 * @param type			数据类型
	 * @param startTime		起始时间
	 * @param endTime		结束时间
	 * @param range			时间范围类型
	 * @return
	 */
	@At
	public Chart getRadixIfChart(@Param("taskId") long taskId, @Param("indexId") int indexId, @Param("type") String type,
			@Param("startTime") long startTime, @Param("endTime") long endTime, @Param("range") String range){
		
		String chartTitle = "";
		String concernsKey = "";
		switch (type) {
		case "totalFlow":
			chartTitle = "总流量统计";
			concernsKey = ConcernsEntry.ENTRY_KEY_RADIXFLOWTOTAL;
			break;
		case "upFlow":
			chartTitle = "上行流量统计";
			concernsKey = ConcernsEntry.ENTRY_KEY_RADIXFLOWUP;
			break;
		case "downFlow":
			chartTitle = "下行流量统计";
			concernsKey = ConcernsEntry.ENTRY_KEY_RADIXFLOWDOWN;
			break;
		default:
			break;
		}
		
		if(!"custom".equals(range)){
			long[] timeRange = getTimeRange(range);
			startTime = timeRange[0];
			endTime = timeRange[1];
		}
		
		Chart chart = new Chart();
		chart.setTitle(new Text(chartTitle));
		
		// 接收数据
		ConcernsEntry inEntry = concernsEntryService.getEntryByKey(taskId, concernsKey, indexId);
		List<Map<String, Object>> inResult = proMonitorService.getHistoryData(taskId, inEntry.getId(), startTime, endTime);
		LineChart lc = new LineChart().setDotStyle(new AbstractDot.Style(AbstractDot.Style.Type.DOT, null,2 /* 数据点半径 */, 1 /* 数据点与连线间的间隔 */)).setWidth(3);
		lc.setOnShow(new OnShow(OnShow.TYPE_POPUP)); // 设置显示动画效果
		
		double maxValue = 1;
		for(Map<String, Object> item : inResult){
			Number tempMax = (Number) item.get("value");
			if(tempMax.floatValue() > maxValue)
				maxValue = tempMax.doubleValue();
			
			Long time = Long.valueOf(item.get("time").toString());
			LineChart.ScatterDot sc = new LineChart.ScatterDot(time/1000,tempMax);
			lc.addDots(sc);
		}
		lc.setGradientFill(true);
		lc.setColour("#32B7FE");
		chart.addElements(lc);
		
		
		
		// x轴数据
		XAxis xAxis = new XAxis();
		XAxisLabels xlabels = new XAxisLabels();
		xlabels.setRotation(Label.Rotation.HALF_DIAGONAL);
		xlabels.setText(getLabelText(range));
		
		
		TaskStruct ts = proMonitorService.getTaskStructById(taskId);
		int tsInterval = ts.getSchedulingCycle();
		
		long xStep = getFixedXStep(startTime, endTime, tsInterval);
		xAxis.setRange(startTime/1000, endTime/1000, xStep);
		xAxis.setXAxisLabels(xlabels);
		chart.setXAxis(xAxis);
		
		// y轴数据
		YAxis yAxis = new YAxis();
		yAxis.setRange(0, maxValue, getFixedYStep(maxValue));
		YAxisLabels yAxisLabels=new YAxisLabels();
		
		String unit = inEntry.getUnit();
		if(inEntry.getType() == DefineConstant.TYPE_PERCENTAGE){
			unit = "%";
		}
		yAxisLabels.setText("#val#" + unit);
		yAxis.setYAxisLabels(yAxisLabels);
		
		chart.setYAxisAutoRange(false);
		chart.setYAxis(yAxis);
		chart.setYAxisAutoRange(false);
		
		return chart;
	}
	
	/**
	 * 流控设备饼图
	 * @return
	 */
	@At
	public Chart viewRadixPieChart(@Param("taskId") long taskId, @Param("key") String key,  @Param("num") int num,
			@Param("type") String type, @Param("radius") int radius){
		
		TaskStruct ts = proMonitorService.getTaskStructById(taskId);
		NetInfoParser parser = new NetInfoParser(ts.getUrl());
		
		if(key == null || key.trim().equals("")){
			key = "rate";
		}
		
		Map<String, String> params = new HashMap<>();
		params.put("key", key);
		if(num > 0){
			params.put("num", num + "");
		}
		
		params.put("type", type);
		
		List<NetInfo> hostinfoList = parser.getNetInfo(params);
		
		/*
		Map<String, Float> valueMap = new HashMap<>();
		for(NetInfo netInfo : hostinfoList){
			if("up".equals(key)) valueMap.put(netInfo.getName(), netInfo.getUp());
			if("down".equals(key)) valueMap.put(netInfo.getName(), netInfo.getDown());
			if("rate".equals(key)) valueMap.put(netInfo.getName(), netInfo.getRate());
			if("session".equals(key)) valueMap.put(netInfo.getName(), (float)netInfo.getSession());
		}
		*/
		
		PieChart pc = new PieChart(); 
		
		if(hostinfoList != null && hostinfoList.size() > 0){
			Iterator<NetInfo> iter = hostinfoList.iterator();
			
			int total = 0;
			while(iter.hasNext()){
				NetInfo netInfo = iter.next();
				
				int value = 0;
				if("up".equals(key)) value = (int)netInfo.getUp();
				if("down".equals(key)) value = (int)netInfo.getDown();
				if("rate".equals(key)) value = (int)netInfo.getRate();
				if("session".equals(key)) value = netInfo.getSession();
				
				String name = "";
				if("host".equals(type)) name = netInfo.getIp();
				if("server".equals(type)) name = netInfo.getName();
				if("group".equals(type)) name = netInfo.getGroupName();
				
				if(value > 0){
					PieChart.Slice slice = new PieChart.Slice(value, name);
					slice.setTip(String.valueOf(name + " : " + value));
					
					pc.addSlices(slice);
				}
				total += value;
			}
			pc.setOnClick("pie_click_handler");
			
			if(total == 0){
				PieChart.Slice slice = new PieChart.Slice(1, "无数据");
				slice.setTip("无数据");
				pc.addSlices(slice);
			}
			
		}else{
			PieChart.Slice slice = new PieChart.Slice(1, "无数据");
			slice.setTip("无数据");
			pc.addSlices(slice);
		}
		
		pc.setRadius(radius);
		pc.setAnimate(true); //设置使用动画效果
		
		Chart chart = new Chart(getKeyName(key)).addElements(pc);
		
		return chart;
	}
	public String getKeyName(String key){
		String name = "";
		switch (key) {
		case "up":
			name = "上行流速";
			break;
		case "down":
			name = "下行流速";
			break;
		case "rate":
			name = "总流速";
			break;
		case "session":
			name ="会话数";
			break;
		default:
			break;
		}
		return name;
	}

	
	public static String[] colors = new String[]{
		"#F54E62",
		"#F0BB0B", // 黄
		"#00CCCB", // 浅蓝
		"#80D24C", // 浅绿
		"#7953DA", // 淡紫
		"#4FB5DD", // 淡蓝
		"#FF58FC", // 粉色
		"#7C334E", // 紫色
		"#517F96", // 
	};
	
	private int colorIndex = 0;
	// 顺序选取颜色
	public String getColorString(){
		colorIndex = colorIndex % colors.length;
	
		return colors[colorIndex++];
	}
	
	@At
	@Ok("raw:xml")
	public String viewRadixGroupChart(@Param("taskId") long taskId, @Param("key") String key){
		long endTime = System.currentTimeMillis();
		long startTime = endTime - 3600 * 1000;
		
		Document document = DocumentHelper.createDocument();
		Element chartEle = document.addElement("chart");
		Element seriesEle = chartEle.addElement("series");
		Element graphsEle = chartEle.addElement("graphs");
		
		int xid = 0;
		int gid = 0;
		colorIndex = 0;
		
		// groupName与<graph/>的对应
		Map<String, Element> graphEleMap = new HashMap<>();
		
		if(RadixCacheManager.me().getDeviceCacheMap().containsKey(taskId)){
			List<RadixGroupItemSnap> snapList = RadixCacheManager.me().getDeviceCacheMap().get(taskId).getGroupSnapList();
			Iterator<RadixGroupItemSnap> iter = snapList.iterator();
			while(iter.hasNext()){
				RadixGroupItemSnap snap = iter.next();
				if(snap.getTimestamp() < startTime) continue;
				
				// 添加横坐标
				long timestamp = snap.getTimestamp();
				SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
				seriesEle.addElement("value").addAttribute("xid","" + xid).addText(df.format(timestamp));
				
				
				List<NetInfo> netinfoList = snap.getNetInfo();
				for(NetInfo netInfo : netinfoList){
					String groupName = netInfo.getGroupName();
					
					// 第一次出现该服务组名称，创建新的graph元素
					if(!graphEleMap.containsKey(groupName)){
						Element graphEle = graphsEle.addElement("graph").addAttribute("title", groupName)
								.addAttribute("gid", "" + gid++).addAttribute("color", getColorString())
								.addAttribute("fill_alpha", "60").addAttribute("line_width", "2");
						graphEleMap.put(groupName, graphEle);
					}
					Element graphEle = graphEleMap.get(groupName);
					
					int value = 0;
					if("up".equals(key)) value = (int)netInfo.getUp();
					if("down".equals(key)) value = (int)netInfo.getDown();
					if("rate".equals(key)) value = (int)netInfo.getRate();
					if("session".equals(key)) value = netInfo.getSession();
					
					// 添加新的<value />
					graphEle.addElement("value").addAttribute("xid", "" + xid).addText(String.valueOf(value));
				}
				
				xid++;
			}
		}
		return document.asXML();
	}
	
	/**
	 * 读取缓存数据，测试使用
	 * @return
	 */
	@At
	@Ok("json")
	public Map<Long, RadixDeviceCache>  getRadixCache(){
		return RadixCacheManager.me().getDeviceCacheMap();
	}
}
