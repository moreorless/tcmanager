package com.radixdigit.tcmanager.asset.polling;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;


public class RadixDeviceCache {
	
	private int groupSnapSize = 360;
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	/**
	 * 服务组快照
	 */
	private List<RadixGroupItemSnap> groupSnapList = new LinkedList<>();
	
	/**
	 * 获取拷贝
	 * @return
	 */
	public List<RadixGroupItemSnap> getGroupSnapList() {
		synchronized (groupSnapList) {
			List<RadixGroupItemSnap> newList = new LinkedList<>();
			for(RadixGroupItemSnap snap : groupSnapList){
				newList.add(snap);
			}
			return newList;
		}
	}
	
	public void addGroupSnap(RadixGroupItemSnap snap){
		if(groupSnapList.size() >= groupSnapSize){
			groupSnapList.remove(0);
		}
		groupSnapList.add(snap);
		
		// logger.debug("添加服务组数据缓存 - timestamp = " + snap.getTimestamp() + "---" + new Date(snap.getTimestamp()).toLocaleString());
	}
	
}
