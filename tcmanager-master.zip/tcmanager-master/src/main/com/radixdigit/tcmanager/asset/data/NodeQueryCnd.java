/**
 
 * Author: wangxh
 * Created: 2011-4-26
 */
package com.radixdigit.tcmanager.asset.data;

import java.io.Serializable;

/**
 * 资产查询对象
 * 
 * @author wangxh
 * 
 */
public class NodeQueryCnd implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 节点ID
	 */
	private long id;

	
	/**
	 * 所在管理组节点id
	 */
	private long groupId;
	
	/**
	 * 视图类型
	 */
	private String viewType;
	/**
	 * 资产名称
	 */
	private String name;
	/**
	 * 资产别名
	 */
	private String alias;
	/**
	 * 资产类型
	 */
	private long type;
	/**
	 * 资产类型IDArr
	 */
	private String typeids;
	/**
	 * IP范围起始
	 */
	private String ipRangeStart;
	/**
	 * IP范围结束
	 */
	private String ipRangeEnd;
	
	/**
	 * 管理开关：资产是否接受管理
	 */
	private int manageSwitch=-1;

	/**
	 * 资产IP
	 */
	private String ip;
	
	/**
	 * 接口IP
	 */
	private String interfaceIp;

	/**
	 * MAC地址
	 */
	private String mac;

	/**
	 * 联系人
	 */
	private String contact;
	
	/**
	 * 区域名称
	 */
	private String netDistrict;
	/**
	 * 地理位置
	 */
	private String location;
	/**
	 * 资产编码
	 */
	private String assetCode;
	/**
	 * 序列号
	 */
	private String sn;
	/**
	 * 制造商
	 */
	private String manufacturer;
	/**
	 * 是否虚拟资产(0：否,2:虚拟资产)
	 */
	private int virtualType=-1;
	/**
	 * 资产价值起始值（查询用）
	 */
	private int valueLowwer;
	/**
	 * 资产价值截止值（查询用）
	 */
	private int valueUpper;
	/**
	 * 等保等级
	 * @return
	 */
	private int protectLowwer;
	private int protectUpper;
	//操作类型，查询或者新增资产
	//operate='search' or 'add'
	private String operate;
	public int getProtectLowwer() {
		return protectLowwer;
	}

	public void setProtectLowwer(int protectLowwer) {
		this.protectLowwer = protectLowwer;
	}

	public int getProtectUpper() {
		return protectUpper;
	}

	public void setProtectUpper(int protectUpper) {
		this.protectUpper = protectUpper;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getAssetCode() {
		return assetCode;
	}

	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public int getVirtualType() {
		return virtualType;
	}

	public void setVirtualType(int virtualType) {
		this.virtualType = virtualType;
	}

	public int getValueLowwer() {
		return valueLowwer;
	}

	public void setValueLowwer(int valueLowwer) {
		this.valueLowwer = valueLowwer;
	}

	public int getValueUpper() {
		return valueUpper;
	}

	public void setValueUpper(int valueUpper) {
		this.valueUpper = valueUpper;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getType() {
		return type;
	}

	public void setType(long type) {
		this.type = type;
	}

	public int getManageSwitch() {
		return manageSwitch;
	}

	public void setManageSwitch(int manageSwitch) {
		this.manageSwitch = manageSwitch;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getInterfaceIp() {
		return interfaceIp;
	}

	public void setInterfaceIp(String interfaceIp) {
		this.interfaceIp = interfaceIp;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}


	public void setNetDistrict(String netDistrict) {
		this.netDistrict = netDistrict;
	}

	public String getNetDistrict() {
		return netDistrict;
	}
	
	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	public String getTypeids() {
		return typeids;
	}

	public void setTypeids(String typeids) {
		this.typeids = typeids;
	}

	public String getIpRangeStart() {
		return ipRangeStart;
	}

	public void setIpRangeStart(String ipRangeStart) {
		this.ipRangeStart = ipRangeStart;
	}

	public String getIpRangeEnd() {
		return ipRangeEnd;
	}

	public void setIpRangeEnd(String ipRangeEnd) {
		this.ipRangeEnd = ipRangeEnd;
	}

	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	public String getOperate() {
		return operate;
	}

	public void setOperate(String operate) {
		this.operate = operate;
	}
	
}
