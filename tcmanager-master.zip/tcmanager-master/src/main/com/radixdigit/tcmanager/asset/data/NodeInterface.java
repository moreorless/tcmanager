package com.radixdigit.tcmanager.asset.data;

/**
 * 节点类通用接口
 * @author wangxh
 *
 */
public interface NodeInterface {
	
	/**
	 * 节点标识
	 * @return 
	 */
	long getId();
	/**
	 * 
	 * @param Id
	 */
	void setId(long id); 
	/**
	 * 节点名称
	 * @return
	 */
	String getName();
	/**
	 * 
	 * @param name
	 */
	void setName(String name);
	/**
	 * 节点类型
	 * @return
	 */
	int getCategory(); 
	/**
	 * 
	 * @param type
	 */
	void setCategory(int category); 

	/**
	 * 管理开关,描述是否被管理
	 * @return
	 */
	int getManageSwitch();
	/**
	 * 
	 * @param manageSwitch
	 */
	void setManageSwitch(int manageSwitch);
	/**
	 * 节点状态
	 * @return
	 */
	int getStatus();
	/**
	 * 
	 * @param status
	 */
	void setStatus(int status); 
	/**
	 * 节点描述
	 * @return
	 */
	String getDescription(); 
	/**
	 * 
	 * @param desc
	 */
	void setDescription(String desc); 
	/**
	 * 节点创建时间
	 * @return
	 */
	long getTimeCreate(); 
	/**
	 * 
	 * @param createTime
	 */
	void setTimeCreate(long createTime);
	/**
	 * 节点修改时间
	 * @return
	 */
	long getTimeModify();
	/**
	 * 
	 * @param modifyTime
	 */
	void setTimeModify(long modifyTime); 
	/**
	 * 是否内置：1-是；2-否
	 * @return
	 */
	int getBuiltIn();
	/**
	 * 
	 * @param builtIn
	 */
	void setBuiltIn(int builtIn);
	/**
	 * 图标
	 * @return
	 */
	String getIcon();
	/**
	 * 
	 * @param icon
	 */
	void setIcon(String icon);
}
