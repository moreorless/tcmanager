package com.radixdigit.tcmanager.commons.mvc.taglib;

import org.apache.taglibs.standard.tag.el.core.IfTag;

import com.radixdigit.tcmanager.auth.Auths;


public class LoginSupport extends IfTag {
	
	protected boolean isLogin() {
		return (Auths.getUser(pageContext.getSession()) != null);
	}
	
}
