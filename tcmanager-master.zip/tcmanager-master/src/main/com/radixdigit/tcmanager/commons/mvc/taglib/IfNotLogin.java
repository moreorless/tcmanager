package com.radixdigit.tcmanager.commons.mvc.taglib;

import javax.servlet.jsp.JspTagException;

/**
 * 检查是否登录标签
 * <p>
 * 使用方法与&lt;c:if&gt;类似，只是不需要设置value属性值，即：<br/>
 * &lt;cupid:ifNotLogin&gt;<br/>
 * &nbsp;&nbsp;&lt;%-- do something, e.g. redirect to login page --%&gt;<br/>
 * &lt;/cupid:ifNotLogin&gt;
 * </p>
 * @author liunan
 *
 */
public class IfNotLogin extends LoginSupport {

	@Override
	protected boolean condition() throws JspTagException {
		return !isLogin();
	}

}
