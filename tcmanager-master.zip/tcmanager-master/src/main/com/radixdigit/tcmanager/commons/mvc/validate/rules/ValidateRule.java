/**
 
 * Author: Administrator
 * Created: 2011-5-10
 */
package com.radixdigit.tcmanager.commons.mvc.validate.rules;


public interface ValidateRule {

	public int[] validate(Object value);
	
}
