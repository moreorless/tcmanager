var ioc = {
	// 默认的登录认证
	defaultAuthenticator : {
		type : "com.radixdigit.tcmanager.auth.authentication.DefaultAuthenticator",
		fields : {
			service : {refer: 'userService' },
			servletContext : {app:'$servlet'}
		}
	},
	defaultPermissionMatcher : {
		type : "com.radixdigit.tcmanager.auth.matcher.SimpleRWPermissionMatcher",
		fields : {
			methods : [],
		}
	}
};