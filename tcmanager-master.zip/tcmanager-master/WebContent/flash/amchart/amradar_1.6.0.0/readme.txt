amRadar version 1.6.0.1
********************************************************************************
Check documentation for help on all topics:
http://www.amcharts.com/docs/

Incase you don't find something, post your questions to support forum:
http://www.amcharts.com/forum/
******************************************************************************** 
Note: amRadar started from version v 1.6.0.0, to meet versions of other charts
in amCharts bungle
********************************************************************************