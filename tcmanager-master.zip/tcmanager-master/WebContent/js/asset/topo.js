
/**
 * 一些全局变量
 */
var AssetMgtConfig = {
	groupId : 0,
	lostThreshold : 20,
	delayThreshold : 100
};

var _skinColor = '0xffffff';
var _defaultLinkColor = '#338833';
var _alertLinkColor = '#fbb450';
var _errorLinkColor = '#cc1100';
var topoBgImg = {isShow:false};
var panConsoleBackColor = '0xC1C1C1';
var panConsoleBorderColor = '0xC1C1C1';
var panConsoleBoxFontColor = '#333333';

﻿/**
 * 添加拖拽节点的回调和调用方法
 */
function _configAddElementsData(type,data){
	if( type == "node" ){

	}else if( type == "edge"){
		var edge={
				label : '',
				source : data.source,
				target : data.target,
				width: data.width,	////////此处待修改，因为返回的是weight(0-1),而width(1-10)			//系统内置的类型,控制连线宽度
				sourceArrowShape: data.sourceArrowShape,	//系统内置的类型,控制连线起点
				targetArrowShape: data.targetArrowShape,	//系统内置的类型,控制连线终点
				lineStyle: data.lineStyle,  //系统内置的类型,控制连线样式
				color: data.color	//系统内置的类型,连线的颜色
		};
		TopoHandler.createEdge(edge);
	}
	return null;	//无需更改
};
/**
 * 配置控制台参数---注意:本方法名不可以修改
 *　本函数独立区分于ctyoscapeweb的配置方式,降低耦合,本方法由控制台(自定义组件)直接调用.
 */
function _initConsoleBoxParam(){
		//参数对象----注意:所有字段不可以修改,不支持自定义字段
		var setParameters = {
			backgroundColor: _skinColor,			//控制舞台的背景颜色,默认0x252525,0x为16进制格式,不可以修改
			backgroundFollowImg:topoBgImg,
			nodeTypeArr:[],
			panAddEdgeBoxVisible:true,			//添加连线浮动面板是否可见,默认为false,
			panConsoleBoxVisible:false,			//控制台是否可见 默认为false,
			panConsoleBoxAlign:"right",			//控制台的对齐方式,目前只支持,左对齐left,右对齐right
			panConsoleBoxBackgroundColor: panConsoleBackColor,//控制台背景色以下二个颜色最好同步,默认颜色3e3e3e
			panConsoleBoxBorderColor:panConsoleBorderColor,//控制台背景边框颜色
			panConsoleBoxFontColor:panConsoleBoxFontColor,	//控制台文字颜色
			dragOutVBoxRowNum:'3',				//拖拽面板的默认显示行数,默认显示4行,最大值为6行
			initPanArray:[						//这个数组是控制面板的显示和收起.
				{name:"dragOutVBox", visible:false, label:"拖拽面板", show_hide:"hide"},
				{name:"layoutOutVBox",visible:false,label:"布局面板",show_hide:"hide"},
				{name:"attrOutVBox",visible:false,label:"属性面板",show_hide:"hide"}
			],
			dragImgArray:[]
		}
	return setParameters;
};



/**
 * 设备类型
 */
var DevTypeHandler = {
	/**
	 * 节点类型与图标的映射关系
	 */
	nodeTypeMapperArr : [{
		attrValue : "group",
		value : $.context + "/images/asset/group_128.png"
		}],
	typelist : [],		// 设备类型
	/**
	 * var deviceType={
					id, name, code, icon
				};
	 */
	addDeviceType : function(deviceType){
		this.typelist.push(deviceType);
	},
	/**
	 * 根据设备编码获取图标
	 */
	getIconByCode : function(code){
		var icon = $.context + "/images/asset/device/server.png";
		$.each(DevTypeHandler.typelist, function(index, typeObj){
			if(typeObj.code == code){
				icon = typeObj.icon;
				return false;
			}
		});
		return icon;
	},
	getByCode : function(code){
		var type;
		$.each(DevTypeHandler.typelist, function(index, typeObj){
			if(typeObj.code == code){
				type = typeObj;
				return false;
			}
		});
		return type;
	}
};


var TopoHandler = {
		groupId : 0,
		autoLayout : false,
		vis:{},
		isDrag:false,
		ipToNodeMap : {},   // 设备ip到节点id的映射
		_linkMap : {},       // 链路的map
		// initialization options 
		options:{
			swfPath : $.context + "/flash/topo/CytoscapeWeb",
			flashInstallerPath : $.context +  + "/flash/topo/playerProductInstall",
			preloadImages: true,
			useProxy: false
		},
		/**
		 *  加载拓扑图
		 *  输入参数 groupId
		 *  autoLayout  加载后是否自动布局
		 *  */
		loadTopo:function(groupId, autoLayout){
			this.groupId = groupId;
			this.autoLayout = autoLayout;
			
			var div_id="cytoscapeweb";//页面中DIV元素 id="cytoscapeweb"
			// init and draw
			TopoHandler.vis = new org.cytoscapeweb.Visualization(div_id, TopoHandler.options);
			//注册监听事件
			TopoHandler.topoListener.init();
			// 注册拓扑绘制完成后事件
			TopoHandler.vis.ready(function(){
				//全局样式
				TopoHandler.vis.visualStyle(TopoHandler.visual_style);
				//设置节点真实大小(必须设置在layout前，否则不管用)
				TopoHandler.vis.zoom(1);
				//设置节点的提示启用
				TopoHandler.vis.nodeTooltipsEnabled(true);
				//设置连线的label可用
				TopoHandler.vis.edgeLabelsVisible(true);
				//设置按照坐标布局
				TopoHandler.vis.layout({name:"Preset",options:{fitToScreen: false, points:[]}});
				//拓扑加载完毕，添加节点连线
				TopoHandler._loadTopoData();
				
				/* 延时1000毫秒 启动数据刷新 */
				setTimeout(TopoHandler.refreshData, 1000);
			});
			//darw
			TopoHandler.vis.draw({network : {dataSchema :TopoHandler.topoDataSchema,data : {}}});
			
			
		},
		/**
		 * 根据ip获取拓扑节点Id
		 */
		getProxyIdByIp : function(ip){
			var proxyId = TopoHandler.ipToNodeMap[ip];
			// if(!TopoHandler.vis.node(proxyId)) return null;  // 如果节点不存在，返回null
			return proxyId;
		},
		_loadTopoData : function(){
			$.ajax({
				type : "POST",
				url : jQuery.context + '/asset/getTopoData',
				dataType : 'json',
				data : {
					groupId: TopoHandler.groupId
				},
				success : function(proxyList){
					// 存储节点连线
					var topoElementsArr=[];
					$.each(proxyList,function(index,proxy){
						if(proxy.nodeType ==1){		// 资产
							if(proxy.node!=null){
								
								var node = {
										x : proxy.pointX,
										y : proxy.pointY,
										group: "nodes",
										data:{id : String(proxy.id),
											nodeId : String(proxy.node.id),
											label : proxy.node.ip,
											ip : proxy.node.ip,
											tooltipText: proxy.node.name + "\n" + proxy.node.ip + '\n' + DevTypeHandler.getByCode(proxy.node.type).name,
											type : String(proxy.node.type),
											nodeType : "asset",
											topoType : proxy.node.type
											
										}
									};
								topoElementsArr.push(node);
								
								TopoHandler.ipToNodeMap[proxy.node.ip] = String(proxy.id);
							}
						}else if(proxy.nodeType ==2){ //连线
							if(proxy.node!=null){
								var edge = {
										group: "edges",
										data:{
											id : String(proxy.id),
											nodeId : String(proxy.node.id),
											//label : proxy.node.description,
											tooltipText : proxy.node.description,
											source : String(proxy.node.startId),
											target : String(proxy.node.endId),
											width: proxy.node.width,				//控制连线宽度
											sourceArrowShape: 'NONE',	//控制连线起点
											targetArrowShape: 'ARROW',	//控制连线终点
											lineStyle: 'SOLID',			//控制连线样式
											color: _defaultLinkColor, 			//连线颜色
											nodeType : "link"
										}
									};
								topoElementsArr.push(edge);
							}
						}
						/* 
						// 不加载组结点
						else if(proxy.nodeType ==4){   // 组
							if(proxy.node!=null){
								var group = {
										group: "nodes",
										x : proxy.pointX,
										y : proxy.pointY,
										data:{
											id : String(proxy.id),
											nodeId : String(proxy.node.id),
											label : proxy.node.name,			
											nodeType : "group",
											size : 128,
											topoType : 'group'
										}
									};
								topoElementsArr.push(group);
							}
						}
						*/
					});
					//ajax请求成功后，先移除所有节点和连线，再添加
					// TopoHandler.vis.removeElements();
					TopoHandler.vis.addElements(topoElementsArr, true);
					
					if(TopoHandler.autoLayout){
						TopoHandler.vis.layout({name:'Radial'});//布局
					}
					
				}
			}
			);
		},
		
		//定义数据字段 ,使用dataSchema定义 要传递的数据，在事件回调时，仍然能取到这些数据
		topoDataSchema : {
			nodes:[  { name: "weight", type: "double" ,defValue: 0.2},			//控制节点宽度
					 { name: "shape", type: "string" ,defValue: "DIAMOND"},		//控制节点形状
					 { name: "label", type: "string" },							//控制节点文字描述
					 { name: "size", type: "double" ,defValue: 36 },			//控制节点宽度
				     {name:"x",type:"number"},						//系统内置类型，节点X轴坐标
				     {name:"y",type:"number"},						//系统内置类型，节点Y轴坐标
			       	 {name:"tooltipText",type:"string"},			//系统内置类型，节点提示信息
			         {name:"nodeId",type:"string"},
				     {name:"type",type:"string"},
				     {name:"topoType", type:"string"},
			         {name:"nodeType",type:"string"},
				     {name:"ip",type:"string"},
				     {name : "image", type : "string"},
				     { name: "topoLabelIcon", type: "object" }		// 节点的状态图标
				],
				edges:[ { name: "network",type: "double" ,defValue: 2},	//系统内置的类型
				        { name: "width",type: "double" ,defValue: 2},	//控制连线宽度
						{ name: "sourceArrowShape", type: "string" },	//控制连线起点
						{ name: "targetArrowShape", type: "string" },	//控制连线终点
						{ name: "lineStyle", type: "string" },			//控制连线样式
						{ name: "sourceArrowColor",  type: "string" },	//控制连线起点颜色
						{ name: "targetArrowColor",  type: "string" },	//控制连线终点颜色
						{ name: "label", type: "string" },				//控制连线的文字描述
						{name:"tooltipText",type:"string"},			    //系统内置类型，节点提示信息
						{ name:"color",type:"string"},
						{ name:"nodeId",type:"string"},
						{ name: "topoLabelIcon", type: "object" },	
						{ name:"nodeType",type:"string"}
						
			    ]
		},
		/**
		 * 使用资产id 获取节点代理
		 */
		getProxyByAssetId : function(assetId){
			var proxy = null;
			var nodes = TopoHandler.vis.nodes();
			$.each(nodes, function(index, theAsset){
				if(theAsset.data.nodeId == assetId){
					proxy = theAsset.data;
					return false;
				}			
			});
			return proxy;
		},
		/**
		 * 使用连线id 获取节点代理
		 */
		getProxyByLinkId : function(linkId){
			var proxy = null;
			var edges = TopoHandler.vis.edges();
			$.each(edges, function(index, theEdge){
				if(theEdge.data.nodeId == linkId){
					proxy = theEdge.data;
					return false;
				}			
			});
			return proxy;
		},
		// 定义拓扑显示样式
		visual_style:{
			global : {
				backgroundColor: "#ffffff"  //拓扑背景色
			},
			nodes : {
				color:"transparent", //默认为“#ffffff”白色
				labelFontColor : '#333333',
				//borderWidth:0,//设置节点边框为无
				shape : "RECTANGLE",//节点形状
				compoundColor : "transparent",//组节点背景颜色为透明(默认为“#ffffff”)
				compoundShape : "RECTANGLE",//复合节点（组）的形状
				compoundLabelFontColor : "#666",
				tooltipText:{passthroughMapper:{attrName:"tooltipText"}},//节点提示信息
				size: { passthroughMapper: { attrName: "size" } },
				labelHorizontalAnchor : "center",
				labelVerticalAnchor : 'top',
				/*image : {passthroughMapper:{attrName:"image"}}*/
				image: {
					defaultValue: $.context + "/images/asset/device/server.png",
					discreteMapper:  {
						attrName: "topoType",
						entries: DevTypeHandler.nodeTypeMapperArr
					}
				}
			},
			edges : {
				mergeColor : "#0b94b1",
				color: { defaultValue:_defaultLinkColor,
					passthroughMapper: { attrName: "color" } },
				labelFontColor : '#4671d5',
				style :{defaultValue:"SOLID",
					passthroughMapper:{attrName:"lineStyle"}},
				width: {defaultValue:2,
					passthroughMapper:{attrName:"width"}},
				sourceArrowShape: {defaultValue:"NONE",
						passthroughMapper:{attrName:"sourceArrowShape"}},
				targetArrowShape: {defaultValue:"ARROW",
					passthroughMapper:{attrName:"targetArrowShape"}},
				sourceArrowColor: { passthroughMapper: { attrName: "color" } },
				targetArrowColor: { passthroughMapper: { attrName: "color" } },
				labelHorizontalAnchor: "center",
				labelVerticalAnchor : 'top'
			}
		},
		
		/* 刷新数据 */
		refreshData : function(){
			var refreshFunc = function(){
				
				TopoAssetRefresher.refresh();
				
				TopoLinkRefresher.refresh();
				};

			refreshFunc();
			setInterval(refreshFunc, 30000);	// 数据刷新间隔 1分钟 
			
			},
		//定义点击拓扑事件监听
		topoListener:{
			init:function(){
				// 注册事件
				TopoHandler.vis.addListener("click", "none", function(event) {
					//handle_bkgroundclick(event);
				})
				.addListener("click", "nodes", function(event) {
					Listener.node_handle_click(event);
				})
				.addListener("click", "edges", function(event) {
					Listener.edge_handle_click(event);
				})
				.addListener("select",function(event) {
					Listener.select_handle(event);
				})
				.addListener("deselect",function(event) {
					Listener.deselect_handle(event);
				})
				.addListener("dblclick","nodes",function(event) {
					Listener.node_dblclick_handle(event);
				})
				.addListener("dblclick","edges",function(event) {
					Listener.edge_dblclick_handle(event);
				})
				.addListener("error", function(err) {
					alert(err.value.msg);
				});
			}	
		},
		
		createEdge : function(edge){
			// 添加连线 -- 向数据库中添加
			var color = edge.color;//"#00CC99";//
			var fromID = edge.source;
			var toID = edge.target;
			var width = edge.width;
			$.ajax({
			  type: 'POST',
			  url: $.context + '/asset/insertLink',
			  data: {
				  groupId : this.groupId,
				  edge : $.toJSON({
					  name : '',
					  description : '',
					  startId : fromID,
					  endId : toID,
					  width:width
				  })
			  },
			  success: function(proxy){
				  // 刷新拓扑图
				  TopoHandler.addEdge(proxy);
				  
				  // 弹出连线编辑对话框
				  // LinkDialogHandler.load(proxy.node.id);
			  },
			  error : function(){
				  $.jGrowl("", {
						header: "保存失败",
						group: "error"
					});		
			  },
			  dataType: 'json'
			});
		},
		addEdge : function(proxy){
			var edge = {
					id : String(proxy.id),
					nodeId : String(proxy.node.id),
					// label : String(proxy.node.name),
					color : _defaultLinkColor,
					source : String(proxy.node.startId),
					target : String(proxy.node.endId),
					width: proxy.node.width,				//系统内置的类型,控制连线宽度
					nodeType : "link"
				};
			TopoHandler.vis.addEdge(edge, true);
		},
		
		//保存节点位置信息
		saveTopo : function(){
			var v_edges=[];
			var v_nodes=[];
			var nodeAttr=TopoHandler.vis.nodes();
			$.each(nodeAttr,function(index,nodeObj){
				var node={id:nodeObj.data.id,
							x:parseInt(nodeObj.x),
							y:parseInt(nodeObj.y)
						};
				v_nodes.push(node);
			});
			/**
			 * 不保存链路
			nodeAttr=TopoHandler.vis.edges();
			$.each(nodeAttr,function(index,edgeObj){
				var edge={
						 id:edgeObj.data.id,
						 width: edgeObj.data.width
						};
				v_edges.push(edge);
			});
			*/
			$.ajax({		  
				  type: 'POST',
				  url: $.context + '/asset/saveTopo',
				  dataType: 'json',
				  data: {
					  groupId : TopoHandler.groupId,
					  Node: $.toJSON(v_nodes),
					  Link: $.toJSON(v_edges)
					  },
				  success: function(){
					  $.jGrowl("", {
								header: "保存成功",
								group: "success"
						});		
				  }
				});
		},
		//得到选中元素id
		getSelectedIds : function(){
			var selectnodes=TopoHandler.vis.selected();
			if(selectnodes.length>0){
				var proxyIds = [];
				$.each(selectnodes, function(index, node){
					var id = node.data.id;
					proxyIds.push(id);
				});	
				return proxyIds;
			}
		},
		// 根据起点id获取所有连线
		getEdgesBySrcId : function(source){
			var allEdges = TopoHandler.vis.edges();
			var resule = [];
			for(var i = 0; i < allEdges.length; i++){
				if(allEdges[i].data.source == source){
					resule.push(allEdges[i]);
				}
			}
			return resule;
		}
};

var Listener={
		node_handle_click:function(event){
			
			var nodetype=event.target.data.nodeType;
			//调用ajax获取节点信息，显示信息面板
			if(nodetype=="asset"){
				//如果是资产
				InfoPanel.loadAsset(event.target.data.nodeId);
			}
		},
		edge_handle_click:function(event){
			$("#btn-delete").btn("enable");
			$("#btn-edit").btn("disable");
			InfoPanel.loadLink(event.target.data.source, event.target.data.target);
		},
		select_handle:function(event){
			var selectnodes=TopoHandler.vis.selected();
			if(selectnodes.length>0){
				$("#btn-delete").btn("enable");
				
				if(selectnodes.length==1){
					var nodeType=selectnodes[0].data.nodeType;
					if(nodeType=="asset"){
						$("#btn-edit").btn("enable");
					}else{
						$("#btn-delete").btn("disable");
						$("#btn-edit").btn("disable");
					}
				}else{
					$("#edit-btn").btn("disable");
				}
			}
		},
		deselect_handle:function(event){
			InfoPanel.close();
			$("#btn-edit").btn("disable");
			$("#btn-delete").btn("disable");
		},
		node_dblclick_handle:function(event){
			var nodetype=event.target.data.nodeType;
			//调用ajax获取节点信息，显示信息面板
			if(nodetype=="asset"){
				//如果是资产
				var assetId = event.target.data.nodeId;
				window.location = $.context + '/asset/monitor/detail?assetId=' + assetId + '&groupId=' + AssetMgtConfig.groupId + '&view=topo';
			}
		},
		edge_dblclick_handle:function(event){
		}
	};

var TopoAssetRefresher={
		addNode : function(proxy){
			var data = {
					id : String(proxy.id),
					nodeId : String(proxy.node.id),
					label : proxy.node.ip,
					ip : proxy.node.ip,
					x : proxy.pointX,
					y : proxy.pointY,
					tooltipText: proxy.node.name,
					topoType: String(proxy.node.type),
					type :  String(proxy.node.type),
					nodeType : 'asset'
				};
			var n = TopoHandler.vis.addNode(proxy.pointX, proxy.pointY, data, true);
		},
		addGroupNode : function(proxy){
			var data = {
					id : String(proxy.id),
					nodeId : String(proxy.node.id),
					label : proxy.node.name,
					ip : proxy.node.ip,
					x : proxy.pointX,
					y : proxy.pointY,
					topoType: String(proxy.node.type),
					type :  String(proxy.node.type),
					nodeType : 'group',
					size : 48
				};
			var n = TopoHandler.vis.addNode(proxy.pointX, proxy.pointY, data, true);
		},
		editNode:function(asset){
			var proxyNode=TopoHandler.vis.selected("nodes")[0];
			var data={
					label : asset.name,
					ip : asset.ip,
					tooltipText: asset.ip,
					topoType: String(asset.type),
					type :  String(asset.type)
			};
			TopoHandler.vis.updateData("nodes",[proxyNode],data);
		},
		addEdge:function(proxy){
			var edge = {
					id : String(proxy.id),
					nodeId : String(proxy.node.id),
					//label : String(proxy.node.name),
					source : String(proxy.node.startId),
					target : String(proxy.node.endId),
					width: proxy.node.width,				//系统内置的类型,控制连线宽度
					nodeType : "link"
				};
			TopoHandler.vis.addEdge(edge, true);
		},
		deletNodes:function(){
			var selectNodes=TopoHandler.vis.selected("nodes");
			TopoHandler.vis.removeElements("nodes",selectNodes); 
		},
		deletEdges:function(){
			var selectEdges=TopoHandler.vis.selected("edges");
			TopoHandler.vis.removeElements("edges",selectEdges,true); 
		},
		
		getAssetIds : function(){
			var assetIds = [];
			var nodes = TopoHandler.vis.nodes();
			$.each(nodes, function(proxyId, proxyObj){
				if(proxyObj.data.nodeType == 'asset'){
					var assetId = proxyObj.data.nodeId;
					if(assetId) assetIds.push(assetId);
				}
			});
			return assetIds;
		},
		
		/* 刷新节点数据 */
		refresh : function(){
			// 刷新设备状态
			this.refreshStatus();
		},
		// 批量刷新连通性状态
		refreshStatus : function(){
			// 不连通状态
			var errorStr = {topoLabelIcon:{array:[ {url:$.context + "/images/asset/status_error.png", xOffset: 10, yOffset:-40} ]}};
			// 告警状态
			var alertStr = {topoLabelIcon:{array:[ {url:$.context + "/images/asset/status_warning.png", xOffset: 10, yOffset:-40} ]}};
			// 运行状态
			var normalStr = {topoLabelIcon:{array:[ {url:$.context + "/images/asset/status_normal.png", xOffset: 10, yOffset:-40} ]}};
			// 未启动监控
			var nodataStr = {topoLabelIcon:{array:[]}};
			
			var assetIds = this.getAssetIds();
			if(!assetIds || assetIds.length == 0) return;
			$.ajax({
				errorPlacer : 0,
				url : $.context + '/asset/monitor/getStatus',
				dataType : 'json',
				type : 'get',
				data : {assetIds : assetIds},
				success : function(result){
					// 设备状态 1 表示连通 0 表示未启动状态监控 -1 表示不连通  -2 表示有告警
					var errorIds = []; var alertIds = []; var normalIds = []; var nodataIds = [];
					for(var assetId in result){
						var proxyId = TopoHandler.getProxyByAssetId(assetId).id;
						
						if(result[assetId] == 1){   // 连通
							normalIds.push(proxyId);
						}else if(result[assetId] == -1){  // 不连通
							errorIds.push(proxyId);
						}else if(result[assetId] == -2){ // 告警
							alertIds.push(proxyId);
						}else{
							nodataIds.push(proxyId);
						}
					}
					
					if(errorIds.length > 0) TopoHandler.vis.updateData('nodes', errorIds, errorStr);
					if(alertIds.length > 0) TopoHandler.vis.updateData('nodes', alertIds, alertStr);
					if(normalIds.length > 0) TopoHandler.vis.updateData('nodes', normalIds, normalStr);
					if(nodataIds.length > 0) TopoHandler.vis.updateData('nodes', nodataIds, nodataStr);
				}
			});
		}
};

var TopoLinkRefresher = {
		refresh : function(){
			
			// 读取流控设备的链路缓存
			$.ajax({
				url : $.context + '/link/getRadixPingCache',
				dataType : 'json',
				type : 'get',
				success : function(linkCache){
					for(var radixIp in linkCache){
						var srcProxyId = TopoHandler.getProxyIdByIp(radixIp);
						if(srcProxyId){  // 判断流控设备是否在本拓扑上
							var edges = TopoHandler.getEdgesBySrcId(srcProxyId);   // 当前节点连接的所有连线
							
							// 流控设备不连通，没有取到链路数据，删除所有链路。
							if(linkCache[radixIp] == null || linkCache[radixIp].pingdata == null){
								TopoHandler.vis.removeElements('edges', edges, true);
								continue;
							}
							
							var pingdataList = linkCache[radixIp].pingdata;
							if(pingdataList){
								var destIpList = [];
								for(var i = 0; i < pingdataList.length; i++){
									destIpList.push(pingdataList[i].destip);
								}
								
								
								// 检测刷新链路
								// 1. 标记出已经不存在的链路删除掉
								for(var i = 0; i<edges.length; i++){
									var edge = edges[i];
									var destIp = TopoHandler.vis.node(edge.data.target).data.ip;
									if($.inArray(destIp, destIpList) == -1){  // 链路已经不存在，删除
										TopoHandler.vis.removeElements('edges', edge, true);
									}
								}
								
								
								// 2. 当前存在的链路，刷新状态颜色
								// 3. 不存在的链路，需要添加上
								
								for(var i = 0; i < pingdataList.length; i++){
									var pingdata = pingdataList[i];
									var dstProxyId = TopoHandler.getProxyIdByIp(pingdata.destip);
									if(!dstProxyId) continue;
									
									// 判断告警和丢包率，决定链路颜色。
									var _color = _defaultLinkColor;
									if(pingdata.lost >= AssetMgtConfig.lostThreshold || pingdata.avg >= AssetMgtConfig.delayThreshold){
										_color = _alertLinkColor;
									}
									if(pingdata.lost == 100){
										_color = _errorLinkColor;  // 丢包率100%
									}
									
									// 判断链路是否已存在，不存在添加；已存在修改颜色。
									var linkId = srcProxyId + '_' + dstProxyId;
									
									var edge = TopoHandler.vis.edge(linkId);
									if(!edge){	// 链路不存在，添加
										var edgeData = {
												id : linkId,
												nodeId : linkId,
												source : srcProxyId,
												target : dstProxyId,
												width: 2,				//系统内置的类型,控制连线宽度
												nodeType : "link",
												color : _color
										};
										edge = TopoHandler.vis.addEdge(edgeData, true);
									}else{
										// 链路已存在，修改颜色
										TopoHandler.vis.updateData('edges', [edge], {color : _color});
									}
									
								}
							}
							
						}
					}
				},
				error : function(){
					console.log('刷新链路错误');
				}
			});
			
			/*
			// 读取最近5分钟内后台自动添加的流控设备链路，若未添加则添加到拓扑图上。
			var linkIds = this.getLinkIds();
			
			$.ajax({
				url : $.context + '/asset/getLastedRadixLink',
				dataType : 'json',
				type : 'get',
				data : {groupId : TopoHandler.groupId},
				success : function(linkProxyList){
					for(var i = 0; i < linkProxyList.length; i++){
						var linkProxy = linkProxyList[i];
						if($.inArray(linkProxy.node.id + "", linkIds) == -1){   // 该连线不在拓扑图中，新建
							TopoHandler.addEdge(linkProxy);
						}
					}
				}
			});
			*/
		},
		
		getLinkIds : function(){
			var edgeIds = [];
			var edges = TopoHandler.vis.edges();
			$.each(edges, function(proxyId, proxyObj){
				if(proxyObj.data.nodeType == 'link'){
					var edgeId = proxyObj.data.nodeId;
					if(edgeId) edgeIds.push(edgeId);
				}
			});
			return edgeIds;
		}
			
	};

/**
 * 信息面板
 */
var InfoPanel = {
	panel_id : 'info-panel',
	init : function(){},
	loadAsset : function(assetId){
		$('#info-panel').css('width', '350px');
		$('#' + this.panel_id).load($.context + '/asset/loadAssetInfo', 
				{assetId : assetId, groupId : AssetMgtConfig.groupId, view : 'topo'}, 
				function(response, status, xhr) {
					// 关闭事件注册
					$('#info-panel .close').click(function(){
						$('#info-panel').hide();
					});
					
					$('#' + InfoPanel.panel_id).show();
					
					NodePanelHandler.init();
				});
		
	},
	
	loadAssetDetail : function(assetId){
		
	},
	
	loadLink : function(sourceId, targetId){
		$('#' + this.panel_id).load($.context + '/asset/loadLinkInfo', 
				{sourceId : sourceId, targetId : targetId, groupId : AssetMgtConfig.groupId, view : 'topo'}, 
				function(response, status, xhr) {
					// 关闭事件注册
					$('#info-panel .close').click(function(){
						$('#info-panel').hide();
					});
					
					$('#' + InfoPanel.panel_id).show();
				});
	},
	
	close : function(){
		$('#' + InfoPanel.panel_id).hide();
	}
		
}
