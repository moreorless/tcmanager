{
   "enable" :true,
   "serviceMailAddress" :"smtp.163.com",
   "port" :25,
   "username" :"radixdigit",
   "userPassword" :"1qaz2wsx",
   "validateService" :true,
   "mailTo" :"gxl0620@163.com"
}