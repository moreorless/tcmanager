{
"mergeTimeRange" :3600,
"pingLostThreshold" :20,
"pingDelayThreshold" :100
}